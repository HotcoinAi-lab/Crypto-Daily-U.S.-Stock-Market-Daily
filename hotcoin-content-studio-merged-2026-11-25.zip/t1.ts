const fng = { value: 63 };
const up = 1;
const down = 5;
const x = `> ① 价格主线：${[1, 2].map((t) => `${t} 项`).join("、")}；主流资产 ${up} 涨 ${down} 跌`;
console.log(x);
