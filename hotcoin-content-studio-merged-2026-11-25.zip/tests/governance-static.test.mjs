import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";
import { latestMondayToSaturday, parseWeeklyPublishWindow } from "../lib/report-governance.ts";

const weekly = await readFile(new URL("../lib/weekly.ts", import.meta.url), "utf8");
const governance = await readFile(new URL("../lib/report-governance.ts", import.meta.url), "utf8");
const api = await readFile(new URL("../app/api/weekly/route.ts", import.meta.url), "utf8");
const dailyApi = await readFile(new URL("../app/api/daily-quality/route.ts", import.meta.url), "utf8");
const projectApi = await readFile(new URL("../app/api/stock-report/route.ts", import.meta.url), "utf8");
const dailyScript = await readFile(new URL("../scripts/check-daily-package.mjs", import.meta.url), "utf8");
const tradfiDaily = await readFile(new URL("../lib/tradfi-daily.ts", import.meta.url), "utf8");
const tradfiApi = await readFile(new URL("../app/api/tradfi-daily/route.ts", import.meta.url), "utf8");
const registry = await readFile(new URL("../lib/run-registry.ts", import.meta.url), "utf8");
const schema = await readFile(new URL("../db/schema.ts", import.meta.url), "utf8");
const dailyUi = await readFile(new URL("../app/page.tsx", import.meta.url), "utf8");

test("weekly collection is bound to an explicit Monday-to-Saturday window", () => {
  assert.match(weekly, /startTime=\$\{startMs\}/);
  assert.match(weekly, /from=\$\{Math\.floor\(startMs/);
  assert.match(governance, /周报仅接受周一 00:00 至周六 23:59 北京时间的发布窗口；周日发布/);
  assert.match(api, /parseWeeklyPublishWindow\(body\.reportWindow\)/);
  assert.match(governance, /Asia\/Shanghai/);
});

test("Shanghai weekly window ends on Saturday and is parseable", () => {
  // 2026-11-16 is a Monday in Asia/Shanghai; latest complete window is Nov 9-14.
  const window = latestMondayToSaturday(new Date("2026-11-16T04:00:00Z"));
  assert.equal(window.timezone, "Asia/Shanghai");
  assert.equal(window.label, "2026-11-09 至 2026-11-14");
  assert.deepEqual(parseWeeklyPublishWindow(window), window);
});

test("weekly collector expects six daily candles for the Monday-to-Saturday window", () => {
  assert.match(weekly, /周一至周六 K 线不足 6 根/);
  assert.doesNotMatch(weekly, /自然周 K 线不足 7 根/);
});

test("HYPE 24h fallback cannot populate 7d field", () => {
  assert.doesNotMatch(weekly, /Gate 现货（24h 口径）/);
  assert.match(governance, /7 日字段不可使用 24h 降级数据/);
});

test("weekly governance has evidence-bound release checks and a run registry", () => {
  for (const id of ["weekly-window", "weekly-24h", "weekly-source-null", "weekly-schema", "weekly-window-output", "weekly-evidence-bounds", "weekly-oi-window", "weekly-approval"]) assert.match(governance, new RegExp(id));
  assert.match(api, /saveRun/);
});

test("weekly gate labels unsupported generated content", () => {
  assert.match(governance, /检测到无一手底稿支撑/);
});

test("ETF failure with non-null output and daily missing evidence are blocked", () => {
  assert.match(governance, /Farside ETF/);
  assert.match(governance, /input\.draft\.etf !== null/);
  assert.match(dailyApi, /evidence\.md/);
  assert.match(dailyApi, /saveRun/);
  assert.match(dailyScript, /daily-quality-report\.json/);
});

test("project report has delivery gates and registers its run", () => {
  assert.match(governance, /projectReportGate/);
  assert.match(governance, /project-locales/);
  assert.match(governance, /project-approval/);
  assert.match(projectApi, /reportType: "tokenized-stock-report"/);
  assert.match(projectApi, /project-report-quality\.json/);
});

test("TradFi plan requires three timestamped evidence streams before production", () => {
  for (const marker of ["美股正式收盘", "Hotcoin 行情快照", "宏观事件日历", "daily-three-timelines", "daily-evidence-links", "daily-evidence-integrity", "daily-evidence-freshness"]) assert.match(tradfiDaily, new RegExp(marker));
  assert.match(tradfiApi, /未生成正文或图表/);
  assert.match(tradfiApi, /await saveRun/);
});

test("daily approval has a visible control and maps draft status correctly", () => {
  assert.match(dailyUi, /id="daily-approval"/);
  assert.match(dailyUi, /待人工确认/);
  assert.match(dailyUi, /dailyApproved/);
});

test("run registry has a D1 durable path and a local-preview fallback", () => {
  assert.match(schema, /report_runs/);
  assert.match(registry, /getDb()/);
  assert.match(registry, /memory fallback/);
});
