import { text, sqliteTable } from "drizzle-orm/sqlite-core";

// D1 is the production system of record. The payload is intentionally JSON so each report
// product can preserve its own output contract without being flattened into one schema.
export const reportRuns = sqliteTable("report_runs", {
  runId: text("run_id").primaryKey(),
  reportType: text("report_type").notNull(),
  createdAt: text("created_at").notNull(),
  status: text("status").notNull(),
  payload: text("payload").notNull(),
});
