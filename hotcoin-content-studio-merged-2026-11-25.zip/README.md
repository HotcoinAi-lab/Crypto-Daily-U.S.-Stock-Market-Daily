# AI Market Content Studio

本地市场日报生产工具：启动自动采集，也可手动采集；按提示词生成内容；本地质量检查和人工确认后，通过CMS API发布。

## 已实现

- 启动自动采集及“开始采集”按钮
- Binance真实行情；Cointelegraph、Decrypt RSS资讯
- 美股三大股指（CNBC公共行情接口）
- BTC/ETH现货ETF资金流（Farside，含日度/周度与连续同向天数）
- 宏观经济日历（ForexFactory本周中高影响事件）
- 恐惧与贪婪指数（alternative.me）
- 扩展源带TTL缓存（股指10分钟/ETF 30分钟/日历60分钟），限流时按retry-after退避重试一次
- 来源失败明确显示，不生成模拟行情
- OpenAI Responses API生成；没有密钥时使用事实模板
- Prompt编辑、正文编辑和本地缓存
- 时效、来源、完整度、风险提示、收益承诺检查
- 阻断项未通过或未人工确认时禁止发布
- 可配置CMS URL、Bearer Token和幂等发布
- SEO元数据自动提取：Meta Title/Description、关键词、slug、FAQ、NewsArticle与FAQPage结构化数据
- KuCoin同款文章URL结构：`/{locale}/news/articles/crypto-daily-market-report-august-31-2026`，同日重发同URL覆盖，旧`?id=`链接301跳转
- SEO质量检查（H1唯一、导语段、FAQ小节）作为发布提醒项
- 演示CMS含文章页（meta/OG/JSON-LD/内链）、新闻列表页、sitemap.xml、rss.xml、robots.txt
- 内置演示CMS接口与独立CMS API程序

## 本地启动

要求 Node.js 22.13+。

```bash
cp .env.example .env.local
# 编辑 .env.local，按需填写 OPENAI_API_KEY
npm run dev
```

内置演示CMS地址为 `/api/cms/articles`。默认演示Token只适合localhost；对外部署前必须设置 `CMS_RECEIVER_SECRET`。

## 独立CMS API

```bash
CMS_RECEIVER_SECRET='your-long-secret' node cms-api/server.mjs
```

工作台配置：

```text
CMS API地址：http://127.0.0.1:8788/v1/articles
Bearer Token：your-long-secret
```

接口：

```http
POST /v1/articles
GET  /v1/articles
Authorization: Bearer <secret>
Content-Type: application/json
Idempotency-Key: daily-2026-08-26
```

创建文章请求体：

```json
{
  "contentType": "daily_market_report",
  "language": "zh-CN",
  "status": "published",
  "title": "加密货币每日市场报告",
  "content": "Markdown正文",
  "symbols": ["BTC", "ETH"],
  "collectedAt": "2026-08-26T00:00:00.000Z",
  "sourceAudit": []
}
```

独立API示例使用内存存储，重启会清空。接正式CMS时请替换为数据库写入，并保持响应字段 `id`、`url`、`publishedAt`。

## CMS适配

工作台发送 `contentType`、`language`、`status`、`title`、`content`、`symbols`、`collectedAt`、`sourceAudit`。WordPress、Strapi或自研CMS字段不同，可在 `app/api/publish/route.ts` 建立映射。

## 安全边界

- AI密钥只通过服务端环境变量读取。
- 发布前必须通过阻断检查并人工确认。
- 正式环境不要使用示例Token。
- RSS只用于标题和事件线索；商业发布前应确认内容授权。
