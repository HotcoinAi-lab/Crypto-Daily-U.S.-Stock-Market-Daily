@echo off
chcp 65001 >nul
title Hotcoin 加密日报工作台
cd /d "%~dp0"

set "NODE_EXE=E:\D\nodejs\node.exe"
if not exist "%NODE_EXE%" (
  echo [错误] 未找到 Node.js: %NODE_EXE%
  echo 请修改本脚本中的 NODE_EXE 路径
  pause
  exit /b 1
)

echo ============================================
echo   Hotcoin 加密日报工作台
echo   启动后请访问 http://localhost:5173/
echo   关闭本窗口即停止网站
echo ============================================
echo.

"%NODE_EXE%" node_modules\vite\bin\vite.js

echo.
echo [网站已停止]
pause
