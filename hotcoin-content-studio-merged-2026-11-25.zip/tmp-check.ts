export type Ticker = { symbol: string; price: number; change24h: number; volume24h: number; source: string; observedAt: string };
export type NewsItem = { title: string; url: string; source: string; publishedAt: string };
export type FearGreed = { value: number; label: string };
export type EquityQuote = { symbol: string; name: string; price: number; changePct: number; observedAt: string };
// ETF 资金流金额单位：百万美元（与 Farside 表格一致）
export type EtfFlow = { asset: string; asOf: string; dailyFlow: number; prevDayFlow: number; weekFlow: number; streakDays: number };
export type CalendarEvent = { date: string; title: string; region: string; impact: string; forecast: string; previous: string };
export type FactPack = { collectedAt: string; tickers: Ticker[]; news: NewsItem[]; sources: { name: string; ok: boolean; count: number; error?: string }[]; indicators?: { fearGreed?: FearGreed }; equities?: EquityQuote[]; etfFlows?: EtfFlow[]; calendar?: CalendarEvent[] };

export function cleanXml(value = "") {
  return value.replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, "$1").replace(/<[^>]+>/g, " ").replace(/&amp;/g, "&").replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/\s+/g, " ").trim();
}

export function parseRss(xml: string, source: string): NewsItem[] {
  const blocks = xml.match(/<item[\s\S]*?<\/item>/gi) || [];
  return blocks.slice(0, 12).map((block) => {
    const get = (tag: string) => block.match(new RegExp(`<${tag}[^>]*>([\\s\\S]*?)<\\/${tag}>`, "i"))?.[1] || "";
    return { title: cleanXml(get("title")), url: cleanXml(get("link")), source, publishedAt: cleanXml(get("pubDate")) };
  }).filter((item) => item.title && item.url);
}

const FNG_ZH: Record<string, string> = { "extreme fear": "极度恐惧", fear: "恐惧", neutral: "中性", greed: "贪婪", "extreme greed": "极度贪婪" };

// CNBC 公共行情接口返回的股指报价
export function parseCnbcQuotes(payload: unknown): EquityQuote[] {
  const quotes = (payload as { FormattedQuoteResult?: { FormattedQuote?: Record<string, string>[] } })?.FormattedQuoteResult?.FormattedQuote || [];
  return quotes.map((q) => ({
    symbol: String(q.altSymbol || q.symbol || ""),
    name: String(q.shortName || q.name || q.symbol || ""),
    price: Number(String(q.last || "").replace(/,/g, "")),
    changePct: Number(String(q.change_pct || "").replace("%", "")),
    observedAt: String(q.last_time || ""),
  })).filter((q) => q.symbol && Number.isFinite(q.price) && Number.isFinite(q.changePct));
}

// Farside（farside.co.uk/btc|eth）表格：日期行首列、末列 Total，单位百万美元，括号表示净流出
export function parseFarsideFlows(html: string, asset: string): EtfFlow | undefined {
  const table = html.match(/<table[^>]*class="[^"]*etf[^"]*"[\s\S]*?<\/table>/i)?.[0];
  if (!table) return undefined;
  const cells = (row: string) => (row.match(/<td[^>]*>([\s\S]*?)<\/td>/gi) || []).map((c) => c.replace(/<[^>]+>/g, " ").replace(/&nbsp;|\u00a0/g, " ").trim());
  const toFlow = (raw = "") => {
    const negative = raw.includes("(");
    const num = Number(raw.replace(/[(),]/g, ""));
    return Number.isFinite(num) ? (negative ? -num : num) : NaN;
  };
  // 按日期字符串手工组装 ISO 日期，避免 new Date("28 Aug 2026") 被按本地时区解析导致日期偏移
  const MONTHS: Record<string, string> = { jan: "01", feb: "02", mar: "03", apr: "04", may: "05", jun: "06", jul: "07", aug: "08", sep: "09", oct: "10", nov: "11", dec: "12" };
  const toIsoDate = (raw: string) => {
    const [d, mon, y] = raw.split(" ");
    const mm = MONTHS[mon?.toLowerCase() || ""];
    return mm ? `${y}-${mm}-${d.padStart(2, "0")}` : "";
  };
  const daily = (table.match(/<tr[\s\S]*?<\/tr>/gi) || []).map(cells)
    .filter((c) => /^\d{1,2} \w{3} \d{4}$/.test(c[0] || ""))
    .map((c) => ({ date: toIsoDate(c[0]), flow: toFlow(c[c.length - 1]) }))
    .filter((r) => r.date && Number.isFinite(r.flow));
  if (!daily.length) return undefined;
  const last = daily[daily.length - 1];
  const streakDays = (() => { let n = 0; for (let i = daily.length - 1; i >= 0 && Math.sign(daily[i].flow) === Math.sign(last.flow); i--) n++; return n; })();
  return {
    asset,
    asOf: last.date,
    dailyFlow: last.flow,
    prevDayFlow: daily.length > 1 ? daily[daily.length - 2].flow : NaN,
    weekFlow: daily.slice(-5).reduce((s, r) => s + r.flow, 0),
    streakDays,
  };
}

// ForexFactory 本周经济日历（nfs.faireconomy.media），仅保留中高影响事件并按时间排序
export function parseFfCalendar(payload: unknown): CalendarEvent[] {
  const rows = Array.isArray(payload) ? payload as Record<string, string>[] : [];
  return rows.filter((r) => r.title && r.date && ["High", "Medium"].includes(r.impact)).map((r) => ({
    date: new Date(r.date).toISOString(),
    title: String(r.title),
    region: String(r.country || ""),
    impact: String(r.impact || ""),
    forecast: String(r.forecast || ""),
    previous: String(r.previous || ""),
  })).sort((a, b) => +new Date(a.date) - +new Date(b.date));
}


function fmtUsd(value: number, maxFractionDigits = 2) {
  return `$${value.toLocaleString("en-US", { maximumFractionDigits: value < 1 ? 6 : maxFractionDigits })}`;
}

// 成交额以中文数量级呈现（亿美元），便于阅读
function fmtVolume(value: number) {
  if (value >= 1e8) return `$${(value / 1e8).toFixed(2)} 亿`;
  if (value >= 1e4) return `$${(value / 1e4).toFixed(1)} 万`;
  return `$${value.toFixed(0)}`;
}

// 百万美元 → 中文数量级（亿）
function fmtFlowM(valueM: number) {
  return `${valueM < 0 ? "净流出" : "净流入"} $${(Math.abs(valueM) / 100).toFixed(2)} 亿`;
}

export function fallbackDraft(facts: FactPack) {
  // 报告日期用本地时区；「资料截至」保留精确 UTC 时间戳
  const day = new Date(facts.collectedAt).toLocaleDateString("zh-CN", { month: "long", day: "numeric" });
  const sorted = [...facts.tickers].sort((a, b) => b.change24h - a.change24h);
  const strongest = sorted[0];
  const weakest = sorted[sorted.length - 1];
  const up = facts.tickers.filter((t) => t.change24h > 0).length;
  const down = facts.tickers.length - up;
  const breadth = up > down ? "全线上涨" : down > up ? "普遍回落" : "涨跌互现";
  const pct = (t?: Ticker) => (t ? `${t.change24h >= 0 ? "+" : ""}${t.change24h.toFixed(2)}%` : "—");
  const fng = facts.indicators?.fearGreed;
  const fngZh = fng ? FNG_ZH[fng.label.toLowerCase()] || fng.label : "";
  const fngTone = fng && fng.value >= 55 ? "偏热" : "中性";
  const cryptoLine = facts.tickers.map((t) => `${t.symbol}: ${fmtUsd(t.price)} (${pct(t)})`).join("；");
  const dataLine = cryptoLine + (fng ? `；恐惧与贪婪指数: ${fng.value}（${fngZh}）` : "") + ` (资料截至：${new Date(facts.collectedAt).toISOString()} UTC)`;
  const movers = [...facts.tickers].sort((a, b) => Math.abs(b.change24h) - Math.abs(a.change24h)).slice(0, 3);
  // 事件式规则标题（模板无法提炼新闻事件，用最强资产 + 整体涨跌）
  const headline = `加密日报｜主流币${breadth}，${strongest?.symbol || "BTC"} 领${(strongest?.change24h ?? 0) >= 0 ? "涨" : "跌"} ${Math.abs(strongest?.change24h ?? 0).toFixed(2)}%`;
  const upcoming = (facts.calendar || []).filter((e) => +new Date(e.date) >= +new Date(facts.collectedAt) - 12 * 3600 * 1000).slice(0, 5);
  const firstEvent = upcoming[0];
  const eventLine = firstEvent ? `${new Date(firstEvent.date).toISOString().slice(5, 16).replace("T", " ")} UTC：${firstEvent.title}［${firstEvent.region}］` : "周末无高影响经济日程";
  const etf = facts.etfFlows?.find((f) => f.asset === "BTC");
  const flowLine = etf ? `BTC ETF ${etf.asOf} ${fmtFlowM(etf.dailyFlow)}（连续 ${etf.streakDays} 天同向）` : "ETF 资金流数据待接入";
  const macroRe = /fed|fomc|cpi|inflation|interest rate|rate cut|rate hike|sec |regulat|treasury|jobs|unemploy|ecb|boj|central bank|gdp|tariff|congress|senate|pce|nonfarm/i;
  const macroNews = facts.news.filter((n) => macroRe.test(n.title)).slice(0, 3);
  const industryNews = facts.news.filter((n) => !macroRe.test(n.title)).slice(0, 5);
  const fmtNews = (items: NewsItem[]) => items.map((n) => `- ${n.title}（来源：${n.source}）`).join("\n");
  const lede = `${day}日报：${facts.tickers.slice(0, 2).map((t) => `${t.symbol} 报 ${fmtUsd(t.price)}（${pct(t)}）`).join("、")}，整体${breadth}${fng ? `；恐惧与贪婪指数 ${fng.value}（${fngZh}）` : ""}。`;
  const faqLines = [
    `- 今日主要加密资产价格是多少？：${facts.tickers.slice(0, 3).map((t) => `${t.symbol} 报 ${fmtUsd(t.price)}（24 小时 ${pct(t)}）`).join("；")}（资料截至 ${new Date(facts.collectedAt).toISOString()}）。`,
    fng ? `- 目前市场情绪偏贪婪还是恐惧？：恐惧与贪婪指数报 ${fng.value}／100（${fngZh}），该指数综合波动率、成交量与社交数据反映近期市场情绪。` : "",
    ...(facts.etfFlows || []).map((f) => `- ${f.asset} 现货 ETF 最新资金流如何？：${f.asOf} ${fmtFlowM(f.dailyFlow)}，近 5 个交易日合计 ${fmtFlowM(f.weekFlow)}；资金流方向可作为机构需求的粗略观察窗口。`),
    upcoming.length ? `- 近期有哪些宏观事件值得关注？：${upcoming.slice(0, 3).map((e) => `${new Date(e.date).toLocaleDateString("zh-CN", { month: "numeric", day: "numeric" })}${e.title}`).join("；")}。` : "",
  ].filter(Boolean);

]
}
