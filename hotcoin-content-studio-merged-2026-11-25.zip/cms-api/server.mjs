import http from "node:http";
import { randomUUID } from "node:crypto";

const port = Number(process.env.CMS_API_PORT || 8788);
const secret = process.env.CMS_RECEIVER_SECRET;
if (!secret) { console.error("Missing CMS_RECEIVER_SECRET. Refusing to start without authentication."); process.exit(1); }
const articles = new Map(); const idempotency = new Map();
function json(res, status, body) { res.writeHead(status, { "content-type": "application/json; charset=utf-8", "access-control-allow-origin": "http://localhost:3000", "access-control-allow-headers": "authorization, content-type, idempotency-key" }); res.end(JSON.stringify(body)); }

const server = http.createServer(async (req, res) => {
  if (req.method === "OPTIONS") return json(res, 204, {});
  if (req.headers.authorization !== `Bearer ${secret}`) return json(res, 401, { error: "Unauthorized" });
  if (req.method === "GET" && req.url === "/v1/articles") return json(res, 200, { items: [...articles.values()] });
  if (req.method !== "POST" || req.url !== "/v1/articles") return json(res, 404, { error: "Not found" });
  const key = req.headers["idempotency-key"]; if (key && idempotency.has(key)) return json(res, 200, idempotency.get(key));
  let raw = ""; for await (const chunk of req) raw += chunk;
  let body; try { body = JSON.parse(raw); } catch { return json(res, 400, { error: "Invalid JSON" }); }
  if (!body.title || !body.content || !body.language) return json(res, 422, { error: "title, content and language are required" });
  const now = new Date().toISOString(); const id = randomUUID();
  const language = body.language || "zh-CN";
  const slug = body.seo?.slug || `article-${id.slice(0, 8)}`;
  const article = { id, slug, title: body.title, content: body.content, language, status: body.status || "draft", symbols: body.symbols || [], collectedAt: body.collectedAt, sourceAudit: body.sourceAudit || [], seo: body.seo || null, publishedAt: now, url: `/${language.toLowerCase()}/news/articles/${slug}` };
  articles.set(article.id, article); if (key) idempotency.set(key, article); return json(res, 201, article);
});
server.listen(port, "127.0.0.1", () => console.log(`CMS API listening on http://127.0.0.1:${port}/v1/articles`));
