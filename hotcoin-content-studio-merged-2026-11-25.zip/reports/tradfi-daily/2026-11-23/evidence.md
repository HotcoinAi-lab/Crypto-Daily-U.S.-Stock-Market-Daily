# TradFi 美股日报 · 证据台账

- 报告日期：2026-11-23（周一美股交易日）
- 生产时间：2026-11-24T18:37:00+08:00（Asia/Shanghai）
- 状态：事实底稿已齐（三条时间线 + 证据台账完整），正文为 AI 草稿，待运营复核后确认。

## 时间线证据

### EV-US-CLOSE-20261123 · 美股正式收盘
- 数据时刻：2026-11-23T16:00:00-05:00（America/New_York）
- 采集时间：2026-11-24T18:37:00+08:00
- 来源：CNBC quote-html-webservice（source=Exchange，last_time=2026-11-23）
- 来源 URL：https://www.cnbc.com/quotes/.SPX
- 数值：NASDAQ Composite 24,089.56（+6.51%）；S&P 500 7,237.17（+4.73%）；Dow Jones 49,595.31（+3.01%）；VIX 26.62

### EV-HOTCOIN-SNAP-20261124 · Hotcoin 行情快照
- 数据时刻：2026-11-24T18:37:00+08:00（Asia/Shanghai）
- 采集时间：2026-11-24T18:37:00+08:00
- 来源：Hotcoin 公开行情接口（代币化美股 B 股）
- 来源 URL：https://api.hotcoinfin.com/v1/market/ticker
- 数值：NVDA 156.50（+15.14%）；TSLA 381.55（+5.37%）；PLTR 156.25（+3.66%）；META 592.50（+1.11%）；AAPL 351.10（+0.74%）；GOOGL 280.74（+0.51%）；AMD 435.28（-2.44%）；MSFT 493.87（-1.47%）；AMZN 255.17（-0.80%）

### EV-MACRO-20261124 · 宏观事件日历
- 数据时刻：2026-11-24T18:37:00+08:00（Asia/Shanghai）
- 采集时间：2026-11-24T18:37:00+08:00
- 来源：ForexFactory 本周经济日历（中高影响）
- 来源 URL：https://www.forexfactory.com/calendar
- 事件：
  - 2026-11-24 10:00 ET · US · CB Consumer Confidence（预期 92.4，前值 91.7）
  - 2026-11-24 · AU · CPI m/m & y/y（高影响）
  - 2026-11-25 08:30 ET · US · Core PCE Price Index m/m（预期 0.3%，前值 0.3%）
  - 2026-11-25 08:30 ET · US · Prelim GDP q/q（预期 3.5%，前值 3.4%）
