# Hotcoin Research · TradFi US Equity Daily | 2026-11-23

> This draft is generated from three independently timestamped fact streams: the official US market close, a Hotcoin market snapshot, and the macro event calendar. All figures trace to the evidence ledger; operations must verify each item before delivery.

## 1. US Market Close

US equities rallied across the board on Monday, 2026-11-23, led by technology. The NASDAQ Composite closed at 24,089.56 (+6.51%), the S&P 500 at 7,237.17 (+4.73%), and the Dow Jones Industrial Average at 49,595.31 (+3.01%). The VIX closed at 26.62, edging higher and still cautious.

(Source: CNBC Exchange; as of 2026-11-23T16:00 ET)

## 2. Hotcoin Tokenized Equity Movers

The Hotcoin tokenized equity (B-share) snapshot shows a clear AI and technology theme: NVDA +15.14%, TSLA +5.37%, and PLTR +3.66% led gains, while AMD -2.44%, MSFT -1.47%, and AMZN -0.80% pulled back. Token quotes are tracked separately from the underlying shares and may deviate; tokens do not represent ownership of the underlying equity.

(Source: Hotcoin public market; snapshot 2026-11-24 Asia/Shanghai)

## 3. Macro Catalyst Calendar

- 2026-11-24 10:00 ET · US CB Consumer Confidence (forecast 92.4, prior 91.7)
- 2026-11-24 · AU CPI m/m & y/y (high impact)
- 2026-11-25 08:30 ET · US Core PCE m/m (forecast 0.3%, prior 0.3%)
- 2026-11-25 08:30 ET · US Prelim GDP q/q (forecast 3.5%, prior 3.4%)

Core PCE and preliminary GDP on Wednesday (11-25) are the key inflation and growth inputs before the Thanksgiving holiday, when trading is expected to thin out.

## 4. Key Watch Points

1. Follow-through after the outsized tech rally: a +6.51% NASDAQ session is an extreme one-day move; watch whether it holds into a quiet holiday week.
2. Hotcoin B-share vs. underlying spread: the NVDA token's +15.14% stands out; monitor the token premium and deviation from the equity benchmark.
3. Macro direction: a hotter-than-expected Core PCE could dent rate-cut expectations and amplify risk-asset volatility.

## Disclaimer

This draft is for market-information and research purposes only and does not constitute investment advice. Tokenized stocks are not equivalent to ownership of the underlying shares. Digital assets are highly volatile; assess your own risk tolerance carefully.
