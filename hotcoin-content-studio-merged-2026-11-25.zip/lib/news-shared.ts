import { fetchArticles } from "@/lib/cms-reader";
import type { Article } from "@/lib/article-store";

// KuCoin 同款结构：/{locale}/news/articles/{slug}
export function articleUrl(a: Pick<Article, "slug" | "language">) {
  return `/${(a.language || "zh-CN").toLowerCase()}/news/articles/${a.slug}`;
}

export function esc(s: string) {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}

// 所有新闻页统一经内部 HTTP 读取演示 CMS 数据（跨 worker 环境共享的唯一途径）
export function listArticles(origin: string) {
  return fetchArticles(origin);
}
