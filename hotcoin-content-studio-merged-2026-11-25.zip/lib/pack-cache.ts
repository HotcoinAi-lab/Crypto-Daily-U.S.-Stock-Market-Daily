import type { FactPack } from "./market-studio";

// 最新一次采集的事实包缓存：跨 API 路由共享（挂在 globalThis 上，隔离实例重启后清空，属 best-effort）
type PackCache = { at: number; facts: FactPack };
const KEY = "__hotcoinPackCache";

export function setPackCache(facts: FactPack) {
  (globalThis as unknown as Record<string, unknown>)[KEY] = { at: Date.now(), facts };
}

export function getPackCache(): PackCache | null {
  return ((globalThis as unknown as Record<string, unknown>)[KEY] as PackCache | undefined) ?? null;
}
