import type { GateCheck, SourceStatus } from "./report-governance";

export type TradfiTimeline = {
  asOf: string;
  timezone: string;
  sourceUrl: string;
  evidenceId: string;
};

export type TradfiDailyFactPack = {
  reportDate: string;
  usClose?: TradfiTimeline & { indices: Record<string, number>; vix?: number | null };
  hotcoinSnapshot?: TradfiTimeline & { assets: Record<string, { price: number; changePct: number }> };
  macroCalendar?: TradfiTimeline & { events: { title: string; scheduledAt: string; sourceUrl: string }[] };
  evidence?: { id: string; sourceUrl: string; retrievedAt: string; note?: string }[];
};

export type TradfiDailyPlan = {
  reportDate: string;
  requiredArtifacts: string[];
  threeTimelines: { key: string; label: string; present: boolean; asOf?: string; timezone?: string }[];
  sourceStatus: SourceStatus[];
  checks: GateCheck[];
  blockers: string[];
};

export const TRADFI_DAILY_ARTIFACTS = [
  "zh.md", "en.md", "evidence.md", "visual-data.json", "visual-data-zh.json",
  "assets/hotcoin-tradfi-daily-cover-fixed.png",
  "visuals-zh/01-market-pulse.png", "visuals-zh/02-hotcoin-asset-movers.png", "visuals-zh/03-catalyst-calendar.png",
  "visuals-en/01-market-pulse.png", "visuals-en/02-hotcoin-asset-movers.png", "visuals-en/03-catalyst-calendar.png",
];

function validTimeline(value: TradfiTimeline | undefined) {
  return Boolean(value?.asOf && value?.timezone && value?.sourceUrl && value?.evidenceId);
}

function validEvidenceRecord(item: { id: string; sourceUrl: string; retrievedAt: string; note?: string } | undefined) {
  return Boolean(item?.id && item?.sourceUrl && item?.retrievedAt);
}

// 证据采集时间不得早于对应数据时点：早于 asOf 的检索快照不能支撑当期数据。
function evidenceFreshnessOk(value: TradfiTimeline, record: { id: string; sourceUrl: string; retrievedAt: string }) {
  const asOf = Date.parse(value.asOf);
  const retrieved = Date.parse(record.retrievedAt);
  if (Number.isNaN(asOf) || Number.isNaN(retrieved)) return false;
  return retrieved >= asOf;
}

// This creates a production plan only. Rendering and prose generation remain blocked until all
// three independently timestamped evidence streams are supplied; it never invents market facts.
export function planTradfiDaily(facts: TradfiDailyFactPack): TradfiDailyPlan {
  const timelines = [
    { key: "usClose", label: "美股正式收盘", value: facts.usClose },
    { key: "hotcoinSnapshot", label: "Hotcoin 行情快照", value: facts.hotcoinSnapshot },
    { key: "macroCalendar", label: "宏观事件日历", value: facts.macroCalendar },
  ];
  const sourceStatus: SourceStatus[] = timelines.map(({ label, value }) => ({
    name: label, status: validTimeline(value) ? "ok" : "failed",
    observedAt: value?.asOf,
    detail: validTimeline(value) ? `${value!.timezone} · ${value!.sourceUrl}` : "缺少带来源、时间与证据编号的事实输入",
  }));
  const evidence = facts.evidence || [];
  const idCounts = new Map<string, number>();
  for (const item of evidence) idCounts.set(item.id, (idCounts.get(item.id) || 0) + 1);
  const duplicateIds = [...idCounts.entries()].filter(([, n]) => n > 1).map(([id]) => id);
  const allEvidenceIntact = evidence.every(validEvidenceRecord);
  const evidenceById = new Map<string, boolean>();
  for (const item of evidence) evidenceById.set(item.id, evidenceById.has(item.id) ? false : validEvidenceRecord(item));
  const evidenceLinked = timelines.every(({ value }) =>
    validTimeline(value) && evidenceById.get(value!.evidenceId) === true
  );
  const evidenceMap = new Map(evidence.map(item => [item.id, item] as const));
  const staleEvidence = timelines.filter(({ label, value }) => {
    if (!validTimeline(value) || evidenceById.get(value!.evidenceId) !== true) return false;
    return !evidenceFreshnessOk(value!, evidenceMap.get(value!.evidenceId)!);
  });
  const checks: GateCheck[] = [
    { id: "daily-date", label: "日报归档日期", passed: /^\d{4}-\d{2}-\d{2}$/.test(facts.reportDate), severity: "blocker", detail: facts.reportDate || "未填写" },
    { id: "daily-three-timelines", label: "三条独立时间线", passed: timelines.every(({ value }) => validTimeline(value)), severity: "blocker", detail: timelines.filter(({ value }) => !validTimeline(value)).map(({ label }) => label).join("、") || "均已提供" },
    { id: "daily-evidence-integrity", label: "证据台账完整性", passed: allEvidenceIntact && duplicateIds.length === 0, severity: "blocker", detail: duplicateIds.length ? `证据编号重复：${duplicateIds.join("、")}` : allEvidenceIntact ? "每条证据均有来源、采集时间且编号唯一" : "存在缺少来源或采集时间的证据记录" },
    { id: "daily-evidence-links", label: "证据台账关联", passed: evidenceLinked, severity: "blocker", detail: evidenceLinked ? "每条时间线均能回溯完整证据记录" : "至少一条时间线引用缺失、不完整或未登记的证据" },
    { id: "daily-evidence-freshness", label: "证据采集时效", passed: staleEvidence.length === 0, severity: "blocker", detail: staleEvidence.length ? `证据采集时间早于数据时点：${staleEvidence.map(({ label }) => label).join("、")}` : "每条证据均在对应数据时点之后采集" },
    { id: "daily-output-contract", label: "固定交付契约", passed: true, severity: "blocker", detail: "中英正文、双语各三图、封面、绘图 JSON 与 evidence.md" },
  ];
  const blockers = checks.filter(check => check.severity === "blocker" && !check.passed).map(check => check.label);
  return {
    reportDate: facts.reportDate, requiredArtifacts: TRADFI_DAILY_ARTIFACTS,
    threeTimelines: timelines.map(({ key, label, value }) => ({ key, label, present: validTimeline(value), asOf: value?.asOf, timezone: value?.timezone })),
    sourceStatus, checks, blockers,
  };
}
