import type { FaqItem } from "@/lib/seo";

// 演示用文章库：模块级内存存储，worker 实例重启即清空；接正式 CMS 时替换为数据库
export type Article = {
  id: string;
  slug: string;
  title: string;
  content: string;
  language: string;
  status: string;
  symbols: string[];
  publishedAt: string;
  collectedAt?: string;
  metaTitle?: string;
  metaDescription?: string;
  keywords?: string[];
  faq?: FaqItem[];
  sourceAudit?: unknown[];
};

const byId = new Map<string, Article>();
const idBySlug = new Map<string, string>();

// 以 slug 为稳定标识写入：同 slug 覆盖旧文（同日重发 URL 不变），返回被替换的旧文
export function upsertBySlug(article: Article): Article | undefined {
  const oldId = idBySlug.get(article.slug);
  const replaced = oldId ? byId.get(oldId) : undefined;
  if (oldId) byId.delete(oldId);
  byId.set(article.id, article);
  idBySlug.set(article.slug, article.id);
  return replaced;
}

export function getArticleById(id: string) {
  return byId.get(id);
}

export function getArticleBySlug(slug: string) {
  const id = idBySlug.get(slug);
  return id ? byId.get(id) : undefined;
}

export function listArticles() {
  return [...byId.values()].sort((a, b) => +new Date(b.publishedAt) - +new Date(a.publishedAt));
}

// KuCoin 同款结构：/{locale}/news/articles/{slug}
export function articleUrl(a: Pick<Article, "slug" | "language">) {
  return `/${(a.language || "zh-CN").toLowerCase()}/news/articles/${a.slug}`;
}
