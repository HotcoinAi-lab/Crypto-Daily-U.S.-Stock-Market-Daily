import type { FactPack, EtfFlow } from "./market-studio";

// 服务端 SVG 图表生成器：无需浏览器渲染，输出 1200×630 图片供报告嵌入
const W = 1200;
const H = 630;
const GREEN = "#73f2a7";
const GREEN_D = "#4ed68f";
const RED = "#f87171";
const RED_D = "#c9564f";
const YELLOW = "#fbbf24";
const INK = "#eef5ef";
const GRAY = "#8fa396";
const GRAY2 = "#6d7f74";

function esc(s: string) {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}

function headerDefs() {
  return `<defs>
    <linearGradient id="bg" x1="0" y1="0" x2="0.6" y2="1">
      <stop offset="0" stop-color="#07100c"/><stop offset="0.6" stop-color="#0a1410"/><stop offset="1" stop-color="#0c1a13"/>
    </linearGradient>
    <linearGradient id="gpos" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stop-color="#8df5bc"/><stop offset="1" stop-color="${GREEN_D}"/>
    </linearGradient>
    <linearGradient id="gneg" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stop-color="${RED}"/><stop offset="1" stop-color="${RED_D}"/>
    </linearGradient>
  </defs>
  <rect width="${W}" height="${H}" fill="url(#bg)"/>`;
}

function brand(title: string, badge: string) {
  return `<image x="56" y="42" width="40" height="40" href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMAAAADACAYAAABS3GwHAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAwOSURBVHgB7Z1PbFxXGcXPxFAFUcREQiRFQX4uQa1A1YxhQRa0cVQJwoa4C5DYYHfZRZWwQbCyu0AVq6gSW7CzQUQVisOmlI1ttRLtBo+phBIlqp9LpDpVW09okJx2MdzvzTwzmcyM33hm3rvfd89POhqPPY7vTM65/999JRRP2anaUqXtuRCBWCB2qrdUc9puPdZa3yuMEvInNfh5p1nQ5KGTBuGa0woMM+O05LTr1KCoLhJvLKHpFRNIbb8Amp4aXFtO81DaQ6DxqVFpC00vRVDCBdD41Oi1hWaL4C0ysF2Frg+V0qcteNgaSK2v5QOkbGgBHhCBtT5VnFYxZGswzDqAdHmugvP4pFhip7Otx4E5gsMhC1hDp4+QERA5baDpyVyYg65mkgpHcxiQCQyG/IFlEOIn0grETptZf2GQMYD841dBiP88h4z7irIGIEKzn1UGIf4jO0xlYFw76IVZBsERmgNemp9oQbyaaYYySwsg5p8BIfpYQ7Ml6MlBg+AFeL7/gpA+RE53nd7q9YLSAb+8BUL0M40e44F+Y4BVEGKDS71+0KsLNA92fYgdIvToCpV6vHgV3OZAbCFTo1PouAi/WxdIVnsjEGILmRq92PnNzhYgAmt/YpeHWoHOFmAGND+xy0OtQGcLINOeEQixi9T+x9In7S3ADGh+Yh9pBWbSJ+0BGHgvNSFK2fd6exdIjjLhhjcSAvuD4bQFkL3+ND8Jhf0DmNMAnAchYZFcQ5wGoApCwiKp9GUMIM3BLggJj2PSArD2J6FSZQBIyCQBiEBImFQkABUQEibJGIDz/yRUKgwA2adcLmN2NrcjNr2hQVFRFDU2NjYawsLCgqqyDylVhc2kubm50P4Th5Kr9Ru7u7uNdgL6/FQV9kCJ+VOkRpOaTVP585YYvReBhEBVYfuq3fwpW1tbjZmZGVXvIw+5/n5jdXW1cRABhEBVYXuqm/kDrM0yqVqtJhVDVox/dqoK21UHmT9laWkpqfk0vbdR68KFCw/19wMPgarCPqSs5k+Rmi/EcYEE/+rVq41hMBoCVYV9QIOaP4D/zK6SMdAgXZ7APjdVhd3XMOZPkUGg5dZAav1Lly41Ro2xEKgqbKJRmD9F+sMWW4NR1vrdMPSZqSrsSM3fjphlfn5e1WfRTdKiDdvXz4qREOgp7LjM347WIEh3Rwx5mBmeYTAQAh0FzcP87aRB8H3atCjjt6M8BP4XMm/ztyPGkvUD31aTpTwywC3S+O0oDoHfBSzS/J1IqyBhkM1jRcweSW1/8eLFTFsYikBjCEppCnxlcXER7oOFj9RqtUTr6+v7X48S2Z9frVZx5swZuBo/kc/I+5+enoYmvA+A4HMIOhET1Ov15HF7extxHCfPU8nzdsTkqcTs8lipVJKvXSuTPNeAvN+zZ88m71EbKpoqF4IG8RPZdq51j5XcJG8RClhbW0OpVPK+GxAammt+QU0ABAmBdCskBEePHgUpFu3mF1SMATqR/rFb7Uz6yKQYLJhfUBkAQczvpgMZggKwYn7hCJQisyky5baysgKSH5bML6gaA3Syt7eHK1eucHCcE9bMn6Jmyqqfxr39N3Q0T3UeIFWF7SvZnrC8vNwgo8Ww+W0FIJXsl/Flk5h2jJvfZgBEeV4YYpUAzG83AKlkTz/HBoMTiPntB0AkrQH3EmUnIPOHEYD2IHCQ3J/AzB9WABiE/gRo/jAD0BkEzhgFa/6wA9AehJAHywGbnwHolJycLK1CKGEI3Pz+XxNcJOl1uOk1udawurdnEBiAjKTX7KaBSK/f1QrN34QBGII0FHJNgmhycnL/+oR+1ymI6Yq84J3mfxA1/TUr6ndfLvb5c5eqwqoXze+dVBVWtWh+L6WqsGpF83srVYVVKZrfa6kqrDrR/N5LVWFVieZXIVWFVSOaX41UFVaFaH5VUlVY70Xzq5Oqwnotml+lVBXWW9H8aqWqsF6K5lctVYX1TjS/eqkqrFei+U1IVWG9Ec1vRqoK64VoflNSVdjCRfObk6rCFiqa36RUFbYw0fxmpaqwhYjmNy1Vhc1dNL95qSpsrqL5g5CqwuYmmj8YqSpsLqL5g5Kqwo5dNH9wUlXYsYrmD1KqCjs20fzBSlVhxyKaP1x9DoHjzI/FxUUUwbhPaT76pUdw4tQxHHc6caqMo48+kiilvnMPO7fquHNrF/HGHYRI0MejWzV/NH0cZ+afwvFvHnOG/3ym39m79xluvHEbm399N6gwBBsAi+av/OhxnHn+KZRPfBHDUN/5L9aX3sHma+/COkEGwJr5y489ivO/Oo3J6a9ilGy+toX15XdQf/8erBJcAKyZ//RPnsQzrtbP2tUZFGkN/vLyW2a7RUEFwJr5pbsjygMJQc1gl2jCaREBQPMPxxNPn8Rd1xrsuBkjSxxBAFjs9uRp/pQf//o0TriZJUuYD4DFAe8PXvwOiuKnv3nmgbUE7ZgOgMWpzp+/8iyKRKZYf/jid2EFswGwOs8/7Bz/aMoxlSy2WcBkAKyu8BbR7++FrDRbwFwArJrfl9o/RRbdLLQCpgJgeWNb9dzj8I0nvn8S2jETANO7Ot2sy6i3OYwCWRvQjokAWDa/4Ovcu3TJfOqWHQb1AbBufmGy6l/tnzKpfBygOgAhmF+Qi1p8hS1AQYRifsHnlVcGoABCMj8ZL+oCQPOTUaIqADS/f8i1xJpRE4CQzS+nN/jK3r1PoRkVAQi95r9zy99Wx+eyZcH7ALDbA6+vwtq5+TE043UAaP4mOzd3cd/Dvvadm/XkonnNeBuA2dlZmr+F9LMlBL4R1/SfFOFtAFZWVnD58mXkja+zPXI+j2+8/ep1aMfrLtD8/HyuIfB5qlPO5bn7vj/dDTk1Tnv3R/B+EJxXCDTM87/+u3/AF+ToRAuomAYddwi0LHJdf+Pf2N74AEXz9qs3TNT+gpqFsHGFQNsK77WX/17ojJB0w9aX/gkrqDoZTgbGU1NTqFarGAUatzfI1oOP3vsE3352Enlz/5PP8PsXXse9j/dgBXVHI44qBJr39nz43n9cK/ApvvG9ryFP/vDC35K/bQmVZ4MOGwILG9tu/+uj5DGPkxmk5v/jL9fc3/wQ1lB7OO5hQ2BpV+d27YNkL87Jb30luR3SOJA+v3R7rB2Km6L6dOhBQ2BxS7N0SW68eTu5amzUF8/LbM+fX3rTVJ+/ExP3B1heXsbc3Fzf14Swn//Jp7/eujdYGcMgU62y8hzCvcLM3CCjXwhCu5hFxgWVc1OIqsfx5ceyXbNbd10duUGetCY+7jsaF6buENMtBKFfySXdovKJR3H8VPmhC9hlMUu0XbuTBCBUvL2J8WHkQsCbUFOZZe5G2bJiLFQqFV7DSw7E7E3yXM1P85MDCfpO8YQEcZM8QnrBAJCgYQBI0EgAYhASJjFbABIydQlADYSESRKAuyAkTDbZApCQiRkAEjI1WQmWzePh7H8l5P8ckxZANszEICQspOdTT6dBr4GQsEi6/mkAVkBIWCSVfqn1RMYBW61HQqwj3f7kBIEjbd9gN4iEwn6Pp30rxDIICYP9Q2ZLHT+Q6VB2g4hlYqep9MlExw+/4DQDQuzyC7Qt/na2ABwME8vETmfRtu7VuR1aBsOvgBCbSN8/bv9GqcuL2AoQi8ToqP2FiS4vlJNQ7zudAyF2kL7/Wuc3S31+YRUcEBMbxGib+WmnXwDkzPENEKIfMX/c7QcTfX5pB82rxdgVIpp5CX32uvVrAVLYFSJaWUNz4NuTLAGI0AxBBEL0EKPLrE8nWQIgyHhAQsCpUaIBWc+aRoYLvbKeCyRLx8+DEB2IV+MsL5xAdq47bTvNghB/EfP/KeuLBwmAIC0BQ0B8Rcy/jByQAMjWaa9ud0MFK/HioSrlrIPgbkTg7BApntjpORzyfKthDseN0ZxmWgMhxbCGpgcLP9xtEbqaTEq/LsIzIjS3UWv5ACmdWkVzXcpb5sEgUKOXDHRHXusPOg2aBemPyRErspEuAlePyXDIqu5vnX4GhePNCGwRqMNJavxFGKpAZ9BcpOD6AdVL4o0l5Lj7eJh1gGGYbakCzwc0ZOzEaHaZZc9+cmIzcqSoALQjTVy1pQjNUJRbikAsELceU4Nvtr7O3fCd/A/q2yUa+4t9/QAAAABJRU5ErkJggg=="/>
  <text x="108" y="68" fill="#dceadf" font-size="19" font-weight="700" letter-spacing="1">Hotcoin</text>
  <text x="196" y="68" fill="${INK}" font-size="24" font-weight="800">${esc(title)}</text>
  <rect x="${W - 56 - 200}" y="46" width="200" height="34" rx="17" fill="rgba(115,242,167,0.07)" stroke="rgba(115,242,167,0.35)"/>
  <text x="${W - 56 - 100}" y="68" fill="${GREEN}" font-size="15" text-anchor="middle" letter-spacing="1">${esc(badge)}</text>`;
}

function footer(left: string, right: string) {
  return `<text x="56" y="${H - 28}" fill="${GRAY2}" font-size="13">${esc(left)}</text>
  <text x="${W - 56}" y="${H - 28}" fill="${GRAY2}" font-size="13" text-anchor="end">${esc(right)}</text>`;
}

function fmtUsd(v: number) {
  return "$" + v.toLocaleString("en-US", { maximumFractionDigits: v < 1 ? 4 : 2 });
}

function fmtPct(v: number) {
  return (v >= 0 ? "+" : "") + v.toFixed(2) + "%";
}

function fmtFlowM(v: number) {
  return (v < 0 ? "净流出 $" : "净流入 $") + (Math.abs(v) / 100).toFixed(2) + " 亿";
}

/** 市场概览图卡：六币行情 + ETF 资金流 + 恐贪指数 + 待接入数据源 */
export function overviewSvg(facts: FactPack): string {
  const day = new Date(facts.collectedAt);
  const dateBadge = `${day.getFullYear()}年${day.getMonth() + 1}月${day.getDate()}日`;
  const etf = facts.etfFlows?.find((f) => f.asset === "BTC");
  const fng = facts.indicators?.fearGreed;
  const fngZh = fng ? { "extreme fear": "极度恐惧", fear: "恐惧", neutral: "中性", greed: "贪婪", "extreme greed": "极度贪婪" }[fng.label.toLowerCase()] || fng.label : "";
  const up = fng && fng.value >= 55;
  const tiles = facts.tickers.map((t, i) => {
    const col = i % 2, row = Math.floor(i / 2);
    const x = 56 + col * 322, y = 118 + row * 88;
    const cls = t.change24h >= 0 ? "up" : "down";
    return `<rect x="${x}" y="${y}" width="310" height="74" rx="12" fill="rgba(255,255,255,0.035)" stroke="rgba(255,255,255,0.09)"/>
    <text x="${x + 16}" y="${y + 24}" fill="${GRAY}" font-size="14">${esc(t.symbol)}</text>
    <text x="${x + 16}" y="${y + 54}" fill="${INK}" font-size="23" font-weight="700">${fmtUsd(t.price)}<tspan fill="${cls === "up" ? GREEN : RED}" font-size="15" font-weight="600" dx="8">${fmtPct(t.change24h)}</tspan></text>`;
  }).join("\n  ");
  const fngDot = 762 + (fng ? Math.max(4, Math.min(96, fng.value)) : 50) / 100 * 352 - 6;
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" font-family="'Microsoft YaHei','PingFang SC',system-ui,sans-serif">
  ${headerDefs()}
  ${brand("市场概览", dateBadge)}
  ${tiles}
  <rect x="740" y="118" width="404" height="92" rx="12" fill="rgba(255,255,255,0.035)" stroke="rgba(255,255,255,0.09)"/>
  <text x="756" y="142" fill="${GRAY}" font-size="13.5">BTC 现货 ETF 净流入 · ${etf ? etf.asOf : "—"}</text>
  ${etf ? `<text x="756" y="174" fill="${etf.dailyFlow >= 0 ? GREEN : RED}" font-size="22" font-weight="700">${fmtFlowM(etf.dailyFlow)}</text>
  <text x="756" y="196" fill="#71857a" font-size="12.5">连续 ${etf.streakDays} 天同向；周内合计 ${fmtFlowM(etf.weekFlow)}</text>` : `<text x="756" y="170" fill="#71857a" font-size="14">ETF 数据待接入</text>`}
  <rect x="740" y="222" width="404" height="92" rx="12" fill="rgba(255,255,255,0.035)" stroke="rgba(255,255,255,0.09)"/>
  <text x="756" y="246" fill="${GRAY}" font-size="13.5">恐惧与贪婪指数</text>
  ${fng ? `<text x="756" y="282" fill="${up ? GREEN : YELLOW}" font-size="22" font-weight="700">${fng.value}<tspan fill="${up ? GREEN : YELLOW}" font-size="15" font-weight="600" dx="8">${fngZh}</tspan></text>
  <rect x="756" y="292" width="352" height="6" rx="3" fill="url(#gneg)"/>
  <rect x="756" y="292" width="${352 * 0.5}" height="6" rx="3" fill="url(#gpos)" opacity="0"/>
  <circle cx="${fngDot}" cy="295" r="6" fill="${up ? GREEN : YELLOW}" stroke="#0b1310" stroke-width="3"/>` : ""}
  <rect x="740" y="326" width="404" height="110" rx="12" fill="rgba(255,255,255,0.035)" stroke="rgba(255,255,255,0.09)"/>
  <text x="756" y="350" fill="${GRAY}" font-size="13.5">待接入数据源</text>
  <rect x="756" y="360" width="178" height="30" rx="8" fill="none" stroke="rgba(255,255,255,0.14)" stroke-dasharray="4 3"/>
  <text x="764" y="380" fill="#71857a" font-size="12.5">总市值 / BTC 占比 —</text>
  <rect x="944" y="360" width="178" height="30" rx="8" fill="none" stroke="rgba(255,255,255,0.14)" stroke-dasharray="4 3"/>
  <text x="952" y="380" fill="#71857a" font-size="12.5">24h 爆仓 —</text>
  <rect x="756" y="396" width="178" height="30" rx="8" fill="none" stroke="rgba(255,255,255,0.14)" stroke-dasharray="4 3"/>
  <text x="764" y="416" fill="#71857a" font-size="12.5">资金费率 —</text>
  <rect x="944" y="396" width="178" height="30" rx="8" fill="none" stroke="rgba(255,255,255,0.14)" stroke-dasharray="4 3"/>
  <text x="952" y="416" fill="#71857a" font-size="12.5">美股与加密概念股 —</text>
  ${footer(`数据截至 ${new Date(facts.collectedAt).toISOString().slice(0, 16).replace("T", " ")} UTC · 来源：Binance/Gate、Farside、CNBC、alternative.me`, "本图仅为市场资讯，不构成投资建议")}
</svg>`;
}

/** BTC 现货 ETF 资金流：近 30 个交易日净流入零轴柱状图 */
export function etfFlowSvg(facts: FactPack): string {
  const etf = facts.etfFlows?.find((f) => f.asset === "BTC");
  const daily = (etf?.daily || []).slice(-30);
  if (!daily.length) {
    return `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}"><rect width="${W}" height="${H}" fill="#0a1410"/><text x="${W / 2}" y="${H / 2}" fill="${GRAY}" font-size="16" text-anchor="middle">暂无 ETF 资金流数据，请先执行采集</text></svg>`;
  }
  const maxAbs = Math.max(...daily.map((d) => Math.abs(d.flow)), 1);
  const x0 = 60, x1 = W - 40;
  const colW = (x1 - x0) / daily.length;
  const barW = Math.min(26, colW * 0.55);
  const midY = 330, halfH = 165;
  // 标注规则：绝对值前 9 名 + 最新一天，共 10 个
  const ranked = [...daily].map((d, i) => ({ v: d.flow, i })).sort((a, b) => Math.abs(b.v) - Math.abs(a.v)).slice(0, 9).map((x) => x.i);
  const show = new Set(ranked.concat([daily.length - 1]));
  const bars = daily.map((d, i) => {
    const cx = x0 + colW * (i + 0.5);
    const h = Math.max(3, Math.round(Math.abs(d.flow) / maxAbs * halfH));
    const cls = d.flow >= 0 ? "pos" : "neg";
    const pvY = d.flow >= 0 ? midY - h - 6 : midY + h + 16;
    const pv = show.has(i) ? `<text x="${cx}" y="${pvY}" fill="${INK}" font-size="12" font-weight="700" text-anchor="middle" paint-order="stroke" stroke="rgba(7,16,12,0.85)" stroke-width="3">${d.flow > 0 ? "+" : ""}${d.flow}</text>` : "";
    const dl = i % 5 === 1 || i === daily.length - 1 ? `<text x="${cx}" y="${midY + halfH + 26}" fill="${GRAY}" font-size="11" text-anchor="middle">${d.date.slice(5)}</text>` : "";
    return `<rect x="${cx - barW / 2}" y="${d.flow >= 0 ? midY - h : midY}" width="${barW}" height="${h}" rx="2" fill="url(#g${cls})"/>${pv}${dl}`;
  }).join("\n  ");
  const asOf = daily[daily.length - 1].date;
  const sum = daily.reduce((s, d) => s + d.flow, 0);
  const sumTxt = `近 ${daily.length} 个交易日合计 ${sum >= 0 ? "+" : "-"}$${Math.abs(sum).toFixed(0)}M；最新一日（${asOf}）${fmtFlowM(daily[daily.length - 1].flow)}`;
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" font-family="'Microsoft YaHei','PingFang SC',system-ui,sans-serif">
  ${headerDefs()}
  ${brand("BTC 现货 ETF 资金流 · 近 " + daily.length + " 个交易日", "截至 " + asOf.slice(5) + " · $M")}
  <text x="56" y="140" fill="#9db3a4" font-size="16.5">以零轴为界（流入向上、流出向下）；关键柱标注数值（前 9 + 最新）</text>
  <line x1="56" y1="${midY}" x2="${W - 44}" y2="${midY}" stroke="rgba(255,255,255,0.28)" stroke-dasharray="5 4"/>
  <text x="44" y="${midY + 4}" fill="${GRAY2}" font-size="12" text-anchor="end">0</text>
  ${bars}
  ${footer(sumTxt, "来源：CoinGlass / Farside")}
</svg>`;
}
