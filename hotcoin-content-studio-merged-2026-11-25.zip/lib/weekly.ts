import type { FactPack } from "./market-studio";
import type { ReportWindow, SourceStatus } from "./report-governance";

// 《每周洞察》底稿采集器：并行聚合各数据源为 docx 规格所需底稿 JSON
// 无可靠数据源的字段保持 null（AI 生成时标注「待人工核实」，不编造）
const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36";

async function jget(url: string, ms = 9000) {
  const c = new AbortController();
  const timer = setTimeout(() => c.abort(), ms);
  try {
    const r = await fetch(url, { signal: c.signal, headers: { "user-agent": UA, accept: "application/json" }, cache: "no-store" });
    if (!r.ok) throw new Error(`HTTP ${r.status}`);
    return await r.json();
  } finally { clearTimeout(timer); }
}

// Binance 日 K 线 → RSI14（Wilder 平滑）
function calcRsi(closes: number[], period = 14): number | null {
  if (closes.length < period + 1) return null;
  let gain = 0, loss = 0;
  for (let i = 1; i <= period; i++) {
    const d = closes[i] - closes[i - 1];
    if (d >= 0) gain += d; else loss -= d;
  }
  let avgG = gain / period, avgL = loss / period;
  for (let i = period + 1; i < closes.length; i++) {
    const d = closes[i] - closes[i - 1];
    avgG = (avgG * (period - 1) + Math.max(d, 0)) / period;
    avgL = (avgL * (period - 1) + Math.max(-d, 0)) / period;
  }
  if (avgL === 0) return 100;
  const rs = avgG / avgL;
  return Math.round((100 - 100 / (1 + rs)) * 10) / 10;
}

export type WeeklyDraft = {
  collectedAt: string;
  reportWindow: ReportWindow;
  sourceStatus: SourceStatus[];
  global: { total_market_cap_usd_tn: number | null; btc_dominance_pct: number | null; btc_market_cap_usd_tn: number | null; mcap_change_24h_pct: number | null; source: string };
  defillama: { stablecoins: { total_usd_bn: number | null; usdt_share_pct: number | null }; tvl: { total_usd_bn: number | null; chg_7d_pct: number | null } };
  coins_7d: { sym: string; price: number; chg_7d_pct: number; chg_24h_pct: number | null; source: string }[];
  rsi14: { sym: string; value: number | null; state: string };
  funding: { sym: string; avg_8h_pct: number; annualized_pct: number; state: string }[];
  open_interest: { sym: string; oi_value_usd_bn: number | null; chg_7d_pct: number | null }[];
  etf: { asset: string; asOf: string; dailyFlow: number | null; weekFlow: number | null; streakDays: number | null; daily: { date: string; flow: number }[] } | null;
  hot_coin: { sym: string; chg_pct: number } | null;
};

function fundState(a: number) { return a >= 0.0003 ? "偏热" : a <= -0.0002 ? "偏冷" : "中性"; }
function rsiState(v: number | null) { return v === null ? "待核实" : v > 70 ? "超买" : v < 30 ? "超卖" : "中性"; }

export async function collectWeeklyDraft(facts: FactPack | null, reportWindow: ReportWindow): Promise<WeeklyDraft> {
  const collectedAt = new Date().toISOString();
  const startMs = new Date(reportWindow.start).getTime();
  const endMs = new Date(reportWindow.end).getTime();
  const sourceStatus: SourceStatus[] = [];

  // 全部数据源并行采集；单源失败不阻断（9 秒超时兜底）
  const binanceK = async (sym: string) => {
    const j = await jget(`https://data-api.binance.vision/api/v3/klines?symbol=${sym}USDT&interval=1d&startTime=${startMs}&endTime=${endMs}`) as unknown[][];
    // 周报窗口为北京时间周一至周六，完整窗口应有 6 根日 K。
    if (j.length < 6) throw new Error("周一至周六 K 线不足 6 根");
    return { price: Number(j[j.length - 1][4]), chg_7d_pct: Math.round((Number(j[j.length - 1][4]) / Number(j[0][1]) - 1) * 10000) / 100 };
  };
  const gateK = async (pair: string) => {
    const j = await jget(`https://api.gateio.ws/api/v4/spot/candlesticks?currency_pair=${pair}&interval=1d&from=${Math.floor(startMs / 1000)}&to=${Math.floor(endMs / 1000)}`);
    if (!Array.isArray(j) || j.length < 6) throw new Error("周一至周六 K 线不足 6 根");
    const candles = j.map((c: any) => ({ timestamp: Number(c.timestamp ?? c[0]) * (Number(c.timestamp ?? c[0]) < 1e12 ? 1000 : 1), close: Number(c.close ?? c[2]), open: Number(c.open ?? c[5]) })).sort((a, b) => a.timestamp - b.timestamp);
    if (!candles.every(c => Number.isFinite(c.close) && Number.isFinite(c.open))) throw new Error("K 线数据异常");
    return { price: candles[candles.length - 1].close, chg_7d_pct: Math.round((candles[candles.length - 1].close / candles[0].open - 1) * 10000) / 100 };
  };
  const gateContract = async (pair: string) => {
    const j = await jget(`https://api.gateio.ws/api/v4/futures/usdt/contracts/${pair}`) as { funding_rate_indicative?: string; position_size?: string; quanto_multiplier?: string; mark_price?: string };
    const size = Number(j.position_size || 0), mult = Number(j.quanto_multiplier || 0), px = Number(j.mark_price || 0);
    // OI 美元值 = 张数 × 每张合约数量 × 标记价
    return { r8: Number(j.funding_rate_indicative || 0), oiUsd: size * mult * px };
  };

  const coins: WeeklyDraft["coins_7d"] = [];
  const funding: WeeklyDraft["funding"] = [];
  const oi: WeeklyDraft["open_interest"] = [];
  let rsiBtc: number | null = null;
  let stTotal: number | null = null, stUsdtShare: number | null = null;
  let tvlNow: number | null = null, tvlChg: number | null = null;
  let mcapTn: number | null = null, btcDom: number | null = null, mcapChg: number | null = null;

  // 各源独立并行
  const results = await Promise.allSettled([
    binanceK("BTC").then(r => coins.push({ sym: "BTC", ...r, chg_24h_pct: null, source: "Binance 现货日K" })),
    binanceK("ETH").then(r => coins.push({ sym: "ETH", ...r, chg_24h_pct: null, source: "Binance 现货日K" })),
    binanceK("SOL").then(r => coins.push({ sym: "SOL", ...r, chg_24h_pct: null, source: "Binance 现货日K" })),
    // HYPE：K 线失败保留空值；不得用 24h 涨跌填充 7 日字段。
    gateK("HYPE_USDT").then(r => coins.push({ sym: "HYPE", ...r, chg_24h_pct: null, source: "Gate 现货日K" })).catch(e => { sourceStatus.push({ name: "Gate HYPE K线", status: "failed", detail: e instanceof Error ? e.message : "采集失败" }); }),
    jget("https://data-api.binance.vision/api/v3/klines?symbol=BTCUSDT&interval=1d&limit=30").then((j: unknown[][]) => { rsiBtc = calcRsi(j.map(k => Number(k[4]))); }),
    // 全市场总市值与 BTC 占比（Coinlore 免费免 key；CoinGecko 不可达的替代源）
    jget("https://api.coinlore.net/api/global/").then((j: { total_mcap: string; btc_d: string; mcap_change: string }[]) => {
      const g = j[0];
      mcapTn = Math.round(Number(g.total_mcap) / 1e12 * 100) / 100;
      btcDom = Number(g.btc_d);
      mcapChg = Number(g.mcap_change);
    }),
    gateContract("BTC_USDT").then(r => { funding.push({ sym: "BTC", avg_8h_pct: r.r8, annualized_pct: Math.round(r.r8 * 3 * 365 * 10000) / 100, state: fundState(r.r8) }); oi.push({ sym: "BTC", oi_value_usd_bn: Math.round(r.oiUsd / 1e9 * 100) / 100, chg_7d_pct: null }); }),
    gateContract("ETH_USDT").then(r => { funding.push({ sym: "ETH", avg_8h_pct: r.r8, annualized_pct: Math.round(r.r8 * 3 * 365 * 10000) / 100, state: fundState(r.r8) }); oi.push({ sym: "ETH", oi_value_usd_bn: Math.round(r.oiUsd / 1e9 * 100) / 100, chg_7d_pct: null }); }),
    gateContract("SOL_USDT").then(r => { funding.push({ sym: "SOL", avg_8h_pct: r.r8, annualized_pct: Math.round(r.r8 * 3 * 365 * 10000) / 100, state: fundState(r.r8) }); oi.push({ sym: "SOL", oi_value_usd_bn: Math.round(r.oiUsd / 1e9 * 100) / 100, chg_7d_pct: null }); }),
    gateContract("HYPE_USDT").then(r => { funding.push({ sym: "HYPE", avg_8h_pct: r.r8, annualized_pct: Math.round(r.r8 * 3 * 365 * 10000) / 100, state: fundState(r.r8) }); oi.push({ sym: "HYPE", oi_value_usd_bn: Math.round(r.oiUsd / 1e9 * 100) / 100, chg_7d_pct: null }); }),
    jget("https://stablecoins.llama.fi/stablecoins?includePrices=false").then((j: { peggedAssets?: { circulating?: Record<string, number>; symbol?: string }[] }) => {
      let total = 0, usdt = 0;
      for (const a of j.peggedAssets || []) { const c = a.circulating?.peggedUSD || 0; total += c; if (a.symbol === "USDT") usdt = c; }
      if (total > 0) { stTotal = Math.round(total / 1e9 * 100) / 100; stUsdtShare = Math.round(usdt / total * 1000) / 10; }
    }),
    jget("https://api.llama.fi/v2/historicalChainTvl").then((j: { date: number; tvl: number }[]) => {
      const withinWindow = Array.isArray(j) ? j.filter(p => p.date * 1000 >= startMs && p.date * 1000 <= endMs).sort((a, b) => a.date - b.date) : [];
      if (withinWindow.length >= 2) { tvlNow = withinWindow[withinWindow.length - 1].tvl; const prev = withinWindow[0].tvl; tvlChg = Math.round((tvlNow / prev - 1) * 10000) / 100; }
    }),
  ]);

  // 24h 涨跌从既有事实包补齐（BTC/ETH/SOL）
  if (facts) for (const c of coins) {
    const t = facts.tickers.find(t => t.symbol === c.sym);
    if (t) c.chg_24h_pct = Math.round(t.change24h * 100) / 100;
  }

  // ETF 资金流摘要取自已采集事实包
  const etfBtc = facts?.etfFlows?.find(f => f.asset === "BTC") || null;
  const etfInWindow = etfBtc && Number.isFinite(Date.parse(etfBtc.asOf)) && Date.parse(etfBtc.asOf + "T23:59:59.999Z") <= endMs;
  if (etfBtc && etfInWindow) sourceStatus.push({ name: "Farside ETF", status: "ok", observedAt: etfBtc.asOf, sourceUrl: "https://farside.co.uk/btc/", usage: "verified_fact" });
  else sourceStatus.push({ name: "Farside ETF", status: "failed", detail: etfBtc ? "ETF 数据日期超出报告窗口" : "本次事实包未提供 BTC ETF 流向", sourceUrl: "https://farside.co.uk/btc/", usage: "verified_fact" });
  for (const [index, result] of results.entries()) if (result.status === "rejected") sourceStatus.push({ name: "采集任务 " + (index + 1), status: "failed", detail: result.reason instanceof Error ? result.reason.message : "采集失败" });
  if (!sourceStatus.some(s => s.name === "Binance K线")) sourceStatus.push({ name: "Binance K线", status: coins.filter(c => ["BTC", "ETH", "SOL"].includes(c.sym)).length === 3 ? "ok" : "partial", sourceUrl: "https://data-api.binance.vision/api/v3/klines", usage: "verified_fact" });
  if (!sourceStatus.some(s => s.name === "Gate HYPE K线")) sourceStatus.push({ name: "Gate HYPE K线", status: coins.some(c => c.sym === "HYPE") ? "ok" : "failed", sourceUrl: "https://api.gateio.ws/api/v4/spot/candlesticks", usage: "verified_fact" });
  sourceStatus.push(
    { name: "Binance BTC RSI", status: rsiBtc === null ? "failed" : "ok", sourceUrl: "https://data-api.binance.vision/api/v3/klines", usage: "verified_fact", detail: "近 30 根 BTC 日 K，本地计算 RSI14" },
    { name: "Coinlore 全市场快照", status: mcapTn === null ? "failed" : "ok", sourceUrl: "https://api.coinlore.net/api/global/", usage: "verified_fact", detail: "运行时快照；不作为周度变化替代" },
    { name: "Gate 衍生品快照", status: funding.length === 4 && oi.length === 4 ? "ok" : "partial", sourceUrl: "https://api.gateio.ws/api/v4/futures/usdt/contracts/", usage: "verified_fact", detail: "运行时 funding/OI 快照；OI 7 日变化保持 null" },
    { name: "DefiLlama 稳定币", status: stTotal === null ? "failed" : "ok", sourceUrl: "https://stablecoins.llama.fi/stablecoins?includePrices=false", usage: "verified_fact" },
    { name: "DefiLlama TVL", status: tvlNow === null ? "failed" : "ok", sourceUrl: "https://api.llama.fi/v2/historicalChainTvl", usage: "verified_fact", detail: "按报告窗口筛选的链上 TVL 序列" },
  );

  // 热点异动币：仅在已有有效价格的币种中选
  const priced = coins.filter(c => Number.isFinite(c.price) && Number.isFinite(c.chg_7d_pct));
  const hot = priced.length ? priced.reduce((a, b) => (Math.abs(b.chg_7d_pct) > Math.abs(a.chg_7d_pct) ? b : a)) : null;

  const btcMcapTn = mcapTn !== null && btcDom !== null ? Math.round(mcapTn * btcDom / 100 * 100) / 100 : null;

  return {
    collectedAt,
    reportWindow,
    sourceStatus,
    global: {
      total_market_cap_usd_tn: mcapTn,
      btc_dominance_pct: btcDom,
      btc_market_cap_usd_tn: btcMcapTn,
      mcap_change_24h_pct: mcapChg,
      source: "Coinlore（CoinGecko 不可达的替代源）",
    },
    defillama: {
      stablecoins: { total_usd_bn: stTotal, usdt_share_pct: stUsdtShare },
      tvl: { total_usd_bn: tvlNow !== null ? Math.round(tvlNow / 1e9 * 100) / 100 : null, chg_7d_pct: tvlChg },
    },
    coins_7d: coins,
    rsi14: { sym: "BTC", value: rsiBtc, state: rsiState(rsiBtc) },
    funding,
    open_interest: oi,
    etf: etfBtc && etfInWindow ? { asset: "BTC", asOf: etfBtc.asOf, dailyFlow: etfBtc.dailyFlow, weekFlow: etfBtc.weekFlow, streakDays: etfBtc.streakDays, daily: etfBtc.daily || [] } : null,
    hot_coin: hot ? { sym: hot.sym, chg_pct: hot.chg_7d_pct } : null,
  };
}
