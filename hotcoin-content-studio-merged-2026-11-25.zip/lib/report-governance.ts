export type ReportWindow = { start: string; end: string; timezone: "Asia/Shanghai"; label: string };
export type SourceStatus = { name: string; status: "ok" | "failed" | "partial"; observedAt?: string; detail?: string; sourceUrl?: string; usage?: "verified_fact" | "lead_only" };
export type GateCheck = { id: string; label: string; passed: boolean; severity: "blocker" | "warning"; detail: string };

const SHANGHAI_OFFSET_MS = 8 * 60 * 60 * 1000;

function shanghaiDay(anchor: Date) {
  const local = new Date(anchor.getTime() + SHANGHAI_OFFSET_MS);
  return new Date(Date.UTC(local.getUTCFullYear(), local.getUTCMonth(), local.getUTCDate()));
}

function formatShanghaiDate(instant: Date) {
  return new Date(instant.getTime() + SHANGHAI_OFFSET_MS).toISOString().slice(0, 10);
}

// 周日发布：固定回顾当周周一 00:00 至周六 23:59:59 北京时间。
// 非周日手动运行时，默认回退到最近一个已完整的周一至周六窗口。
export function latestMondayToSaturday(anchor = new Date()): ReportWindow {
  const dayStart = shanghaiDay(anchor);
  const weekday = dayStart.getUTCDay(); // Sun=0, Mon=1 ... Sat=6
  // Sun -> previous Sat (1 day); Mon-Fri -> previous Sat (2-6 days); Sat -> same day.
  const daysSinceSaturday = weekday === 0 ? 1 : weekday === 6 ? 0 : weekday + 1;
  const end = new Date(dayStart); end.setUTCDate(end.getUTCDate() - daysSinceSaturday);
  const start = new Date(end); start.setUTCDate(start.getUTCDate() - 5);
  const startInstant = new Date(start.getTime() - SHANGHAI_OFFSET_MS);
  const endInstant = new Date(end.getTime() - SHANGHAI_OFFSET_MS + 24 * 60 * 60 * 1000 - 1);
  return { start: startInstant.toISOString(), end: endInstant.toISOString(), timezone: "Asia/Shanghai", label: formatShanghaiDate(startInstant) + " 至 " + formatShanghaiDate(endInstant) };
}

export function parseWeeklyPublishWindow(value: unknown): ReportWindow {
  if (!value || typeof value !== "object") return latestMondayToSaturday();
  const item = value as Partial<ReportWindow>;
  if (!item.start || !item.end || item.timezone !== "Asia/Shanghai") throw new Error("报告窗口必须提供 Asia/Shanghai 的 start、end 和 timezone");
  const start = new Date(item.start), end = new Date(item.end);
  if (!Number.isFinite(+start) || !Number.isFinite(+end) || +start >= +end) throw new Error("报告窗口时间无效");
  const localStart = new Date(+start + SHANGHAI_OFFSET_MS), localEnd = new Date(+end + SHANGHAI_OFFSET_MS);
  if (localStart.getUTCDay() !== 1 || localStart.getUTCHours() !== 0 || localEnd.getUTCDay() !== 6 || localEnd.getUTCHours() !== 23 || localEnd.getUTCMinutes() !== 59) throw new Error("周报仅接受周一 00:00 至周六 23:59 北京时间的发布窗口；周日发布");
  return { start: start.toISOString(), end: end.toISOString(), timezone: "Asia/Shanghai", label: item.label || formatShanghaiDate(start) + " 至 " + formatShanghaiDate(end) };
}

export function createRunId(type: "crypto-weekly" | "tradfi-daily" | "tokenized-stock-report", now = new Date()) { return type + "-" + now.toISOString().replace(/[-:.]/g, ""); }

export function projectReportGate(input: {
  today: string; approved?: boolean; reports?: Record<string, { report?: string; poster?: Record<string, unknown> }>;
  visuals?: Record<string, { coverSvg?: string; posterSvg?: string }>;
  ledger?: { item: string; value: string; source: string; pending?: boolean }[]; linksConfigured?: boolean;
}) {
  const locales = ["zh-CN", "zh-HK", "en"];
  const missingLocales = locales.filter(locale => !input.reports?.[locale]?.report?.trim());
  const missingPosters = locales.filter(locale => !input.reports?.[locale]?.poster);
  const missingVisuals = locales.filter(locale => !input.visuals?.[locale]?.coverSvg?.startsWith("<svg") || !input.visuals?.[locale]?.posterSvg?.startsWith("<svg"));
  const tailsOk = locales.every(locale => {
    const report = input.reports?.[locale]?.report || "";
    return locale === "en" ? report.includes("Disclaimer") && report.includes("About Us") : report.includes(locale === "zh-HK" ? "免責聲明" : "免责声明") && report.includes(locale === "zh-HK" ? "關於我們" : "关于我们");
  });
  const ledgerOk = Boolean(input.ledger?.some(item => item.item.includes("正股价格") && item.value !== "—" && item.source));
  const pending = input.ledger?.filter(item => item.pending).length || 0;
  const checks: GateCheck[] = [
    { id: "project-locales", label: "三语报告齐全", passed: !missingLocales.length, severity: "blocker", detail: missingLocales.length ? "缺少：" + missingLocales.join("、") : "简中、繁中、英文正文均已生成" },
    { id: "project-posters", label: "海报文案齐全", passed: !missingPosters.length, severity: "blocker", detail: missingPosters.length ? "缺少：" + missingPosters.join("、") : "每种语言均有结构化海报文案" },
    { id: "project-visuals", label: "封面与海报视觉素材", passed: !missingVisuals.length, severity: "blocker", detail: missingVisuals.length ? "缺少或格式无效：" + missingVisuals.join("、") : "每种语言均有可编辑 SVG 封面与海报" },
    { id: "project-tail", label: "固定尾缀", passed: tailsOk, severity: "blocker", detail: tailsOk ? "免责声明与 About Us 均已追加" : "至少一种语言缺少固定尾缀" },
    { id: "project-ledger", label: "核心行情证据", passed: ledgerOk, severity: "blocker", detail: ledgerOk ? "正股行情已记录来源与数值" : "正股行情缺失，不能作为正式交付" },
    { id: "project-links", label: "品牌链接配置", passed: input.linksConfigured === true, severity: "warning", detail: input.linksConfigured ? "已配置 REPORT_BRAND_LINKS" : "未配置，交付稿将标记官方链接待配置" },
    { id: "project-pending", label: "待核验字段披露", passed: true, severity: "warning", detail: pending ? "仍有 " + pending + " 项待核验；人工审核时必须逐项确认或保留待核验状态" : "无待核验字段" },
    { id: "project-approval", label: "人工确认", passed: input.approved === true, severity: "blocker", detail: input.approved ? "已人工确认" : "未确认，不可进入发布" },
  ];
  return { passed: checks.every(check => check.severity !== "blocker" || check.passed), checks };
}

export function weeklyGate(input: { reportWindow?: ReportWindow; draft: Record<string, unknown>; sources: SourceStatus[]; generated?: Record<string, unknown> | null; approved?: boolean }) {
  const coins = Array.isArray(input.draft.coins_7d) ? input.draft.coins_7d as Record<string, unknown>[] : [];
  const windowOk = !!input.reportWindow && input.reportWindow.timezone === "Asia/Shanghai";
  const improper24h = coins.some(c => String(c.source || "").includes("24h") && c.chg_7d_pct !== null);
  const failedSources = input.sources.filter(s => s.status === "failed").map(s => s.name);
  const sourceFailureWithValue =
    (failedSources.includes("Gate HYPE K线") && coins.some(c => c.sym === "HYPE" && c.chg_7d_pct !== null)) ||
    (failedSources.includes("Farside ETF") && input.draft.etf !== null);
  const schemaOk = !input.generated || (typeof input.generated === "object" && "week" in input.generated && "market" in input.generated && "flows" in input.generated);
  const week = input.generated?.week as Record<string, unknown> | undefined;
  const windowEmbedded = !input.generated || Boolean(week?.label && week?.publish_date);
  // No first-party validated news, macro calendar, unlock, conference or price-level source is in this draft.
  // Until those sources are integrated, generated output must leave those sections empty.
  const prediction = input.generated?.prediction as Record<string, unknown> | undefined;
  const future = input.generated?.future as Record<string, unknown> | undefined;
  const events = input.generated?.events;
  const macro = input.generated?.macro;
  const ranges = prediction?.ranges;
  const futureItems = future ? [future.conferences, future.key_events, future.projects, future.unlocks] : [];
  const unsupportedSectionsEmpty = !input.generated || (
    (!Array.isArray(ranges) || ranges.length === 0) &&
    (!Array.isArray(events) || events.length === 0) &&
    (!Array.isArray(macro) || macro.length === 0) &&
    futureItems.every(item => !Array.isArray(item) || item.length === 0)
  );
  const generatedOi = input.generated?.derivatives && typeof input.generated.derivatives === "object"
    ? (input.generated.derivatives as Record<string, unknown>).open_interest : undefined;
  const oiChangesRemainNull = !Array.isArray(generatedOi) || generatedOi.every(item => {
    if (!item || typeof item !== "object") return false;
    return (item as Record<string, unknown>).chg_7d_pct === null;
  });
  const checks: GateCheck[] = [
    { id: "weekly-window", label: "固定周一至周六窗口", passed: windowOk, severity: "blocker", detail: windowOk ? input.reportWindow!.label + "（北京时间，周日发布）" : "未锁定周一至周六报告窗口" },
    { id: "weekly-24h", label: "7 日字段不可使用 24h 降级数据", passed: !improper24h, severity: "blocker", detail: improper24h ? "检测到 24h 数据写入 chg_7d_pct" : "未检测到 24h 回填 7 日字段" },
    { id: "weekly-source-null", label: "失败来源不得填充伪数据", passed: !sourceFailureWithValue, severity: "blocker", detail: sourceFailureWithValue ? "失败来源仍对应非空 7 日字段" : "失败来源未生成伪数据" },
    { id: "weekly-schema", label: "周报 JSON 基础 schema", passed: schemaOk, severity: "blocker", detail: schemaOk ? "必要顶层字段存在" : "缺少 week、market 或 flows 字段" },
    { id: "weekly-window-output", label: "输出含报告周期", passed: windowEmbedded, severity: "blocker", detail: windowEmbedded ? "输出携带 week 标识" : "输出未携带报告周期" },
    { id: "weekly-evidence-bounds", label: "未接入来源不得由 AI 补写", passed: unsupportedSectionsEmpty, severity: "blocker", detail: unsupportedSectionsEmpty ? "新闻、宏观、未来日历与关键价位均保留为空，待一手来源接入" : "检测到无一手底稿支撑的新闻、宏观、未来日历或价格区间" },
    { id: "weekly-oi-window", label: "OI 未采集周变化时必须为空", passed: oiChangesRemainNull, severity: "blocker", detail: oiChangesRemainNull ? "OI 仅保留运行时快照，未伪造 7 日变化" : "检测到未采集的 OI 7 日变化被填充" },
    { id: "weekly-approval", label: "人工确认", passed: input.approved === true, severity: "blocker", detail: input.approved ? "已人工确认" : "未确认，不可进入发布" },
  ];
  return { passed: checks.every(c => c.severity !== "blocker" || c.passed), checks };
}
