import type { FactPack } from "./market-studio";
import type { ReportWindow } from "./report-governance";

export type EvidenceReviewItem = {
  id: string;
  kind: "news" | "macro_calendar";
  title: string;
  observedAt: string | null;
  source: string;
  sourceUrl: string;
  reason: string;
  status: "pending_review";
};

function inWindow(value: string, window: ReportWindow) {
  const time = Date.parse(value);
  return Number.isFinite(time) && time >= Date.parse(window.start) && time <= Date.parse(window.end);
}

// RSS/公开日历均是待核验线索。此队列只协助运营定位和留痕，不把线索升级为发布事实。
export function buildEvidenceReviewQueue(facts: FactPack | null, reportWindow: ReportWindow): EvidenceReviewItem[] {
  if (!facts) return [];
  const news = facts.news
    .filter(item => inWindow(item.publishedAt, reportWindow))
    .map((item, index) => ({
      id: `news-${index}-${item.url}`, kind: "news" as const, title: item.title, observedAt: item.publishedAt || null,
      source: item.source, sourceUrl: item.url, reason: "RSS 转载线索；需打开原文并补充一手或权威原始来源后才可引用。", status: "pending_review" as const,
    }));
  const calendar = (facts.calendar || [])
    .filter(item => inWindow(item.date, reportWindow))
    .map((item, index) => ({
      id: `macro-${index}-${item.date}-${item.title}`, kind: "macro_calendar" as const,
      title: item.title, observedAt: item.date || null, source: "ForexFactory 公开日历",
      sourceUrl: "https://www.forexfactory.com/calendar",
      reason: `公开日历线索（${item.region || "地区未标明"}；${item.impact || "影响等级未知"}）；需以官方发布机构日历或实际公布值核验。`,
      status: "pending_review" as const,
    }));
  return [...news, ...calendar].slice(0, 30);
}
