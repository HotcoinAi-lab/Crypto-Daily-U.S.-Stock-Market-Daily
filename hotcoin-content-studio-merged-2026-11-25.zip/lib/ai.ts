// 模型调用适配层：统一支持 OpenAI 官方与所有 OpenAI 兼容端点
// （DeepSeek、Kimi/Moonshot、GLM、Qwen、SiliconFlow 等均提供 /chat/completions 兼容接口）
// 环境变量优先级：AI_API_KEY/AI_BASE_URL/AI_MODEL > OPENAI_API_KEY/OPENAI_MODEL（api.openai.com）

export type AIConfig = { baseUrl: string; apiKey: string; model: string; kind: "responses" | "chat" };

export function aiConfigured(): boolean {
  return Boolean(process.env.AI_API_KEY || process.env.OPENAI_API_KEY);
}

export function getAIConfig(): AIConfig | null {
  const apiKey = process.env.AI_API_KEY || process.env.OPENAI_API_KEY || "";
  if (!apiKey) return null;
  const baseUrl = (process.env.AI_BASE_URL || "https://api.openai.com/v1").replace(/\/+$/, "");
  const model = process.env.AI_MODEL || process.env.OPENAI_MODEL || "gpt-5.6";
  // OpenAI 官方走 Responses API；其余兼容端点走 chat/completions
  const kind: AIConfig["kind"] = /api\.openai\.com/i.test(baseUrl) ? "responses" : "chat";
  return { baseUrl, apiKey, model, kind };
}

// 单轮文本生成：prompt 直接作为用户消息；返回纯文本
export async function chatComplete(prompt: string): Promise<string> {
  const cfg = getAIConfig();
  if (!cfg) throw new Error("未配置模型密钥（AI_API_KEY 或 OPENAI_API_KEY）");

  if (cfg.kind === "responses") {
    const r = await fetch(cfg.baseUrl + "/responses", {
      method: "POST",
      headers: { authorization: `Bearer ${cfg.apiKey}`, "content-type": "application/json" },
      body: JSON.stringify({ model: cfg.model, input: prompt }),
    });
    const j = await r.json() as Record<string, unknown>;
    if (!r.ok) throw new Error(typeof j.error === "object" ? JSON.stringify(j.error) : `模型接口 HTTP ${r.status}`);
    const text = (j as { output_text?: string }).output_text || "";
    if (!text) throw new Error("模型未返回正文");
    return text;
  }

  const r = await fetch(cfg.baseUrl + "/chat/completions", {
    method: "POST",
    headers: { authorization: `Bearer ${cfg.apiKey}`, "content-type": "application/json" },
    body: JSON.stringify({ model: cfg.model, messages: [{ role: "user", content: prompt }] }),
  });
  const j = await r.json() as { choices?: { message?: { content?: string } }[]; error?: unknown };
  if (!r.ok) throw new Error(typeof j.error === "object" ? JSON.stringify(j.error) : `模型接口 HTTP ${r.status}`);
  const text = j.choices?.[0]?.message?.content || "";
  if (!text) throw new Error("模型未返回正文");
  return text;
}

// 从模型输出中提取 JSON 对象（容忍 ```json 围栏与前后解释文字）
export function extractJson(text: string): unknown {
  const fenced = text.match(/```(?:json)?\s*([\s\S]*?)```/i);
  const body = fenced ? fenced[1] : text;
  const start = body.indexOf("{");
  const end = body.lastIndexOf("}");
  if (start < 0 || end <= start) throw new Error("模型输出中未找到 JSON 对象");
  return JSON.parse(body.slice(start, end + 1));
}
