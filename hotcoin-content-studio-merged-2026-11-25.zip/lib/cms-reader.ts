import type { Article } from "@/lib/article-store";

// 演示 CMS 的存储在 API 路由所在的 worker 环境里；不同环境间模块状态不共享，
// 新闻页面统一通过内部 HTTP 回读该接口，保证与发布写入的是同一份数据。
export async function fetchArticles(origin: string): Promise<Article[]> {
  const secret = process.env.CMS_RECEIVER_SECRET || "local-demo-secret";
  try {
    const res = await fetch(`${origin}/api/cms/articles`, { headers: { authorization: `Bearer ${secret}` }, cache: "no-store" });
    if (!res.ok) return [];
    const data = await res.json() as { items?: Article[] };
    return (data.items || []).sort((a, b) => +new Date(b.publishedAt) - +new Date(a.publishedAt));
  } catch {
    return [];
  }
}
