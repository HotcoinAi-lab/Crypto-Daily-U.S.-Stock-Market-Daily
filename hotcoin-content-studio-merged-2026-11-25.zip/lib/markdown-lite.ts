// 轻量 Markdown → HTML，仅覆盖日报用到的语法（标题/列表/粗体/引用/表格/段落），输出前先做 HTML 转义
function esc(s: string) {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}

function inline(s: string) {
  return esc(s).replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>").replace(/`([^`]+)`/g, "<code>$1</code>");
}

export function renderMarkdown(md: string) {
  const lines = md.split("\n");
  const out: string[] = [];
  let listOpen = false;
  let tableRows: string[][] = [];
  const closeList = () => { if (listOpen) { out.push("</ul>"); listOpen = false; } };
  const flushTable = () => {
    if (!tableRows.length) return;
    const [head, , ...body] = tableRows;
    out.push("<table><thead><tr>" + head.map((c) => `<th>${inline(c)}</th>`).join("") + "</tr></thead><tbody>"
      + body.map((r) => "<tr>" + r.map((c) => `<td>${inline(c)}</td>`).join("") + "</tr>").join("") + "</tbody></table>");
    tableRows = [];
  };
  for (const raw of lines) {
    const line = raw.trimEnd();
    // 图片：![alt](src)
    const img = line.match(/^!\[([^\]]*)\]\(([^)\s]+)\)$/);
    if (img) {
      flushTable(); closeList();
      const src = img[2];
      const safe = /\.(svg|png|jpe?g|webp|gif)$/i.test(src) && /^\//.test(src) ? src : "";
      if (safe) out.push(`<img src="${esc(safe)}" alt="${esc(img[1])}" style="max-width:100%;border-radius:12px;display:block;margin:10px auto;"/>`);
      continue;
    }
    if (/^\|.*\|$/.test(line)) {
      const cells = line.slice(1, -1).split("|").map((c) => c.trim());
      if (!cells.every((c) => /^:?-{2,}:?$/.test(c))) tableRows.push(cells);
      continue;
    }
    flushTable();
    const h = line.match(/^(#{1,4})\s+(.*)$/);
    if (h) { closeList(); out.push(`<h${h[1].length}>${inline(h[2])}</h${h[1].length}>`); continue; }
    if (line.startsWith("> ")) { closeList(); out.push(`<blockquote>${inline(line.slice(2))}</blockquote>`); continue; }
    if (/^[-*]\s+/.test(line)) {
      if (!listOpen) { out.push("<ul>"); listOpen = true; }
      out.push(`<li>${inline(line.replace(/^[-*]\s+/, ""))}</li>`);
      continue;
    }
    closeList();
    if (line.trim()) out.push(`<p>${inline(line)}</p>`);
  }
  flushTable(); closeList();
  return out.join("\n");
}
