import type { FactPack } from "@/lib/market-studio";

export type FaqItem = { question: string; answer: string };
export type SeoMeta = {
  slug: string;
  metaTitle: string;
  metaDescription: string;
  keywords: string[];
  faq: FaqItem[];
  jsonLd: Record<string, unknown>[];
  warnings: string[];
};

// 交给 CMS 的 SEO 元数据全部从正文与事实包确定性提取，不依赖模型，避免编造
export function buildSeo(draft: string, facts: FactPack): SeoMeta {
  const warnings: string[] = [];
  const lines = draft.split("\n").map((l) => l.trim());
  const title = (lines.find((l) => l.startsWith("# ")) || "").replace(/^#\s*/, "").trim() || "加密货币每日市场报告";

  // 导语：第一段非标题/引用/表格/列表的正文文本
  const lede = lines.find((l) => l && !/^[#>|*-]/.test(l) && !l.startsWith("```") && (l.match(/[一-鿿]/g) || []).length >= 15) || "";

  const metaTitle = clip(title, 60);
  const metaDescription = clip(lede.replace(/\*\*/g, ""), 155);
  if (!lede) warnings.push("正文缺少导语段，meta description 为空");
  if (title.length > 60) warnings.push(`H1 标题 ${title.length} 字符，建议 ≤60`);
  if (lede.length > 160) warnings.push(`导语 ${lede.length} 字符，建议 ≤160 以完整进入搜索摘要`);

  const keywords = [...new Set([
    ...facts.tickers.map((t) => t.symbol),
    "加密货币每日市场报告",
    "比特币价格",
    ...(facts.etfFlows?.length ? ["BTC ETF 资金流", "ETH ETF 资金流"] : []),
    ...(facts.calendar?.length ? ["宏观经济日历"] : []),
    ...(facts.indicators?.fearGreed ? ["恐惧与贪婪指数"] : []),
  ])];

  // FAQ：约定格式「## ❓ 常见问题」下的「- {問}：{答}」列表项
  const faqStart = lines.findIndex((l) => /^#{2,3}\s*.*常[见見][问問][题題]/.test(l));
  const faq: FaqItem[] = [];
  if (faqStart >= 0) {
    for (const line of lines.slice(faqStart + 1)) {
      if (/^#{1,3}\s/.test(line)) break;
      const m = line.match(/^[-*]\s*\*\*(.+?)\*\*[：:]\s*(.+)$/) || line.match(/^[-*]\s*(.+?)[：:]\s*(.+)$/);
      if (m) faq.push({ question: m[1].trim(), answer: m[2].trim() });
    }
  } else {
    warnings.push("正文缺少「常见问题」FAQ 小节，无法生成 FAQPage 结构化数据");
  }

  // KuCoin 风格 slug：crypto-daily-market-report-september-10-2026（本地日期，与正文标题一致；同日重复发布得到同一 slug）
  const day = new Date(facts.collectedAt);
  const month = day.toLocaleString("en-US", { month: "long" }).toLowerCase();
  const slug = `crypto-daily-market-report-${month}-${day.getDate()}-${day.getFullYear()}`;
  const publishedAt = new Date().toISOString();
  const jsonLd: Record<string, unknown>[] = [{
    "@context": "https://schema.org",
    "@type": "NewsArticle",
    headline: metaTitle,
    description: metaDescription,
    inLanguage: "zh-CN",
    keywords: keywords.join(", "),
    datePublished: publishedAt,
    dateModified: publishedAt,
    articleSection: "市场报告",
  }];
  if (faq.length) {
    jsonLd.push({
      "@context": "https://schema.org",
      "@type": "FAQPage",
      mainEntity: faq.map((f) => ({
        "@type": "Question",
        name: f.question,
        acceptedAnswer: { "@type": "Answer", text: f.answer },
      })),
    });
  }
  return { slug, metaTitle, metaDescription, keywords, faq, jsonLd, warnings };
}

function clip(text: string, max: number) {
  const clean = text.replace(/\s+/g, " ").trim();
  return clean.length <= max ? clean : `${clean.slice(0, max - 1)}…`;
}
