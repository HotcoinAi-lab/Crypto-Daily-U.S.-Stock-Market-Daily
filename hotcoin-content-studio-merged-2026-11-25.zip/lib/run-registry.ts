import type { GateCheck, ReportWindow, SourceStatus } from "./report-governance";
import { desc } from "drizzle-orm";
import { reportRuns } from "@/db/schema";
export type RunRecord = { runId: string; reportType: "crypto-weekly" | "tradfi-daily" | "tokenized-stock-report"; createdAt: string; reportWindow: ReportWindow | { date: string; timezone: "UTC" } | { date: string; label: string; timezone: "UTC" }; sources: SourceStatus[]; quality: GateCheck[]; approval: "pending" | "approved"; artifacts: string[]; status: "draft" | "blocked" | "ready" };
const records: RunRecord[] = [];

function saveMemory(record: RunRecord) { const index = records.findIndex(r => r.runId === record.runId); if (index >= 0) records[index] = record; else records.unshift(record); return record; }

// Local preview falls back to memory when no D1 binding exists. Production must bind DB and apply
// the migration; a successful D1 write becomes the durable registry.
export async function saveRun(record: RunRecord) {
  saveMemory(record);
  try {
    // Keep the Cloudflare-only binding out of the Node preview module graph.
    const { getDb } = await import("@/db");
    const db = getDb();
    await db.insert(reportRuns).values({ runId: record.runId, reportType: record.reportType, createdAt: record.createdAt, status: record.status, payload: JSON.stringify(record) })
      .onConflictDoUpdate({ target: reportRuns.runId, set: { status: record.status, payload: JSON.stringify(record) } });
  } catch { /* local preview or unconfigured D1: memory fallback remains explicit in UI/docs */ }
  return record;
}

export async function listRuns() {
  try {
    const { getDb } = await import("@/db");
    const rows = await getDb().select().from(reportRuns).orderBy(desc(reportRuns.createdAt)).limit(50);
    return rows.map(row => JSON.parse(row.payload) as RunRecord);
  } catch { return records.slice(0, 50); }
}
