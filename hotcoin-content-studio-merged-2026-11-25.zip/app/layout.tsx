import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "AI Market Content Studio",
  description: "本地市场数据采集、AI内容生成、质量检查与CMS发布工具",
  other: { "codex-preview": "development" },
  icons: { icon: "/favicon.svg", shortcut: "/favicon.svg" },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="zh-CN"><body className="antialiased">{children}</body></html>;
}
