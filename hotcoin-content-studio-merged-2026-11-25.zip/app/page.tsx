"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { Activity, Bot, CheckCircle2, CircleAlert, CloudUpload, Database, Download, Eye, Play, RefreshCw, ShieldCheck, Sparkles, Archive, ClipboardCheck, ArrowUpRight, FileCheck2, Layers3, type LucideIcon } from "lucide-react";
import { renderMarkdown } from "@/lib/markdown-lite";
import { DEFAULT_MARKET_PROMPT } from "@/lib/prompts";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { ProjectReportWorkspace, type ReportLocale, type StockReportData } from "@/components/project-report-workspace";
import { latestMondayToSaturday } from "@/lib/report-governance";
import { toast, Toaster } from "sonner";

type Ticker = { symbol: string; price: number; change24h: number; volume24h: number; source: string; observedAt: string };
type NewsItem = { title: string; url: string; source: string; publishedAt: string };
type FearGreed = { value: number; label: string };
type EquityQuote = { symbol: string; name: string; price: number; changePct: number; observedAt: string };
type EtfFlow = { asset: string; asOf: string; dailyFlow: number; prevDayFlow: number; weekFlow: number; streakDays: number };
type CalendarEvent = { date: string; title: string; region: string; impact: string; forecast: string; previous: string };
type Collection = { collectedAt: string; tickers: Ticker[]; news: NewsItem[]; sources: { name: string; ok: boolean; count: number; error?: string }[]; indicators?: { fearGreed?: FearGreed }; equities?: EquityQuote[]; etfFlows?: EtfFlow[]; calendar?: CalendarEvent[] };
type Check = { id: string; label: string; passed: boolean; detail: string; severity: "blocker" | "warning" };
type WeeklyRun = { runId: string; reportType: "crypto-weekly" | "tradfi-daily" | "tokenized-stock-report"; createdAt: string; reportWindow: { start: string; end: string; timezone: "Asia/Shanghai"; label: string } | { date: string; label?: string; timezone: "UTC" }; sources: { name: string; status: string; detail?: string }[]; quality: Check[]; approval: "pending" | "approved"; status: string; artifacts: string[] };
type DailyQuality = { passed: boolean; checks: Check[]; artifacts: string[]; run: WeeklyRun };
type DailyFactPlan = { plan: { checks: Check[]; blockers: string[]; threeTimelines: { key: string; label: string; present: boolean; asOf?: string; timezone?: string }[]; requiredArtifacts: string[] }; run: WeeklyRun; warning: string };
type EvidenceReviewItem = { id: string; kind: "news" | "macro_calendar"; title: string; observedAt: string | null; source: string; sourceUrl: string; reason: string; status: "pending_review" };
type ReviewDecision = { verified: boolean; verifiedUrl: string; note: string };
type StockReportResponse = StockReportData & { tokenOk: boolean; tokenPrice: string; tokenChange: string; stockOk: boolean; stockPrice: string; stockChange: string; stockName: string; ledger: { item: string; value: string; source: string; url: string; asOf: string; pending?: boolean }[]; relatedNews: { title: string; url: string; source: string; pubDate: string }[]; warnings: string[]; draftZh: string; aiMode: string; runId: string; quality: { passed: boolean; checks: Check[] }; run: WeeklyRun };

const DEFAULT_PROMPT = DEFAULT_MARKET_PROMPT;

function fmtPrice(value: number) {
  return new Intl.NumberFormat("en-US", { maximumFractionDigits: value < 1 ? 6 : 2 }).format(value);
}

// 资金流单位为百万美元，按中文数量级（億）展示
function fmtFlow(m: number) {
  return `${m < 0 ? "淨流出" : "淨流入"} $${(Math.abs(m) / 100).toFixed(2)} 億`;
}

export default function Home() {
  const [collection, setCollection] = useState<Collection | null>(null);
  const [prompt, setPrompt] = useState(DEFAULT_PROMPT);
  const [draft, setDraft] = useState("");
  const [checks, setChecks] = useState<Check[]>([]);
  const [collecting, setCollecting] = useState(false);
  const [generating, setGenerating] = useState(false);
  const [validating, setValidating] = useState(false);
  const [publishing, setPublishing] = useState(false);
  const [approved, setApproved] = useState(false);
  const [cmsUrl, setCmsUrl] = useState("/api/cms/articles");
  const [cmsToken, setCmsToken] = useState("local-demo-secret");
  const [lastPublish, setLastPublish] = useState<{ id: string; url?: string; publishedAt: string } | null>(null);
  const [seo, setSeo] = useState<{ slug: string; metaTitle: string; metaDescription: string; keywords: string[]; faq: { question: string; answer: string }[]; jsonLd: unknown[]; warnings: string[] } | null>(null);
  const [srForm, setSrForm] = useState({ company: "", ticker: "", code: "", issuer: "" });
  const [srPre, setSrPre] = useState<{ reports: { title: string; slug: string; createdTime: number }[]; dup: { title: string; slug: string; createdTime: number } | null } | null>(null);
  const [srData, setSrData] = useState<StockReportResponse | null>(null);
  const [srDraft, setSrDraft] = useState("");
  const [srDrafts, setSrDrafts] = useState<Record<ReportLocale, string>>({ "zh-CN": "", "zh-HK": "", en: "" });
  const [srLocale, setSrLocale] = useState<ReportLocale>("zh-CN");
  const [srApproved, setSrApproved] = useState(false);
  const [srBusy, setSrBusy] = useState(false);
  const [showPreview, setShowPreview] = useState(false);
  const [showSrPreview, setShowSrPreview] = useState(false);
  const [wkBusy, setWkBusy] = useState(false);
  const [wkApproved, setWkApproved] = useState(false);
  const [wkData, setWkData] = useState<{ mode: string; runId: string; reportWindow: { start: string; end: string; timezone: "Asia/Shanghai"; label: string }; draft: Record<string, unknown>; weekly: Record<string, unknown> | null; evidenceManifest?: Record<string, unknown>; evidenceReviewQueue?: EvidenceReviewItem[]; quality: { passed: boolean; checks: Check[] }; run: WeeklyRun; warning?: string } | null>(null);
  const [reviewDecisions, setReviewDecisions] = useState<Record<string, ReviewDecision>>({});
  const [dailyDate, setDailyDate] = useState("2026-11-10");
  // 对应已归档的 2026-11-12 日报交付包；用于验证“已有日报可被统一登记”，不是重新生成日报。
  const [dailyFiles, setDailyFiles] = useState("zh.md\nen.md\nevidence.md\nvisual-data.json\nvisual-data-zh.json\nvisuals-zh/01-market-pulse.png\nvisuals-zh/02-hotcoin-asset-movers.png\nvisuals-zh/03-catalyst-calendar.png\nvisuals-en/01-market-pulse.png\nvisuals-en/02-hotcoin-asset-movers.png\nvisuals-en/03-catalyst-calendar.png\nassets/hotcoin-tradfi-daily-cover-fixed.png");
  const [dailyQuality, setDailyQuality] = useState<DailyQuality | null>(null);
  const [dailyApproved, setDailyApproved] = useState(false);
  const [dailyFactInput, setDailyFactInput] = useState('{\n  "reportDate": "2026-11-19",\n  "usClose": { "asOf": "", "timezone": "America/New_York", "sourceUrl": "", "evidenceId": "us-close-001", "indices": {} },\n  "hotcoinSnapshot": { "asOf": "", "timezone": "UTC", "sourceUrl": "", "evidenceId": "hotcoin-snapshot-001", "assets": {} },\n  "macroCalendar": { "asOf": "", "timezone": "America/New_York", "sourceUrl": "", "evidenceId": "macro-calendar-001", "events": [] },\n  "evidence": [{ "id": "us-close-001", "sourceUrl": "", "retrievedAt": "" }, { "id": "hotcoin-snapshot-001", "sourceUrl": "", "retrievedAt": "" }, { "id": "macro-calendar-001", "sourceUrl": "", "retrievedAt": "" }]\n}');
  const [dailyFactPlan, setDailyFactPlan] = useState<DailyFactPlan | null>(null);
  const [runs, setRuns] = useState<WeeklyRun[]>([]);
  const [runTypeFilter, setRunTypeFilter] = useState<"all" | WeeklyRun["reportType"]>("all");
  const [runStatusFilter, setRunStatusFilter] = useState<"all" | WeeklyRun["status"]>("all");
  const [activeTab, setActiveTab] = useState("collect");

  // 与 /api/validate 的数据时效检查一致：超过 6 小时的采集数据视为过期
  const FRESH_MS = 6 * 60 * 60 * 1000;
  const isStale = (c: Collection | null) => !c?.collectedAt || Date.now() - Date.parse(c.collectedAt) > FRESH_MS;

  const collect = useCallback(async (silent = false) => {
    setCollecting(true); setChecks([]); setApproved(false); setSeo(null);
    try {
      const res = await fetch("/api/collect", { method: "POST" });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "采集失败");
      setCollection(data); localStorage.setItem("market-studio-collection", JSON.stringify(data));
      if (!silent) toast.success(`采集完成：${data.tickers.length} 个行情，${data.news.length} 条资讯`);
      return data as Collection;
    } catch (error) { toast.error(error instanceof Error ? error.message : "采集失败"); return null; }
    finally { setCollecting(false); }
  }, []);

  useEffect(() => {
    const saved = localStorage.getItem("market-studio-collection");
    if (saved) { try { const c = JSON.parse(saved) as Collection; if (!isStale(c)) setCollection(c); } catch { /* ignore */ } }
    collect(true);
  }, [collect]);

  async function generate() {
    setGenerating(true); setChecks([]); setApproved(false); setSeo(null);
    try {
      // 数据过期（含 localStorage 里恢复的旧采集）时先自动重新采集，避免用旧日期生成
      let facts = collection;
      if (isStale(facts)) {
        toast.message("采集数据已过期，正在重新采集…");
        facts = await collect(true);
      }
      if (!facts) return;
      const res = await fetch("/api/generate", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ prompt, factPack: facts }) });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "生成失败");
      setDraft(data.content); setSeo(null); toast.success(data.mode === "ai" ? "AI内容已生成" : "已生成安全模板稿（未配置模型密钥）");
    } catch (error) { toast.error(error instanceof Error ? error.message : "生成失败"); }
    finally { setGenerating(false); }
  }

  async function validate() {
    if (!collection || !draft.trim()) return toast.error("请先采集并生成内容");
    setValidating(true); setApproved(false);
    try {
      const res = await fetch("/api/validate", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ draft, factPack: collection }) });
      const data = await res.json(); setChecks(data.checks || []);
      toast[data.passed ? "success" : "error"](data.passed ? "全部阻断项已通过" : "存在问题，禁止发布");
    } finally { setValidating(false); }
  }

  async function publish() {
    if (!canPublish) return toast.error("必须通过检查并完成人工确认");
    setPublishing(true);
    try {
      const res = await fetch("/api/publish", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ cmsUrl, cmsToken, draft, factPack: collection, checks, approved }) });
      const data = await res.json(); if (!res.ok) throw new Error(data.error || "发布失败");
      setLastPublish(data); toast.success("内容已通过CMS API发布");
    } catch (error) { toast.error(error instanceof Error ? error.message : "发布失败"); }
    finally { setPublishing(false); }
  }

  async function previewSeo() {
    if (!collection || !draft.trim()) return toast.error("请先采集并生成内容");
    try {
      const res = await fetch("/api/seo", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ draft, factPack: collection }) });
      const data = await res.json(); if (!res.ok) throw new Error(data.error || "SEO生成失败");
      setSeo(data); toast.success("SEO元数据已生成");
    } catch (error) { toast.error(error instanceof Error ? error.message : "SEO生成失败"); }
  }

  async function runStockReport() {
    if (!srForm.company || !srForm.ticker || !srForm.code) return toast.error("请填写公司名、正股代码、Hotcoin 代码");
    setSrBusy(true); setSrPre(null); setSrData(null); setSrDraft("");
    try {
      // 第 0 步查重：前端直连 Hotcoin 学院接口（CORS 已验证可用），逐页拉取直到空
      const reports: { title: string; slug: string; createdTime: number }[] = [];
      let dup: { title: string; slug: string; createdTime: number } | null = null;
      const kw = [srForm.ticker, srForm.code, srForm.company].filter(Boolean).map(k => k.toUpperCase());
      for (let p = 1; p <= 12 && !dup; p++) {
        const r = await fetch(`https://www.hotcoin.com/hk-web/cms/academy/course/list?catalogCode=27766377952972800&moduleId=2&pageNum=${p}&pageSize=6&lang=zh_CN`);
        const j = await r.json();
        const items = (j.data || []) as { title: string; slug: string; createdTime: number }[];
        for (const it of items) {
          reports.push(it);
          const title = (it.title || "").toUpperCase();
          if (kw.some(k => title.includes(k))) dup = it;
        }
        if (!items.length) break;
      }
      setSrPre({ reports, dup });
      const demoRun = srForm.company.includes("内部演示");
      if (dup && !demoRun) { toast.error(`该标的已发过报告：${dup.title}`); return; }
      if (dup && demoRun) toast.message("演示模式：跳过已有内容查重；此批次不可作为正式发布依据。");
      toast.success(`前置检查通过：未发现已发报告（学院共 ${reports.length} 条）`);
      const today = new Date().toISOString().slice(0, 10);
      // 代币价格：前端直连 Hotcoin 行情接口（服务端 workerd 对该域名 DNS 不稳）
      let tokenPrice = ""; let tokenChange = ""; let tokenAsOf = today;
      try {
        const r = await fetch("https://api.hotcoinfin.com/v1/market/ticker");
        const j = await r.json();
        const hit = (j.ticker || []).find((t: { symbol: string }) => t.symbol === srForm.code.toLowerCase() + "_usdt");
        if (hit) {
          tokenPrice = "$" + hit.last;
          tokenChange = (Number(hit.change) >= 0 ? "+" : "") + hit.change + "%";
          tokenAsOf = new Date(Number(hit.ts)).toISOString().slice(0, 10);
          toast.success(`已核实交易对 ${hit.symbol}：${tokenPrice}`);
        } else toast.error(`Hotcoin 现货未找到 ${srForm.code.toLowerCase()}_usdt，请核实代码`);
      } catch { toast.error("Hotcoin 行情接口不可达，代币价格需人工确认"); }
      // 采集 + 生成
      const res = await fetch("/api/stock-report", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ company_name: srForm.company, stock_ticker: srForm.ticker, hotcoin_code: srForm.code, issuer_info: srForm.issuer, today, token_price: tokenPrice, token_change: tokenChange, token_asof: tokenAsOf, approved: srApproved }) });
      const d = await res.json();
      if (!res.ok) throw new Error(d.error || "生成失败");
      const reportData = d as StockReportResponse;
      const drafts = { "zh-CN": reportData.reports["zh-CN"].report, "zh-HK": reportData.reports["zh-HK"].report, en: reportData.reports.en.report };
      setSrData(reportData); setSrDrafts(drafts); setSrLocale("zh-CN"); setSrDraft(drafts["zh-CN"]); refreshRuns();
      toast.success(d.aiMode === "ai" ? "三语报告、海报文案与视觉素材已生成" : "已输出三语骨架与待核验内容（未配置 AI 密钥）");
    } catch (e) { toast.error(e instanceof Error ? e.message : "生成失败"); }
    finally { setSrBusy(false); }
  }

  function loadProjectReportDemo() {
    setSrForm({ company: "Apple Inc.（内部演示）", ticker: "AAPL", code: "aaplb", issuer: "演示输入：发行方、公链、合约与权利结构须在正式交付前由官方材料核验" });
    setSrApproved(false); setSrData(null); setSrPre(null); setSrDraft("");
    toast.message("已填入 AAPL / AAPLB 演示案例；该输入只用于展示生产链路，不代表已核实或已发布内容。");
  }

  function countSrChars(t: string) {
    const body = t.split("免责声明")[0];
    const han = (body.match(/[\u4e00-\u9fff]/g) || []).length;
    const words = (body.match(/[A-Za-z0-9]+(?:\.[0-9]+)?/g) || []).length;
    return han + words;
  }

  function switchSrLocale(locale: ReportLocale) {
    setSrDrafts((current) => ({ ...current, [srLocale]: srDraft }));
    setSrLocale(locale);
    setSrDraft(srDrafts[locale]);
  }

  function updateSrDraft(value: string) {
    setSrDraft(value);
    setSrDrafts((current) => ({ ...current, [srLocale]: value }));
  }

  function downloadFile(name: string, content: string, type: string) {
    const url = URL.createObjectURL(new Blob([content], { type }));
    const anchor = document.createElement("a");
    anchor.href = url; anchor.download = name; anchor.click();
    URL.revokeObjectURL(url);
  }

  function downloadReportPackage() {
    if (!srData) return;
    const reports = Object.fromEntries((Object.keys(srData.reports) as ReportLocale[]).map((locale) => [locale, { ...srData.reports[locale], report: srDrafts[locale] }]));
    downloadFile("project-report-production-package.json", JSON.stringify({ ...srData, reports }, null, 2), "application/json;charset=utf-8");
  }


  function defaultWeeklyWindow() { return latestMondayToSaturday(); }

  async function refreshRuns() {
    const res = await fetch("/api/runs"); const d = await res.json(); if (res.ok) setRuns(d.runs || []);
  }

  async function runWeekly(mode: "draft" | "generate") {
    setWkBusy(true); setWkData(null); setReviewDecisions({});
    try {
      const res = await fetch("/api/weekly", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ mode, reportWindow: defaultWeeklyWindow(), approved: wkApproved }) });
      const d = await res.json();
      if (!res.ok) throw new Error(d.error || "请求失败");
      setWkData(d);
      refreshRuns();
      toast.success(mode === "draft" ? "周报底稿已采集" : d.weekly ? "周报 JSON 已生成" : "底稿已输出" + (d.warning ? "（" + d.warning.slice(0, 40) + "…）" : ""));
    } catch (e) { toast.error(e instanceof Error ? e.message : "请求失败"); }
    finally { setWkBusy(false); }
  }

  async function checkDailyPackage() {
    const files = dailyFiles.split(/\n+/).map(x => x.trim()).filter(Boolean);
    const res = await fetch("/api/daily-quality", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ reportDate: dailyDate, files, approved: dailyApproved }) });
    const d = await res.json(); if (!res.ok) return toast.error(d.error || "日报检查失败");
    setDailyQuality(d);
    refreshRuns();
    toast[d.passed ? "success" : "error"](d.passed ? "日报交付包完整，已登记" : "日报交付包存在缺件，已登记为阻断");
  }

  async function planDailyFacts() {
    let facts: unknown;
    try { facts = JSON.parse(dailyFactInput); } catch { toast.error("事实底稿不是有效 JSON，请检查逗号、引号和括号。"); return; }
    const res = await fetch("/api/tradfi-daily", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ ...(facts as Record<string, unknown>), approved: dailyApproved }) });
    const data = await res.json();
    if (!res.ok) return toast.error(data.error || "日报事实包检查失败");
    setDailyFactPlan(data); refreshRuns();
    toast[data.plan.blockers.length ? "error" : "success"](data.plan.blockers.length ? "事实底稿有阻断项，未生成正文或图表。" : "事实底稿完整，已进入人工确认前状态。");
  }

  function downloadDailyFactPack() {
    if (!dailyFactPlan) return;
    downloadFile(`${dailyFactPlan.run.runId}-daily-fact-pack.json`, JSON.stringify({ version: "1.0", exportedAt: new Date().toISOString(), input: JSON.parse(dailyFactInput), ...dailyFactPlan }, null, 2), "application/json;charset=utf-8");
  }

  function downloadRunManifest(run: WeeklyRun) {
    downloadFile(`${run.runId}-run-manifest.json`, JSON.stringify({ version: "1.0", exportedAt: new Date().toISOString(), run, qualitySummary: { blockers: run.quality.filter(check => check.severity === "blocker" && !check.passed), warnings: run.quality.filter(check => check.severity === "warning" && !check.passed) } }, null, 2), "application/json;charset=utf-8");
  }

  async function retryRun(run: WeeklyRun) {
    if (run.reportType === "crypto-weekly") { setActiveTab("weekly"); await runWeekly("draft"); return; }
    if (run.reportType === "tradfi-daily") {
      setDailyApproved(false);
      setDailyDate("date" in run.reportWindow ? run.reportWindow.date : dailyDate);
      setActiveTab("daily-facts");
      toast.message("已切回日报事实底稿：先补齐三条时间线与证据关联，再进行交付包检查。");
      return;
    }
    setActiveTab("report"); toast.message("已切回项目报告：补齐阻断项后重新生成。");
  }

  function downloadWeekly() {
    if (!wkData) return;
    const payload = wkData.weekly ? JSON.stringify(wkData.weekly, null, 2) : JSON.stringify(wkData.draft, null, 2);
    const blob = new Blob([payload], { type: "application/json" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = wkData.weekly ? "weekly_data.json" : "weekly_data_draft.json";
    a.click(); URL.revokeObjectURL(a.href);
  }

  function downloadWeeklyEvidence() {
    if (!wkData) return;
    const payload = { run: wkData.run, evidence_manifest: wkData.evidenceManifest, reportWindow: wkData.reportWindow, sourceStatus: wkData.run.sources, quality: wkData.quality, weekly_data_draft: wkData.draft, weekly_data: wkData.weekly, evidence_review_queue: (wkData.evidenceReviewQueue || []).map(item => ({ ...item, review: reviewDecisions[item.id] || { verified: false, verifiedUrl: "", note: "" } })) };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob); a.download = `${wkData.runId}-evidence-pack.json`; a.click(); URL.revokeObjectURL(a.href);
  }

  function updateReviewDecision(id: string, patch: Partial<ReviewDecision>) {
    setReviewDecisions(current => ({ ...current, [id]: { verified: false, verifiedUrl: "", note: "", ...current[id], ...patch } }));
  }

  const blockers = checks.filter((c) => c.severity === "blocker" && !c.passed);
  const passedCount = checks.filter((c) => c.passed).length;
  const visibleRuns = runs.filter(run => (runTypeFilter === "all" || run.reportType === runTypeFilter) && (runStatusFilter === "all" || run.status === runStatusFilter));
  const canPublish = Boolean(collection && draft && checks.length && blockers.length === 0 && approved);
  const progress = useMemo(() => collection ? draft ? checks.length ? approved ? 100 : 82 : 58 : 30 : 8, [collection, draft, checks, approved]);
  const workflowSteps: { Icon: LucideIcon; label: string; done: boolean }[] = [
    { Icon: Database, label: "采集事实", done: !!collection },
    { Icon: Sparkles, label: "生成内容", done: !!draft },
    { Icon: ShieldCheck, label: "质量检查", done: checks.length > 0 },
    { Icon: CloudUpload, label: "CMS发布", done: !!lastPublish },
  ];

  useEffect(() => { refreshRuns(); }, []);

  return <main className="studio-shell min-h-screen text-[#eef5ef]">
    <Toaster theme="dark" richColors />
    <header className="studio-header border-b border-white/10 px-5 py-4 lg:px-8"><div className="mx-auto flex max-w-[1500px] items-center justify-between">
      <div className="flex items-center gap-3"><div className="brand-mark grid size-10 place-items-center text-[#07110b]"><Activity size={19}/></div><div><div className="flex items-center gap-2"><h1 className="text-sm font-semibold tracking-[.09em]">HOTCOIN RESEARCH OPS</h1><span className="hidden text-[10px] text-white/30 sm:inline">INTERNAL WORKBENCH</span></div><p className="mt-0.5 text-xs text-white/45">市场内容生产、证据治理与交付控制台</p></div></div>
      <div className="flex items-center gap-3"><Badge variant="outline" className="border-[#97e763]/30 bg-[#97e763]/[.06] text-[#97e763]"><span className="mr-2 size-1.5 animate-pulse rounded-full bg-[#97e763]"/>LOCAL DEMO</Badge><Button onClick={() => collect()} disabled={collecting} className="studio-primary"><Play size={15}/>{collecting ? "正在采集" : "更新市场数据"}</Button></div>
    </div></header>

    <div className="mx-auto grid max-w-[1500px] gap-5 p-5 lg:grid-cols-[270px_minmax(0,1fr)] lg:p-8">
      <aside className="space-y-4"><section className="panel scope-panel p-5"><p className="eyebrow">UNIFIED OPERATIONS</p><h2 className="mt-3 text-base font-semibold">一个工作台，三类交付</h2><p className="mt-2 text-xs leading-5 text-white/45">合并入口、证据状态、审核与运行登记；不混用日报、周报和项目报告的内容口径。</p><div className="mt-5 space-y-2"><button type="button" onClick={()=>setActiveTab("weekly")} className="product-rail product-rail-crypto"><span><Layers3 size={15}/></span><div><b>加密市场周报</b><small>周日发布 · 周一至周六 · JSON</small></div><ArrowUpRight size={14}/></button><button type="button" onClick={()=>setActiveTab("daily-quality")} className="product-rail product-rail-tradfi"><span><FileCheck2 size={15}/></span><div><b>TradFi 美股日报</b><small>日报包 · 完整性检查</small></div><ArrowUpRight size={14}/></button></div></section><section className="panel p-5"><p className="eyebrow">生产进度</p><div className="mt-4 flex items-end justify-between"><span className="text-3xl font-semibold tracking-tight">{progress}%</span><span className="text-xs text-white/40">日报通用工作流</span></div><Progress value={progress} className="mt-4 h-1.5 bg-white/10"/>
        <div className="mt-5 space-y-4">{workflowSteps.map(({ Icon, label, done },i)=><div key={label} className="flex items-center gap-3"><div className={`grid size-7 place-items-center rounded-lg ${done?"bg-[#97e763]/15 text-[#97e763]":"bg-white/5 text-white/30"}`}><Icon size={14}/></div><span className={`text-sm ${done?"text-white/85":"text-white/35"}`}>{i+1}. {label}</span></div>)}</div>
      </section><section className="panel p-5"><p className="eyebrow">数据源状态</p><div className="mt-4 space-y-3">{collection?.sources.map(s=><div key={s.name} className="flex items-center justify-between"><span className="text-sm text-white/65">{s.name}</span><Badge className={s.ok?"bg-[#97e763]/10 text-[#97e763]":"bg-red-500/10 text-red-400"}>{s.ok?`${s.count} 条`:"失败"}</Badge></div>) || <p className="text-sm text-white/35">等待首次采集…</p>}</div>{collection&&<p className="mt-4 border-t border-white/8 pt-4 text-[11px] text-white/35">截止 {new Date(collection.collectedAt).toLocaleString("zh-CN")}</p>}</section></aside>

      <section className="min-w-0"><div className="workspace-intro mb-4"><div><p className="eyebrow text-[#97e763]">CONTENT PRODUCTION CONTROL PLANE</p><h2>研究内容生产工作台</h2><p>统一操作与治理；各报告仍保持独立时间窗口、数据模型与交付格式。</p></div><div className="workspace-stats"><span><b>03</b> 核心报告产品</span><span><b>01</b> 统一运行登记</span></div></div><Tabs value={activeTab} onValueChange={setActiveTab} className="w-full"><TabsList className="studio-tabs mb-4 grid h-auto w-full grid-cols-2 gap-1 rounded-2xl border border-white/10 p-1.5 sm:grid-cols-4 xl:grid-cols-9"><TabsTrigger value="collect"><small>DAILY</small>市场采集</TabsTrigger><TabsTrigger value="generate"><small>DAILY</small>内容生成</TabsTrigger><TabsTrigger value="validate"><small>DAILY</small>质量检查</TabsTrigger><TabsTrigger value="publish"><small>DELIVERY</small>发布控制</TabsTrigger><TabsTrigger value="report"><small>RESEARCH</small>项目报告</TabsTrigger><TabsTrigger value="weekly"><small>CRYPTO</small>每周洞察</TabsTrigger><TabsTrigger value="daily-facts"><small>TRADFI</small>事实底稿</TabsTrigger><TabsTrigger value="daily-quality"><small>TRADFI</small>日报检查</TabsTrigger><TabsTrigger value="runs"><small>CONTROL</small>运行登记</TabsTrigger></TabsList>
        <TabsContent value="collect" className="space-y-4"><div className="grid gap-4 xl:grid-cols-[1.25fr_.75fr]">
          <section className="panel overflow-hidden"><div className="panel-head"><div><p className="eyebrow">MARKET SNAPSHOT</p><h2 className="section-title">实时市场事实</h2></div><Button variant="ghost" size="sm" onClick={()=>collect()} disabled={collecting}><RefreshCw className={collecting?"animate-spin":""} size={15}/>刷新</Button></div><div className="grid gap-px bg-white/8 sm:grid-cols-2 xl:grid-cols-3">{collection?.tickers.map(t=><article key={t.symbol} className="bg-[#101512] p-5"><div className="flex items-center justify-between"><strong>{t.symbol}</strong><span className={`text-xs ${t.change24h>=0?"text-[#73f2a7]":"text-red-400"}`}>{t.change24h>=0?"+":""}{t.change24h.toFixed(2)}%</span></div><p className="mt-3 text-2xl font-semibold tracking-tight">${fmtPrice(t.price)}</p><p className="mt-1 text-xs text-white/35">24h量 ${new Intl.NumberFormat("en",{notation:"compact"}).format(t.volume24h)}</p></article>) || Array.from({length:6}).map((_,i)=><div key={i} className="h-32 animate-pulse bg-white/[.025]"/>)}</div></section>
          <section className="panel"><div className="panel-head"><div><p className="eyebrow">SOURCE QUEUE</p><h2 className="section-title">资讯事件</h2></div><Badge variant="outline" className="border-white/10 text-white/50">{collection?.news.length || 0}</Badge></div><div className="max-h-[430px] divide-y divide-white/8 overflow-auto">{collection?.news.map((n,i)=><a href={n.url} target="_blank" rel="noreferrer" key={`${n.url}-${i}`} className="block p-4 transition hover:bg-white/[.035]"><p className="line-clamp-2 text-sm leading-6 text-white/80">{n.title}</p><div className="mt-2 flex justify-between text-[11px] text-white/35"><span>{n.source}</span><span>{n.publishedAt?new Date(n.publishedAt).toLocaleString("zh-CN"):"时间未知"}</span></div></a>) || <p className="p-5 text-sm text-white/35">启动后将自动采集，也可以点击“开始采集”。</p>}</div></section>
        </div>
          {(collection?.equities?.length || collection?.etfFlows?.length || collection?.calendar?.length) ? <section className="panel p-5"><div className="grid gap-6 lg:grid-cols-3">
            {collection?.equities?.length ? <div><p className="eyebrow">US EQUITIES · 上收盤</p><div className="mt-3 space-y-2">{collection.equities.map(e=><div key={e.symbol} className="flex items-center justify-between gap-3 text-sm"><span className="text-white/65">{e.name}</span><span className="text-right"><span className="text-white/85">{fmtPrice(e.price)}</span> <span className={`text-xs ${e.changePct>=0?"text-[#73f2a7]":"text-red-400"}`}>{e.changePct>=0?"+":""}{e.changePct.toFixed(2)}%</span></span></div>)}</div></div> : null}
            {collection?.etfFlows?.length ? <div><p className="eyebrow">SPOT ETF FLOWS · FARSIDE</p><div className="mt-3 space-y-2">{collection.etfFlows.map(f=><div key={f.asset} className="text-sm"><div className="flex items-center justify-between gap-3"><span className="text-white/65">{f.asset} ETF · {f.asOf}</span><span className={f.dailyFlow>=0?"text-[#73f2a7]":"text-red-400"}>{fmtFlow(f.dailyFlow)}</span></div><p className="mt-1 text-[11px] text-white/35">前一交易日 {Number.isFinite(f.prevDayFlow)?fmtFlow(f.prevDayFlow):"—"} · 近5個交易日 {fmtFlow(f.weekFlow)}（連續同向 {f.streakDays} 日）</p></div>)}</div></div> : null}
            {collection?.calendar?.length ? <div><p className="eyebrow">MACRO CALENDAR · UTC</p><div className="mt-3 max-h-36 space-y-2 overflow-auto pr-1">{collection.calendar.filter(e=>+new Date(e.date)>=+new Date(collection.collectedAt)-12*3600*1000).slice(0,6).map((e,i)=><div key={`${e.date}-${i}`} className="text-sm"><div className="flex items-center justify-between gap-3"><span className="text-white/65">{e.title}</span><Badge variant="outline" className={`border-white/10 text-[10px] ${e.impact==="High"?"text-amber-400":"text-white/40"}`}>{e.impact}</Badge></div><p className="mt-0.5 text-[11px] text-white/35">{new Date(e.date).toLocaleDateString("zh-CN",{month:"numeric",day:"numeric",timeZone:"UTC"})}（UTC）{e.region?` · ${e.region}`:""}{e.forecast?` · 預期 ${e.forecast}`:""}{e.previous?` · 前值 ${e.previous}`:""}</p></div>)}</div></div> : null}
          </div></section> : null}
        </TabsContent>

        <TabsContent value="generate"><section className="panel"><div className="panel-head"><div><p className="eyebrow">PROMPT WORKBENCH</p><h2 className="section-title">根据事实包生成日报</h2></div><Button onClick={generate} disabled={!collection||generating} className="bg-[#73f2a7] text-[#07110b] hover:bg-[#8ff6b7]"><Bot size={16}/>{generating?"生成中…":"生成内容"}</Button></div><div className="grid min-h-[620px] lg:grid-cols-2"><div className="border-b border-white/8 p-5 lg:border-b-0 lg:border-r"><Label className="mb-3 text-xs text-white/45">系统提示词</Label><Textarea value={prompt} onChange={e=>setPrompt(e.target.value)} className="min-h-[520px] resize-none border-white/10 bg-black/20 font-mono text-sm leading-7"/></div><div className="p-5"><div className="mb-3 flex items-center justify-between"><Label className="text-xs text-white/45">生成内容（可本地编辑）</Label><Button variant="ghost" size="sm" onClick={() => setShowPreview(!showPreview)} className="text-white/60"><Eye size={14}/>{showPreview ? "隐藏预览" : "预览效果"}</Button></div><Textarea value={draft} onChange={e=>{setDraft(e.target.value);setChecks([]);setSeo(null);setApproved(false)}} placeholder="生成后的文章会显示在这里…" className="min-h-[520px] resize-none border-white/10 bg-black/20 text-sm leading-7"/>{showPreview && <div className="mt-4 rounded-xl border border-white/10 bg-black/30 p-5 max-h-[520px] overflow-auto" dangerouslySetInnerHTML={{ __html: renderMarkdown(draft) }}/>}</div></div></section></TabsContent>

        <TabsContent value="validate"><section className="panel"><div className="panel-head"><div><p className="eyebrow">QUALITY GATE</p><h2 className="section-title">发布前自动检查</h2></div><Button onClick={validate} disabled={!draft||validating} className="bg-white text-black hover:bg-white/85"><ShieldCheck size={16}/>{validating?"检查中…":"开始检查"}</Button></div><div className="p-5"><div className="mb-5 grid gap-3 sm:grid-cols-3"><Metric label="已通过" value={`${passedCount}`} tone="green"/><Metric label="阻断问题" value={`${blockers.length}`} tone={blockers.length?"red":"green"}/><Metric label="检查总数" value={`${checks.length}`} tone="neutral"/></div><div className="space-y-2">{checks.length?checks.map(c=><div key={c.id} className="flex items-start gap-3 rounded-xl border border-white/8 bg-black/15 p-4">{c.passed?<CheckCircle2 className="mt-0.5 text-[#73f2a7]" size={17}/>:<CircleAlert className={`mt-0.5 ${c.severity==="blocker"?"text-red-400":"text-amber-400"}`} size={17}/>}<div><p className="text-sm font-medium">{c.label}</p><p className="mt-1 text-xs leading-5 text-white/40">{c.detail}</p></div><Badge variant="outline" className="ml-auto border-white/10 text-[10px] text-white/40">{c.severity==="blocker"?"阻断":"提醒"}</Badge></div>):<div className="grid min-h-64 place-items-center text-center"><div><ShieldCheck className="mx-auto text-white/15" size={42}/><p className="mt-4 text-sm text-white/40">生成内容后运行检查</p></div></div>}</div></div></section></TabsContent>

        <TabsContent value="weekly"><section className="panel"><div className="panel-head"><div><p className="eyebrow">WEEKLY INSIGHT · GOVERNED RUN</p><h2 className="section-title">每周洞察（Hotcoin Research 周报）</h2></div><div className="flex gap-2"><Button variant="ghost" onClick={() => runWeekly("draft")} disabled={wkBusy} className="border border-white/15 text-white/80 hover:bg-white/5"><RefreshCw size={15}/>采集底稿</Button><Button onClick={() => runWeekly("generate")} disabled={wkBusy} className="bg-[#73f2a7] text-[#07110b] hover:bg-[#8ff6b7]"><Sparkles size={15}/>{wkBusy ? "运行中…" : "AI 生成周报 JSON"}</Button></div></div>
          <div className="mx-5 mb-4 rounded-xl border border-[#73f2a7]/20 bg-[#73f2a7]/5 p-3 text-xs leading-5 text-white/65">本次固定窗口：<b className="text-[#73f2a7]">{defaultWeeklyWindow().label}（北京时间）</b>。周日发布，回顾当周周一 00:00 至周六 23:59；运营确认窗口建议为周日 09:00–18:00（北京时间）。HYPE K 线失败时保留空值，不再用 24h 涨跌回填 7 日字段。</div>
          <div className="mx-5 mb-3 flex items-start gap-3 rounded-xl border border-white/10 bg-black/20 p-3"><Checkbox id="weekly-approval" checked={wkApproved} onCheckedChange={v=>setWkApproved(v===true)} /><Label htmlFor="weekly-approval" className="text-xs leading-5 text-white/65">已人工核对报告窗口、来源状态和缺失字段。未确认时，周报运行将被质量门禁标记为不可发布。</Label></div>
          {wkBusy && <div className="mx-5 mb-4 rounded-xl border border-white/10 bg-black/20 p-4 text-sm text-white/60">正在采集多数据源底稿（币种 K 线 / 资金费率 / OI / 稳定币 / TVL），约需 10–30 秒…</div>}
          {wkData && <div className="space-y-4 px-5 pb-5">
            {wkData.warning && <div className="rounded-xl border border-amber-400/20 bg-amber-400/5 p-3 text-xs leading-5 text-amber-300">⚠ {wkData.warning}</div>}
            <div className="rounded-xl border border-white/8 bg-black/20 p-4 text-xs leading-5"><div className="flex items-center justify-between"><p className="text-white/45">运行批次 <code>{wkData.runId}</code></p><Badge className={wkData.quality.passed ? "bg-[#73f2a7]/10 text-[#73f2a7]" : "bg-red-400/10 text-red-300"}>{wkData.quality.passed ? "质检可交付" : "质检阻断"}</Badge></div><p className="mt-2 text-white/55">窗口：{wkData.reportWindow.label}（北京时间）</p><div className="mt-3 space-y-1">{wkData.quality.checks.map(c=><p key={c.id} className={c.passed ? "text-[#73f2a7]" : "text-red-300"}>{c.passed ? "✓" : "✕"} {c.label} · {c.detail}</p>)}</div><p className="mt-3 text-white/40">证据包：{wkData.run.artifacts.join(" · ")}</p></div>
            {wkData.weekly && <div className="rounded-xl border border-[#73f2a7]/25 bg-[#73f2a7]/5 p-4 text-sm"><p className="text-[#73f2a7]">✓ weekly_data.json 已生成（字段名与规格一致），可直接下载交付</p></div>}
            <div className="rounded-xl border border-white/8 bg-black/20 p-4">
              <div className="mb-2 flex items-center justify-between"><p className="text-xs text-white/45">{wkData.weekly ? "weekly_data.json（AI 生成）" : "weekly_data_draft.json（底稿）"}</p><div className="flex gap-1"><Button variant="ghost" size="sm" onClick={downloadWeekly} className="text-white/60">下载 JSON</Button><Button variant="ghost" size="sm" onClick={downloadWeeklyEvidence} className="text-white/60">下载证据包</Button></div></div>
              <pre className="max-h-[420px] overflow-auto whitespace-pre-wrap break-all text-xs leading-5 text-white/70">{JSON.stringify(wkData.weekly || wkData.draft, null, 2)}</pre>
            </div>
            <div className="rounded-xl border border-amber-400/20 bg-amber-400/[.035] p-4">
              <div className="flex flex-wrap items-center justify-between gap-2"><div><p className="text-sm font-medium text-amber-100">待核验资讯与日历线索</p><p className="mt-1 text-xs leading-5 text-amber-100/55">线索默认不进入正式周报。勾选“已核验”后仍须填写原始/权威链接；审核记录只写入下载的证据包，当前本地预览不跨重启保存。</p></div><Badge variant="outline" className="border-amber-300/25 text-amber-200">{wkData.evidenceReviewQueue?.length || 0} 条待核验</Badge></div>
              <div className="mt-4 space-y-3">{wkData.evidenceReviewQueue?.length ? wkData.evidenceReviewQueue.map(item => { const decision = reviewDecisions[item.id] || { verified: false, verifiedUrl: "", note: "" }; return <div key={item.id} className="rounded-lg border border-white/10 bg-black/20 p-3"><div className="flex flex-wrap items-start justify-between gap-2"><div className="min-w-0"><a href={item.sourceUrl} target="_blank" rel="noreferrer" className="text-sm leading-5 text-white/85 underline decoration-white/20 underline-offset-4 hover:text-[#97e763]">{item.title}</a><p className="mt-1 text-[11px] text-white/40">{item.kind === "news" ? "新闻线索" : "宏观日历"} · {item.source} · {item.observedAt ? new Date(item.observedAt).toLocaleString("zh-CN") : "时间未知"}</p></div><label className="flex items-center gap-2 text-xs text-amber-100/80"><Checkbox checked={decision.verified} onCheckedChange={value => updateReviewDecision(item.id, { verified: value === true })}/>已核验</label></div><p className="mt-2 text-xs leading-5 text-white/50">{item.reason}</p><div className="mt-3 grid gap-2 sm:grid-cols-2"><Input value={decision.verifiedUrl} onChange={event=>updateReviewDecision(item.id, { verifiedUrl: event.target.value })} placeholder="核验后的原始/权威链接（必填）" className="border-white/10 bg-black/20 text-xs"/><Input value={decision.note} onChange={event=>updateReviewDecision(item.id, { note: event.target.value })} placeholder="核验备注：主体、数字、适用栏目" className="border-white/10 bg-black/20 text-xs"/></div>{decision.verified && !decision.verifiedUrl.trim() && <p className="mt-2 text-[11px] text-red-300">已核验状态缺少原始/权威链接；该项仍不可作为发布事实。</p>}</div> }) : <p className="text-xs text-white/45">当前缓存没有落在本报告窗口内的 RSS/公开日历线索。</p>}</div>
            </div>
          </div>}
          </section></TabsContent>

        <TabsContent value="daily-facts"><section className="panel"><div className="panel-head"><div><p className="eyebrow">TRADFI DAILY · FACT PACK</p><h2 className="section-title">日报三线事实底稿</h2></div><Button onClick={planDailyFacts} className="bg-[#73f2a7] text-[#07110b] hover:bg-[#8ff6b7]"><ShieldCheck size={16}/>校验并登记</Button></div><div className="grid gap-5 p-5 lg:grid-cols-2"><div><p className="mb-3 text-xs leading-5 text-white/45">录入三条不可混用时间线：美股正式收盘、Hotcoin 行情快照、宏观事件日历。每条均需时间、时区、来源 URL、证据编号，并在 evidence 台账中对应。</p><Textarea value={dailyFactInput} onChange={event=>setDailyFactInput(event.target.value)} className="min-h-[520px] border-white/10 bg-black/20 font-mono text-xs leading-6"/></div><div className="rounded-xl border border-white/8 bg-black/20 p-4"><p className="text-sm font-medium">生成边界</p><p className="mt-2 text-xs leading-6 text-white/45">这里只创建可追溯事实底稿和运行记录。缺任一时间线或证据关联时会阻断；不会生成正文、图表，也不发布 CMS。</p>{dailyFactPlan && <div className="mt-5 space-y-2"><p className={dailyFactPlan.plan.blockers.length ? "text-sm text-red-300" : "text-sm text-[#73f2a7]"}>{dailyFactPlan.plan.blockers.length ? `已阻断：${dailyFactPlan.plan.blockers.join("、")}` : "事实底稿齐全，待运营确认。"}</p>{dailyFactPlan.plan.threeTimelines.map(line=><div key={line.key} className={"rounded-lg border p-3 text-xs "+(line.present ? "border-[#73f2a7]/20 bg-[#73f2a7]/5 text-[#73f2a7]" : "border-red-400/20 bg-red-400/5 text-red-300")}>{line.present ? "✓" : "✕"} {line.label} · {line.present ? `${line.asOf} · ${line.timezone}` : "缺少来源、时间或证据编号"}</div>)}{dailyFactPlan.plan.checks.map(check=><div key={check.id} className="text-xs text-white/50">{check.passed ? "✓" : "✕"} {check.label} · {check.detail}</div>)}<div className="mt-3 flex flex-wrap gap-2"><Button variant="outline" size="sm" onClick={downloadDailyFactPack} className="border-white/15 text-white/75 hover:bg-white/5">下载事实底稿</Button><Button variant="ghost" size="sm" onClick={()=>downloadRunManifest(dailyFactPlan.run)} className="text-white/65">下载运行清单</Button></div></div>}</div></div></section></TabsContent>

        <TabsContent value="daily-quality"><section className="panel"><div className="panel-head"><div><p className="eyebrow">TRADFI DAILY · PACKAGE CHECK</p><h2 className="section-title">日报交付包完整性检查</h2></div><Button onClick={checkDailyPackage} className="bg-[#73f2a7] text-[#07110b] hover:bg-[#8ff6b7]"><ClipboardCheck size={16}/>检查并登记</Button></div><div className="grid gap-5 p-5 lg:grid-cols-2"><div><Label className="mb-2 block text-xs text-white/45">日报归档日期</Label><Input type="date" value={dailyDate} onChange={e=>setDailyDate(e.target.value)} className="mb-1 border-white/10 bg-black/20"/><p className="mb-4 text-[11px] leading-5 text-white/35">该日期是日报交付包归档日期；美股正式收盘、Hotcoin 快照与宏观事件时间仍以 evidence.md 为准。</p><Label className="mb-2 block text-xs text-white/45">交付文件清单（每行一个相对路径）</Label><Textarea value={dailyFiles} onChange={e=>setDailyFiles(e.target.value)} className="min-h-[300px] border-white/10 bg-black/20 font-mono text-xs leading-6"/></div><div className="rounded-xl border border-white/8 bg-black/20 p-4"><p className="text-sm font-medium">检查规则</p><p className="mt-2 text-xs leading-6 text-white/45">中文稿、英文稿、evidence.md、双语绘图 JSON、共享固定封面、中英文各 3 张图。默认清单对应已归档的 2026-11-12 交付包；此处仅检查完整性并登记，不改动原日报生产逻辑，也不代表已发布。</p><label htmlFor="daily-approval" className="mt-4 flex cursor-pointer items-start gap-3 rounded-lg border border-amber-300/20 bg-amber-300/5 p-3 text-xs leading-5 text-amber-100/80"><input id="daily-approval" type="checkbox" checked={dailyApproved} onChange={e=>setDailyApproved(e.target.checked)} className="mt-1 size-3.5 accent-[#97e763]"/><span><b className="font-medium">运营已确认可交付</b><br/>未勾选时，完整交付包仍登记为“待人工确认”，不能视为已交付或已发布。</span></label>{dailyQuality && <div className="mt-5 space-y-2">{dailyQuality.checks.map(c=><div key={c.id} className={"rounded-lg border p-3 text-xs "+(c.passed ? "border-[#73f2a7]/20 bg-[#73f2a7]/5 text-[#73f2a7]" : "border-red-400/20 bg-red-400/5 text-red-300")}>{c.passed ? "✓" : "✕"} {c.label} · {c.detail}</div>)}<Button variant="outline" size="sm" onClick={()=>downloadRunManifest(dailyQuality.run)} className="border-white/15 text-white/75 hover:bg-white/5">下载运行清单</Button></div>}</div></div></section></TabsContent>

          <TabsContent value="runs"><section className="panel"><div className="panel-head"><div><p className="eyebrow">REPORT RUN REGISTRY</p><h2 className="section-title">报告运行登记</h2></div><Button variant="ghost" onClick={refreshRuns}><RefreshCw size={15}/>刷新</Button></div><div className="p-5"><p className="mb-4 text-xs leading-5 text-white/45">记录日报、周报、项目报告的周期、来源、质检、人工确认与交付清单。未绑定 D1 的本地预览环境仅保留当前服务会话内记录。</p><div className="mb-4 grid gap-3 sm:grid-cols-2"><label className="text-xs text-white/45">报告类型<select value={runTypeFilter} onChange={e=>setRunTypeFilter(e.target.value as typeof runTypeFilter)} className="mt-1.5 block w-full rounded-md border border-white/10 bg-black/30 p-2 text-sm text-white/80"><option value="all">全部报告</option><option value="tradfi-daily">TradFi 日报</option><option value="crypto-weekly">加密市场周报</option><option value="tokenized-stock-report">项目报告</option></select></label><label className="text-xs text-white/45">处理状态<select value={runStatusFilter} onChange={e=>setRunStatusFilter(e.target.value as typeof runStatusFilter)} className="mt-1.5 block w-full rounded-md border border-white/10 bg-black/30 p-2 text-sm text-white/80"><option value="all">全部状态</option><option value="draft">待人工确认</option><option value="blocked">已阻断</option><option value="ready">待交付</option></select></label></div><div className="space-y-3">{visibleRuns.length ? visibleRuns.map(run=><div key={run.runId} className="rounded-xl border border-white/8 bg-black/20 p-4"><div className="flex items-start justify-between gap-4"><div><p className="font-medium">{run.reportType === "crypto-weekly" ? "每周洞察" : run.reportType === "tradfi-daily" ? "TradFi 日报" : "代币化美股项目报告"} <span className="ml-2 font-mono text-xs text-white/40">{run.runId}</span></p><p className="mt-1 text-xs text-white/50">{"label" in run.reportWindow ? run.reportWindow.label : run.reportWindow.date} · {run.sources.map(s=>s.name+":"+s.status).join(" / ")}</p></div><Badge className={run.status === "ready" ? "bg-[#73f2a7]/10 text-[#73f2a7]" : run.status === "draft" ? "bg-amber-300/10 text-amber-200" : "bg-red-400/10 text-red-300"}>{run.status === "ready" ? "待交付" : run.status === "draft" ? "待人工确认" : "已阻断"}</Badge></div>{run.status === "blocked" && <div className="mt-3 rounded-lg border border-red-400/15 bg-red-400/5 p-3 text-xs leading-5 text-red-200"><b>需处理：</b>{run.quality.filter(c=>c.severity==="blocker"&&!c.passed).map(c=>c.label+"（"+c.detail+"）").join("；") || "请核对来源与交付文件后重跑。"}</div>}<p className="mt-3 text-xs text-white/40">交付清单：{run.artifacts.join(" · ")}</p><div className="mt-3 flex flex-wrap gap-2"><Button variant="outline" size="sm" onClick={()=>downloadRunManifest(run)} className="border-white/15 text-white/75 hover:bg-white/5">下载运行清单</Button><Button variant="ghost" size="sm" onClick={()=>retryRun(run)} className="text-white/65">{run.status==="blocked"?"处理后重跑":"打开对应流程"}</Button></div></div>) : <div className="grid min-h-48 place-items-center text-center text-sm text-white/40"><div><Archive className="mx-auto mb-3 text-white/15" size={38}/><p>{runs.length ? "当前筛选条件下没有运行记录。" : "还没有运行记录。运行任一报告后会自动登记。"}</p></div></div>}</div></div></section></TabsContent>

        <TabsContent value="report"><section className="panel"><div className="panel-head"><div><p className="eyebrow">TOKENIZED STOCK REPORT</p><h2 className="section-title">代币化美股项目报告</h2></div><div className="flex gap-2"><Button variant="outline" onClick={loadProjectReportDemo} disabled={srBusy} className="border-white/15 text-white/80 hover:bg-white/5">填入演示案例</Button><Button onClick={runStockReport} disabled={srBusy} className="bg-[#73f2a7] text-[#07110b] hover:bg-[#8ff6b7]"><Bot size={16}/>{srBusy?"前置检查并生成中…":"前置检查并生成"}</Button></div></div>
          <div className="mx-5 mt-4 rounded-xl border border-sky-400/20 bg-sky-400/5 p-3 text-xs leading-5 text-sky-100/80">演示路径：点击“填入演示案例”→ 保持人工确认未勾选可展示阻断 → 勾选并生成可展示质检、三语正文、海报与运行登记。案例仅用于验证内部流程，不代表 Hotcoin 已审核、已发布或对项目作出任何推荐。</div>
          <div className="grid gap-4 p-5 sm:grid-cols-2 xl:grid-cols-4">
            <div><Label className="mb-2 text-xs text-white/45">公司中英文名 *</Label><Input value={srForm.company} onChange={e=>setSrForm({...srForm,company:e.target.value})} placeholder="甲骨文 / Oracle" className="border-white/10 bg-black/20"/></div>
            <div><Label className="mb-2 text-xs text-white/45">正股代码 *</Label><Input value={srForm.ticker} onChange={e=>setSrForm({...srForm,ticker:e.target.value})} placeholder="ORCL" className="border-white/10 bg-black/20"/></div>
            <div><Label className="mb-2 text-xs text-white/45">Hotcoin 交易代码 *</Label><Input value={srForm.code} onChange={e=>setSrForm({...srForm,code:e.target.value})} placeholder="ORCLB" className="border-white/10 bg-black/20"/></div>
            <div><Label className="mb-2 text-xs text-white/45">发行方 / 公链 / 合约地址（可选）</Label><Input value={srForm.issuer} onChange={e=>setSrForm({...srForm,issuer:e.target.value})} placeholder="如 xStocks / Solana" className="border-white/10 bg-black/20"/></div>
          </div>
          <div className="mx-5 mb-4 flex items-start gap-3 rounded-xl border border-white/10 bg-black/20 p-3"><Checkbox id="project-report-approval" checked={srApproved} onCheckedChange={v=>setSrApproved(v===true)} /><Label htmlFor="project-report-approval" className="text-xs leading-5 text-white/65">已人工核对项目主体、发行结构、行情来源和所有待核验字段。未确认时仍可生成草稿包，但质量门禁将阻断正式交付。</Label></div>
          {srPre && <div className="mx-5 mb-4 rounded-xl border border-white/8 bg-black/20 p-4 text-sm">
            {srPre.dup ? <p className="text-red-400">✗ 查重命中：该标的已发过报告「{srPre.dup.title}」（{new Date(srPre.dup.createdTime).toLocaleDateString("zh-CN")}），流程终止。文章地址：/learn/article/{srPre.dup.slug}</p>
              : <p className="text-[#73f2a7]">✓ 前置检查通过：学院「项目报告」栏目共 {srPre.reports.length} 条已发报告，未命中该标的。最近 3 条：{srPre.reports.slice(0,3).map(r=>r.title).join(" · ")}</p>}
          </div>}
          {srData && <div className="space-y-4 px-5 pb-2">
            <div className="rounded-xl border border-white/8 bg-black/20 p-4 text-xs leading-5"><div className="flex items-center justify-between"><p className="text-white/45">项目报告批次 <code>{srData.runId}</code></p><Badge className={srData.quality.passed ? "bg-[#73f2a7]/10 text-[#73f2a7]" : "bg-red-400/10 text-red-300"}>{srData.quality.passed ? "质检可交付" : "质检阻断"}</Badge></div><div className="mt-3 space-y-1">{srData.quality.checks.map(c=><p key={c.id} className={c.passed ? "text-[#73f2a7]" : c.severity === "warning" ? "text-amber-300" : "text-red-300"}>{c.passed ? "✓" : "✕"} {c.label} · {c.detail}</p>)}</div></div>
            <div className="grid gap-3 sm:grid-cols-2">
              <div className="rounded-xl border border-white/8 bg-black/20 p-4 text-sm"><p className="text-xs text-white/45">代币层（Hotcoin）</p><p className="mt-1">{srData.tokenOk ? <>价格 {srData.tokenPrice}（24h {srData.tokenChange}）</> : <span className="text-red-400">交易对验证失败</span>}</p></div>
              <div className="rounded-xl border border-white/8 bg-black/20 p-4 text-sm"><p className="text-xs text-white/45">正股层（{srData.stockName || srForm.ticker}）</p><p className="mt-1">{srData.stockOk ? <>价格 {srData.stockPrice}（{srData.stockChange}）</> : <span className="text-red-400">行情获取失败</span>}</p></div>
            </div>
            <div className="rounded-xl border border-white/8 bg-black/20 p-4"><p className="mb-2 text-xs text-white/45">数据台账（缺失项已列入人工确认）</p><div className="space-y-1 text-xs leading-5 text-white/60">{srData.ledger.map(l=><div key={l.item}>{l.pending?"◦ ":"• "}<span className="text-white/85">{l.item}</span>｜{l.value}｜{l.source}{l.asOf?`｜截至 ${l.asOf}`:""}</div>)}</div></div>
            <div className="rounded-xl border border-white/8 bg-black/20 p-4"><p className="mb-2 text-xs text-white/45">相关新闻（近 90 天，{srData.relatedNews.length} 条）</p><div className="space-y-1 text-xs leading-5 text-white/60">{srData.relatedNews.length?srData.relatedNews.map(n=><div key={n.url}>• {n.title}（{n.source}）</div>):<div>近 90 天未见该公司相关新闻</div>}</div></div>
            {srData.warnings.length>0 && <div className="rounded-xl border border-amber-400/20 bg-amber-400/5 p-3 text-[11px] leading-5 text-amber-300">{srData.warnings.map(w=><p key={w}>• {w}</p>)}</div>}
          </div>}
          {srData && <ProjectReportWorkspace data={srData} locale={srLocale} draft={srDraft} showPreview={showSrPreview} onLocale={switchSrLocale} onDraft={updateSrDraft} onPreview={()=>setShowSrPreview(!showSrPreview)} onDownload={downloadFile} onPackage={downloadReportPackage} countChars={countSrChars}/>}
        </section></TabsContent>

        <TabsContent value="publish"><section className="panel"><div className="panel-head"><div><p className="eyebrow">CMS DELIVERY</p><h2 className="section-title">连接并发布到CMS</h2></div><Badge className={canPublish?"bg-[#73f2a7]/10 text-[#73f2a7]":"bg-white/5 text-white/35"}>{canPublish?"允许发布":"发布锁定"}</Badge></div><div className="grid gap-6 p-5 lg:grid-cols-2"><div className="space-y-5"><div><Label className="mb-2 text-xs text-white/45">CMS API地址</Label><Input value={cmsUrl} onChange={e=>setCmsUrl(e.target.value)} className="border-white/10 bg-black/20"/></div><div><Label className="mb-2 text-xs text-white/45">Bearer Token</Label><Input type="password" value={cmsToken} onChange={e=>setCmsToken(e.target.value)} className="border-white/10 bg-black/20"/></div><div className="rounded-xl border border-white/8 bg-black/20 p-4 text-xs leading-6 text-white/45">本地演示接收端：<code>/api/cms/articles</code>，文章页 <code>/news/articles?id=…</code>；站点地图 <code>/news/sitemap.xml</code>，订阅 <code>/news/rss.xml</code>。<br/>正式接入时替换为你的CMS地址和Token。请求包含幂等键，避免重复发布。</div>
          <div className="rounded-xl border border-white/8 bg-black/20 p-4"><div className="flex items-center justify-between"><div><p className="eyebrow">SEO PREVIEW</p><h3 className="text-sm font-medium text-white/80">搜索摘要与结构化数据</h3></div><Button variant="ghost" size="sm" onClick={previewSeo} disabled={!collection||!draft.trim()}>生成SEO预览</Button></div>
          {seo && <div className="mt-4 space-y-3"><div><p className="text-[11px] text-white/35">Meta Title（{seo.metaTitle.length}/60）</p><p className="text-sm text-[#8ab4f8]">{seo.metaTitle}</p></div><div><p className="text-[11px] text-white/35">Meta Description（{seo.metaDescription.length}/155）</p><p className="text-sm leading-6 text-white/70">{seo.metaDescription}</p></div><div className="flex flex-wrap gap-1.5">{seo.keywords.map(k=><Badge key={k} variant="outline" className="border-white/10 text-[11px] text-white/50">{k}</Badge>)}</div><p className="text-[11px] text-white/35">FAQ {seo.faq.length} 条 · 结构化数据 {seo.jsonLd.map((j)=>String((j as {"@type": string})["@type"])).join(" + ")} · slug <code>{seo.slug}</code></p>{seo.warnings.length ? <div className="rounded-lg border border-amber-400/20 bg-amber-400/5 p-3 text-[11px] leading-5 text-amber-300">{seo.warnings.map(w=><p key={w}>• {w}</p>)}</div> : <p className="text-[11px] text-[#73f2a7]">SEO 项全部就绪</p>}</div>}</div></div><div className="rounded-2xl border border-white/8 bg-black/20 p-5"><h3 className="text-sm font-medium">发布确认</h3><div className="mt-4 space-y-3 text-sm text-white/55"><p>• 已采集真实行情和来源</p><p>• 已完成人工内容检查</p><p>• 所有阻断规则必须通过</p></div><div className="my-5 flex items-start gap-3 rounded-xl border border-[#73f2a7]/15 bg-[#73f2a7]/5 p-4"><Checkbox id="approval" checked={approved} onCheckedChange={v=>setApproved(v===true)} disabled={!checks.length||blockers.length>0}/><Label htmlFor="approval" className="text-sm leading-5 text-white/75">我已人工核对正文、数字、来源和发布时间，并确认发布</Label></div><Button onClick={publish} disabled={!canPublish||publishing} className="w-full bg-[#73f2a7] text-[#07110b] hover:bg-[#8ff6b7]"><CloudUpload size={16}/>{publishing?"正在发布…":"通过CMS API发布"}</Button>{lastPublish&&<div className="mt-4 rounded-xl border border-[#73f2a7]/20 p-4 text-xs text-[#73f2a7]"><p>发布成功 · {lastPublish.id}</p><p className="mt-1 opacity-60">{new Date(lastPublish.publishedAt).toLocaleString("zh-CN")}</p></div>}</div></div></section></TabsContent>
      </Tabs></section>
    </div>
  </main>;
}

function Metric({label,value,tone}:{label:string;value:string;tone:"green"|"red"|"neutral"}) { const color=tone==="green"?"text-[#73f2a7]":tone==="red"?"text-red-400":"text-white"; return <div className="rounded-xl border border-white/8 bg-black/15 p-4"><p className="text-xs text-white/35">{label}</p><p className={`mt-2 text-2xl font-semibold ${color}`}>{value}</p></div>; }
