import { esc, listArticles } from "@/lib/news-shared";
import { renderMarkdown } from "@/lib/markdown-lite";
import type { Article } from "@/lib/article-store";

type Props = { params: Promise<{ locale: string; slug: string }> };

// KuCoin 同款文章 URL：/{locale}/news/articles/{slug}
export async function GET(request: Request, props: Props) {
  const { origin } = new URL(request.url);
  const { locale, slug } = await props.params;
  const articles = await listArticles(origin);
  const article = articles.find((a) => a.slug === slug && a.language.toLowerCase() === locale.toLowerCase())
    || articles.find((a) => a.slug === slug || a.id === slug); // 容错：仅按 slug/id 匹配
  if (!article) return notFound(origin);
  // 若以 id 或错误 locale 进入，301 到规范地址
  const canonicalPath = articleUrlOf(article);
  if (canonicalPath !== new URL(request.url).pathname) return Response.redirect(origin + canonicalPath, 301);
  return articlePage(request, article, articles);
}

function articleUrlOf(a: Article) {
  return `/${a.language.toLowerCase()}/news/articles/${a.slug}`;
}

function notFound(origin: string) {
  return new Response(html(`文章不存在`, `<p>文章不存在或已被清理。</p><p><a href="${origin}/news">返回报告列表</a></p>`, { origin, description: "文章不存在" }), { status: 404, headers: { "content-type": "text/html; charset=utf-8" } });
}

function articlePage(request: Request, article: Article, articles: Article[]) {
  const { origin } = new URL(request.url);
  const title = article.metaTitle || article.title;
  const description = article.metaDescription || "";
  const canonical = origin + articleUrlOf(article);
  const jsonLd: Record<string, unknown>[] = [{
    "@context": "https://schema.org", "@type": "NewsArticle",
    headline: title, description, inLanguage: article.language,
    datePublished: article.publishedAt, dateModified: article.publishedAt,
    articleSection: "市场报告", keywords: (article.keywords || []).join(", "),
    mainEntityOfPage: canonical,
  }];
  if (article.faq?.length) {
    jsonLd.push({
      "@context": "https://schema.org", "@type": "FAQPage",
      mainEntity: article.faq.map((f) => ({ "@type": "Question", name: f.question, acceptedAnswer: { "@type": "Answer", text: f.answer } })),
    });
  }
  const faqHtml = article.faq?.length
    ? `<section class="faq"><h2>常见问题</h2>${article.faq.map((f) => `<div class="qa"><h3>${esc(f.question)}</h3><p>${esc(f.answer)}</p></div>`).join("")}</section>`
    : "";
  const related = articles.filter((a) => a.id !== article.id).slice(0, 5);
  const relatedHtml = related.length
    ? `<nav class="related"><h2>相关报告</h2><ul>${related.map((a) => `<li><a href="${articleUrlOf(a)}">${esc(a.title)}</a></li>`).join("")}</ul></nav>`
    : "";
  const body = `
<p class="meta">${new Date(article.publishedAt).toLocaleString("zh-CN", { timeZone: "UTC" })}（UTC） · ${esc((article.symbols || []).join(" / "))}</p>
<article>${renderMarkdown(article.content)}</article>
${faqHtml}
${relatedHtml}
<p><a href="${origin}/news">← 更多每日市场报告</a></p>`;
  return new Response(html(title, body, { origin, canonical, description, keywords: article.keywords, jsonLd, og: { title, description, type: "article", publishedTime: article.publishedAt, url: canonical } }), { headers: { "content-type": "text/html; charset=utf-8" } });
}

function html(title: string, body: string, opts: { origin: string; canonical?: string; description?: string; keywords?: string[]; jsonLd?: Record<string, unknown>[]; og?: Record<string, string> }) {
  const { canonical, description, keywords, jsonLd, og } = opts;
  const meta = [
    `<meta charset="utf-8">`,
    `<meta name="viewport" content="width=device-width, initial-scale=1">`,
    `<title>${esc(title)}</title>`,
    description ? `<meta name="description" content="${esc(description)}">` : "",
    keywords?.length ? `<meta name="keywords" content="${esc(keywords.join(", "))}">` : "",
    canonical ? `<link rel="canonical" href="${canonical}">` : "",
    og ? Object.entries({
      "og:title": og.title, "og:description": og.description, "og:type": og.type,
      "article:published_time": og.publishedTime, "og:url": og.url,
    }).filter(([, v]) => v).map(([k, v]) => `<meta property="${k}" content="${esc(String(v))}">`).join("\n") : "",
    jsonLd?.length ? `<script type="application/ld+json">${JSON.stringify(jsonLd)}</script>` : "",
  ].filter(Boolean).join("\n");
  return `<!DOCTYPE html>
<html lang="zh-CN">
<head>
${meta}
<style>body{font-family:system-ui,sans-serif;max-width:760px;margin:0 auto;padding:2rem 1.25rem;color:#1a2320;line-height:1.8}h1{line-height:1.35}.meta{color:#6b7a74;font-size:.9em}article h1{font-size:1.6rem}article h2{font-size:1.25rem;border-bottom:1px solid #e3e8e6;padding-bottom:.3em;margin-top:2em}article h3{font-size:1.05rem;margin-top:1.5em}.faq .qa h3{margin:.9em 0 .2em;font-size:1rem}.related ul{margin:.5em 0;padding-left:1.2em}a{color:#0b6b4f}code{background:#f2f5f4;padding:.1em .35em;border-radius:4px}blockquote{border-left:3px solid #cfd8d4;margin:1em 0;padding:.2em 1em;color:#4d5d57}table{border-collapse:collapse}td,th{border:1px solid #d7dedb;padding:.35em .7em}</style>
</head>
<body>
${body}
</body>
</html>`;
}
