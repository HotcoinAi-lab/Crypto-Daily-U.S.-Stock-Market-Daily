import { articleUrl, esc, listArticles } from "@/lib/news-shared";

export async function GET(request: Request) {
  const origin = new URL(request.url).origin;
  const items = await listArticles(origin);
  const entries = items.map((a) => `    <item>\n      <title>${esc(a.title)}</title>\n      <link>${origin}${articleUrl(a)}</link>\n      <guid isPermaLink="true">${origin}${articleUrl(a)}</guid>\n      <pubDate>${new Date(a.publishedAt).toUTCString()}</pubDate>\n      <description>${esc(a.metaDescription || "")}</description>\n    </item>`);
  const xml = `<?xml version="1.0" encoding="UTF-8"?>\n<rss version="2.0"><channel>\n    <title>AI Market Studio 每日市场报告</title>\n    <link>${origin}/news</link>\n    <description>加密货币每日市场报告</description>\n${entries.join("\n")}\n  </channel></rss>`;
  return new Response(xml, { headers: { "content-type": "application/rss+xml; charset=utf-8" } });
}
