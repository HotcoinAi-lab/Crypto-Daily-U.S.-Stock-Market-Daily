import { esc, listArticles } from "@/lib/news-shared";

// 旧地址 /news/articles/{slug}（无 locale 前缀）→ 301 到 /{locale}/news/articles/{slug}
export async function GET(request: Request, props: { params: Promise<{ slug: string }> }) {
  const { origin } = new URL(request.url);
  const { slug } = await props.params;
  const articles = await listArticles(origin);
  const article = articles.find((a) => a.slug === decodeURIComponent(slug)) || articles[0];
  if (!article) return Response.redirect(`${origin}/news`, 301);
  return Response.redirect(`${origin}/${article.language.toLowerCase()}/news/articles/${encodeURIComponent(article.slug)}`, 301);
}
