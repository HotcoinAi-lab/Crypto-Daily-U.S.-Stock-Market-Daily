import { esc, listArticles } from "@/lib/news-shared";

// 旧地址 /news/articles?id=… 与 /news/articles/{slug} → 301 到 /{locale}/news/articles/{slug}
export async function GET(request: Request) {
  const { origin, searchParams } = new URL(request.url);
  const id = searchParams.get("id");
  const articles = await listArticles(origin);
  const article = (id ? articles.find((a) => a.id === id) : undefined) || articles[0];
  if (!article) return Response.redirect(`${origin}/news`, 301);
  return Response.redirect(`${origin}/${article.language.toLowerCase()}/news/articles/${esc(article.slug)}`, 301);
}
