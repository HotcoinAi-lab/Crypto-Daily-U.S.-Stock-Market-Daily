import { articleUrl, esc, listArticles } from "@/lib/news-shared";

// 新闻列表页：route handler 输出完整 HTML，保证搜索引擎可抓取
export async function GET(request: Request) {
  const origin = new URL(request.url).origin;
  const items = await listArticles(origin);
  const list = items.map((a) => `<li><a href="${articleUrl(a)}">${esc(a.title)}</a><span class="date">${new Date(a.publishedAt).toLocaleDateString("zh-CN", { timeZone: "UTC" })}</span></li>`).join("\n");
  const html = `<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>加密货币每日市场报告 | AI Market Studio</title>
<meta name="description" content="加密货币每日市场报告列表：主流資產行情、BTC/ETH 現貨 ETF 資金流、宏觀經濟日曆與行業動態。">
<link rel="canonical" href="${origin}/news">
<link rel="alternate" type="application/rss+xml" title="每日市場報告 RSS" href="${origin}/news/rss.xml">
<style>body{font-family:system-ui,sans-serif;max-width:760px;margin:0 auto;padding:2rem 1.25rem;color:#1a2320;line-height:1.7}li{margin:.5rem 0}.date{color:#6b7a74;font-size:.85em;margin-left:.5em}</style>
</head>
<body>
<h1>加密货币每日市场报告</h1>
${items.length ? `<ul>\n${list}\n</ul>` : "<p>暂无已发布报告。请在管理台完成采集、生成、检查并发布。</p>"}
</body>
</html>`;
  return new Response(html, { headers: { "content-type": "text/html; charset=utf-8" } });
}
