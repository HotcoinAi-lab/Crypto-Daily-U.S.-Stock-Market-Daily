import { articleUrl, listArticles } from "@/lib/news-shared";

export async function GET(request: Request) {
  const origin = new URL(request.url).origin;
  const items = await listArticles(origin);
  const urls = items.map((a) => `  <url><loc>${origin}${articleUrl(a)}</loc><lastmod>${a.publishedAt}</lastmod></url>`);
  const xml = `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n  <url><loc>${origin}/news</loc></url>\n${urls.join("\n")}\n</urlset>`;
  return new Response(xml, { headers: { "content-type": "application/xml; charset=utf-8" } });
}
