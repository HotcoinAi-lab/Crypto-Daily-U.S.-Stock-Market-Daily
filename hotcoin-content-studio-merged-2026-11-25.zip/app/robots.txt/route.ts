export async function GET(request: Request) {
  const origin = new URL(request.url).origin;
  const txt = `User-agent: *\nAllow: /\n\nSitemap: ${origin}/news/sitemap.xml\n`;
  return new Response(txt, { headers: { "content-type": "text/plain; charset=utf-8" } });
}
