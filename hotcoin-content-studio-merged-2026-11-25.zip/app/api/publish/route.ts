import { NextResponse } from "next/server";
import type { FactPack } from "@/lib/market-studio";
import { buildSeo } from "@/lib/seo";

export async function POST(request: Request) {
  const body = await request.json() as { cmsUrl?: string; cmsToken?: string; draft?: string; factPack?: FactPack; checks?: {passed:boolean;severity:string}[]; approved?: boolean };
  if (!body.approved || !body.checks?.length || body.checks.some(c=>c.severity==="blocker"&&!c.passed)) return NextResponse.json({ error: "内容未通过发布门禁" }, { status: 409 });
  if (!body.cmsUrl || !body.cmsToken || !body.draft || !body.factPack) return NextResponse.json({ error: "CMS配置或正文不完整" }, { status: 400 });
  const target = new URL(body.cmsUrl, request.url);
  const idempotencyKey = `daily-${body.factPack.collectedAt.slice(0,10)}-${body.draft.length}`;
  const seo = buildSeo(body.draft, body.factPack);
  try {
    const res = await fetch(target, { method: "POST", headers: { authorization: `Bearer ${body.cmsToken}`, "content-type": "application/json", "idempotency-key": idempotencyKey }, body: JSON.stringify({ contentType: "daily_market_report", language: "zh-CN", status: "published", title: body.draft.split("\n").find(Boolean)?.replace(/^#\s*/, "") || "市场日报", content: body.draft, symbols: body.factPack.tickers.map(t=>t.symbol), collectedAt: body.factPack.collectedAt, sourceAudit: body.factPack.sources, seo }) });
    const data = await res.json().catch(()=>({})); if (!res.ok) throw new Error((data as {error?:string}).error || `CMS HTTP ${res.status}`);
    return NextResponse.json({ ...(data as object), seo });
  } catch (error) { return NextResponse.json({ error: error instanceof Error ? error.message : "CMS发布失败" }, { status: 502 }); }
}
