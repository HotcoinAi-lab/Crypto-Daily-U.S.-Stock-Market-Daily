import { NextResponse } from "next/server";
import { fallbackDraft, type FactPack } from "@/lib/market-studio";
import { setPackCache } from "@/lib/pack-cache";
import { aiConfigured, chatComplete } from "@/lib/ai";
import { DEFAULT_MARKET_PROMPT } from "@/lib/prompts";

export async function POST(request: Request) {
  const { prompt, factPack } = await request.json() as { prompt?: string; factPack?: FactPack };
  if (!factPack?.tickers?.length) return NextResponse.json({ error: "缺少有效事实包" }, { status: 400 });
  // 回填图表缓存：服务器重启后缓存清空，生成时用前端传来的最新事实包回填，配图始终有数据
  setPackCache(factPack);
  if (!aiConfigured()) return NextResponse.json({ content: fallbackDraft(factPack), mode: "template" });
  const today = new Date().toLocaleDateString("zh-CN", { year: "numeric", month: "long", day: "numeric" });
  // 结构提示词由服务端强制（防止前端缓存旧版）；用户文本框内容仅作附加要求
  const userExtra = prompt && prompt.trim() && !prompt.includes("FACT_PACK") ? "\n\n【用户附加要求】" + prompt : "";
  const fullPrompt = `${DEFAULT_MARKET_PROMPT}${userExtra}\n\n【日期说明】今天的日期（当地时区）是 ${today}；FACT_PACK 采集于 ${factPack.collectedAt}。标题、导语与正文中的「当天日期」一律使用今天（当地时区）的日期，不要使用 UTC 日期。\n\nFACT_PACK（唯一事实来源）：\n${JSON.stringify(factPack)}`;
  try {
    const content = await chatComplete(fullPrompt);
    return NextResponse.json({ content, mode: "ai" });
  } catch (error) {
    // 模型调用失败时降级为安全模板稿（结构/配图齐全），不中断工作流
    return NextResponse.json({ content: fallbackDraft(factPack), mode: "template", warning: error instanceof Error ? error.message : "模型调用失败" });
  }
}
