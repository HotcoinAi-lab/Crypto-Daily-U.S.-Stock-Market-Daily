import { NextResponse } from "next/server";
import { getPackCache } from "@/lib/pack-cache";
import { etfFlowSvg, overviewSvg } from "@/lib/charts";

// 图表路由：从最新采集缓存生成 SVG 配图（无需浏览器渲染）
// GET /api/charts/overview.svg → 市场概览图卡
// GET /api/charts/etf-flow.svg → BTC ETF 资金流柱状图
export async function GET(request: Request, props: { params: Promise<{ name: string }> }) {
  const { name: rawName } = await props.params;
  const name = rawName.replace(/.svg$/i, "");
  const pack = getPackCache();
  if (!pack) {
    return new Response(`<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="630"><rect width="1200" height="630" fill="#0a1410"/><text x="600" y="315" fill="#8fa396" font-size="16" text-anchor="middle" font-family="system-ui">暂无数据：请先在「01 数据采集」执行采集</text></svg>`, { status: 200, headers: { "content-type": "image/svg+xml; charset=utf-8", "cache-control": "no-store" } });
  }
  const facts = pack.facts;
  let svg: string;
  if (name === "overview") svg = overviewSvg(facts);
  else if (name === "etf-flow") svg = etfFlowSvg(facts);
  else return NextResponse.json({ error: "未知图表" }, { status: 404 });
  return new Response(svg, { headers: { "content-type": "image/svg+xml; charset=utf-8", "cache-control": "no-store" } });
}
