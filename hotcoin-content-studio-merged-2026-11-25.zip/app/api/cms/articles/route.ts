import { NextResponse } from "next/server";
import { articleUrl, listArticles, upsertBySlug, type Article } from "@/lib/article-store";
import type { SeoMeta } from "@/lib/seo";

export async function POST(request: Request) {
  const expected = process.env.CMS_RECEIVER_SECRET || "local-demo-secret";
  if (request.headers.get("authorization") !== `Bearer ${expected}`) return NextResponse.json({ error: "CMS鉴权失败" }, { status: 401 });
  const key = request.headers.get("idempotency-key") || crypto.randomUUID();
  const payload = await request.json() as {
    title?: string; content?: string; language?: string; status?: string; symbols?: string[]; collectedAt?: string; sourceAudit?: unknown[];
    seo?: Partial<SeoMeta>;
  };
  if (!payload.title || !payload.content) return NextResponse.json({ error: "title和content为必填项" }, { status: 422 });
  const id = crypto.randomUUID(); const publishedAt = new Date().toISOString();
  const article: Article = {
    id, slug: payload.seo?.slug || `article-${id.slice(0, 8)}`, title: payload.title, content: payload.content,
    language: payload.language || "zh-CN", status: payload.status || "draft", symbols: payload.symbols || [],
    publishedAt, collectedAt: payload.collectedAt, sourceAudit: payload.sourceAudit || [],
    metaTitle: payload.seo?.metaTitle, metaDescription: payload.seo?.metaDescription, keywords: payload.seo?.keywords, faq: payload.seo?.faq,
  };
  // 以 slug 为稳定标识：同一天重复发布覆盖旧文，URL 保持不变（幂等键仅用于完全相同的重放）
  const replaced = upsertBySlug(article);
  return NextResponse.json({ ...article, url: articleUrl(article), replaced: Boolean(replaced) }, { status: replaced ? 200 : 201 });
}

export async function GET(request: Request) {
  const expected = process.env.CMS_RECEIVER_SECRET || "local-demo-secret";
  if (request.headers.get("authorization") !== `Bearer ${expected}`) return NextResponse.json({ error: "CMS鉴权失败" }, { status: 401 });
  return NextResponse.json({ items: listArticles() });
}
