import { NextResponse } from "next/server";
import type { FactPack } from "@/lib/market-studio";
import { buildSeo } from "@/lib/seo";

export async function POST(request: Request) {
  const { draft, factPack } = await request.json() as { draft?: string; factPack?: FactPack };
  if (!draft || !factPack) return NextResponse.json({ error: "缺少正文或事实包" }, { status: 400 });
  return NextResponse.json(buildSeo(draft, factPack));
}
