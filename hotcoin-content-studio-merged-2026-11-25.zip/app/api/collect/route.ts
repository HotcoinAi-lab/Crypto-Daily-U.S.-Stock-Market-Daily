import { NextResponse } from "next/server";
import { parseCnbcQuotes, parseFarsideFlows, parseFfCalendar, parseRss, type CalendarEvent, type EtfFlow, type EquityQuote, type NewsItem, type Ticker } from "@/lib/market-studio";
import { setPackCache } from "@/lib/pack-cache";

const symbols = ["BTCUSDT", "ETHUSDT", "SOLUSDT", "XRPUSDT", "BNBUSDT", "DOGEUSDT"];

const BROWSER_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36";

// 扩展源缓存（模块级，worker 实例存活期内有效；实例重启后自动失效，属 best-effort）
const extCache: { equities?: { at: number; data: EquityQuote[] }; etf?: { at: number; data: EtfFlow[] }; calendar?: { at: number; data: CalendarEvent[] } } = {};

async function fetchWithTimeout(url: string, ms = 9000, headers: Record<string, string> = {}) {
  const controller = new AbortController(); const timer = setTimeout(() => controller.abort(), ms);
  try { return await fetch(url, { signal: controller.signal, headers: { "user-agent": "AI-Market-Studio/1.0", ...headers }, cache: "no-store" }); }
  finally { clearTimeout(timer); }
}

export async function POST() {
  const collectedAt = new Date().toISOString(); const tickers: Ticker[] = []; const news: NewsItem[] = [];
  const equities: EquityQuote[] = []; const etfFlows: EtfFlow[] = []; const calendar: CalendarEvent[] = [];
  const sources: { name: string; ok: boolean; count: number; error?: string }[] = [];
  // Binance 官方行情镜像与主站依次尝试；部分地区直连 api.binance.com 受 DNS 污染影响会超时，
  // api1–api4 端口族在部分网络同样不可达，故不纳入，避免无谓的超时等待
  const binanceHosts = ["https://data-api.binance.vision", "https://api.binance.com"];
  let lastBinanceError = "";
  for (const host of binanceHosts) {
    try {
      const res = await fetchWithTimeout(`${host}/api/v3/ticker/24hr?symbols=${encodeURIComponent(JSON.stringify(symbols))}`);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const rows = await res.json() as { symbol: string; lastPrice: string; priceChangePercent: string; quoteVolume: string; closeTime: number }[];
      for (const row of rows) tickers.push({ symbol: row.symbol.replace("USDT", ""), price: Number(row.lastPrice), change24h: Number(row.priceChangePercent), volume24h: Number(row.quoteVolume), source: "Binance Spot", observedAt: new Date(row.closeTime).toISOString() });
      sources.push({ name: `Binance 行情（${host.replace("https://", "")}）`, ok: true, count: rows.length });
      lastBinanceError = "";
      break;
    } catch (error) { lastBinanceError = error instanceof Error ? error.message : "unknown"; }
  }
  if (lastBinanceError) sources.push({ name: "Binance 行情", ok: false, count: 0, error: lastBinanceError });

  // Binance 全部不可达时切换到 Gate.io 公共行情：仍是真实交易所数据（非模拟），来源如实标注
  if (!tickers.length) {
    try {
      const res = await fetchWithTimeout("https://api.gateio.ws/api/v4/spot/tickers", 8000);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const rows = await res.json() as { currency_pair: string; last: string; change_percentage: string; quote_volume: string }[];
      const wanted = new Set(symbols.map((s) => `${s.slice(0, -4)}_USDT`));
      const mapped = rows.filter((r) => wanted.has(r.currency_pair)).map((r) => ({
        symbol: r.currency_pair.split("_")[0],
        price: Number(r.last),
        change24h: Number(r.change_percentage),
        volume24h: Number(r.quote_volume),
        source: "Gate.io Spot",
        observedAt: collectedAt,
      })).filter((t) => Number.isFinite(t.price) && t.price > 0);
      if (!mapped.length) throw new Error("未匹配到目标交易对");
      tickers.push(...mapped);
      sources.push({ name: "Gate.io 行情（Binance 备用）", ok: true, count: mapped.length });
    } catch (error) { sources.push({ name: "Gate.io 行情（Binance 备用）", ok: false, count: 0, error: error instanceof Error ? error.message : "unknown" }); }
  }

  // RSS 资讯源选用当前网络环境可直连的站点；如所在网络可访问 CoinDesk，可加回：
  // { name: "CoinDesk", url: "https://www.coindesk.com/arc/outboundfeeds/rss/" }
  const feeds = [
    { name: "Cointelegraph", url: "https://cointelegraph.com/rss" },
    { name: "Decrypt", url: "https://decrypt.co/feed" },
  ];
  for (const feed of feeds) {
    try { const res = await fetchWithTimeout(feed.url); if (!res.ok) throw new Error(`HTTP ${res.status}`); const items = parseRss(await res.text(), feed.name); news.push(...items); sources.push({ name: feed.name, ok: true, count: items.length }); }
    catch (error) { sources.push({ name: feed.name, ok: false, count: 0, error: error instanceof Error ? error.message : "unknown" }); }
  }
  const uniqueNews = [...new Map(news.map((item) => [item.url, item])).values()].sort((a,b) => +new Date(b.publishedAt)-+new Date(a.publishedAt)).slice(0, 20);

  // 恐懼與貪婪指數（alternative.me 公開接口）；属辅助情绪指标，失败不阻断采集
  let fearGreed: { value: number; label: string } | undefined;
  try {
    const res = await fetchWithTimeout("https://api.alternative.me/fng/?limit=1");
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json() as { data?: { value?: string; value_classification?: string }[] };
    const entry = data.data?.[0];
    if (entry?.value != null && entry.value_classification) fearGreed = { value: Number(entry.value), label: entry.value_classification };
    sources.push({ name: "恐懼與貪婪指數", ok: Boolean(fearGreed), count: fearGreed ? 1 : 0, ...(fearGreed ? {} : { error: "未取得有效数据" }) });
  } catch (error) { sources.push({ name: "恐懼與貪婪指數", ok: false, count: 0, error: error instanceof Error ? error.message : "unknown" }); }

  // 以下三个扩展源彼此独立，并行采集；任一失败仅在该源状态中标注，不阻断其余数据。
  // 结果按 TTL 缓存：股指 10 分钟、ETF 资金流 30 分钟、日历 60 分钟，降低对限流源（如 ForexFactory）的请求频率
  const record = (name: string, ok: boolean, count: number, error?: string) => sources.push(ok ? { name, ok, count } : { name, ok, count, error });
  const fresh = <T,>(entry: { at: number; data: T } | undefined, ttlMs: number) => entry && Date.now() - entry.at < ttlMs ? entry.data : undefined;
  await Promise.allSettled([
    // 美股三大股指（CNBC 公共行情接口，免密钥）
    (async () => {
      const cached = fresh(extCache.equities, 10 * 60_000);
      if (cached) { equities.push(...cached); record("美股股指（CNBC）", true, cached.length, undefined); sources[sources.length - 1].name += "（缓存）"; return; }
      const res = await fetchWithTimeout("https://quote.cnbc.com/quote-html-webservice/restQuote/symbolType/symbol?symbols=.IXIC|.SPX|.DJI&requestMethod=itv&noform=1&partnerId=2&fund=1&output=json", 9000, { accept: "application/json" });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const quotes = parseCnbcQuotes(await res.json());
      if (!quotes.length) throw new Error("未取得有效报价");
      equities.push(...quotes); extCache.equities = { at: Date.now(), data: quotes }; record("美股股指（CNBC）", true, quotes.length);
    })().catch((error) => record("美股股指（CNBC）", false, 0, error instanceof Error ? error.message : "unknown")),
    // BTC/ETH 现货 ETF 资金流（Farside 表格页，需要浏览器 UA）
    (async () => {
      const cached = fresh(extCache.etf, 30 * 60_000);
      if (cached) { etfFlows.push(...cached); record("ETF 资金流（Farside）", true, cached.length); sources[sources.length - 1].name += "（缓存）"; return; }
      const flows: EtfFlow[] = [];
      for (const asset of ["btc", "eth"] as const) {
        const res = await fetchWithTimeout(`https://farside.co.uk/${asset}/`, 12000, { "user-agent": BROWSER_UA, accept: "text/html" });
        if (!res.ok) throw new Error(`${asset.toUpperCase()} HTTP ${res.status}`);
        const flow = parseFarsideFlows(await res.text(), asset.toUpperCase());
        if (!flow) throw new Error(`${asset.toUpperCase()} 表格解析失败`);
        flows.push(flow);
      }
      etfFlows.push(...flows); extCache.etf = { at: Date.now(), data: flows }; record("ETF 资金流（Farside）", true, flows.length);
    })().catch((error) => record("ETF 资金流（Farside）", false, 0, error instanceof Error ? error.message : "unknown")),
    // 宏观经济日历（ForexFactory 本周公开周历；源按客户端指纹限流并返回 retry-after，做有界重试）
    (async () => {
      const cached = fresh(extCache.calendar, 60 * 60_000);
      if (cached) { calendar.push(...cached); record("宏观日历（ForexFactory）", true, cached.length); sources[sources.length - 1].name += "（缓存）"; return; }
      let events: CalendarEvent[] = [];
      for (let attempt = 0; attempt < 2; attempt++) {
        const res = await fetchWithTimeout("https://nfs.faireconomy.media/ff_calendar_thisweek.json", 9000, { "user-agent": BROWSER_UA, accept: "application/json", "accept-language": "en-US,en;q=0.9" });
        if (res.ok) {
          events = parseFfCalendar(await res.json());
          if (events.length) break;
        } else if (res.status === 429 && attempt === 0) {
          const wait = Math.min(Number(res.headers.get("retry-after")) || 0, 12) * 1000;
          await new Promise((r) => setTimeout(r, wait));
          continue;
        }
        throw new Error(`HTTP ${res.status}`);
      }
      if (!events.length) throw new Error("未取得有效日程");
      calendar.push(...events); extCache.calendar = { at: Date.now(), data: events }; record("宏观日历（ForexFactory）", true, events.length);
    })().catch((error) => record("宏观日历（ForexFactory）", false, 0, error instanceof Error ? error.message : "unknown")),
  ]);

  if (!tickers.length) return NextResponse.json({ error: "真实行情源不可用，采集已停止；系统不会使用模拟价格。", collectedAt, sources }, { status: 503 });
  const pack = { collectedAt, tickers, news: uniqueNews, sources, indicators: { fearGreed }, equities, etfFlows, calendar };
  // 缓存最新事实包，供图表路由（/api/charts/*）生成配图使用
  setPackCache(pack);
  return NextResponse.json(pack);
}
