import { NextResponse } from "next/server";
import { listRuns, saveRun, type RunRecord } from "@/lib/run-registry";

export async function GET() { return NextResponse.json({ runs: await listRuns() }); }
export async function POST(request: Request) {
  const record = await request.json() as RunRecord;
  if (!record.runId || !record.reportType || !record.reportWindow) return NextResponse.json({ error: "运行记录不完整" }, { status: 400 });
  return NextResponse.json({ run: await saveRun(record) });
}
