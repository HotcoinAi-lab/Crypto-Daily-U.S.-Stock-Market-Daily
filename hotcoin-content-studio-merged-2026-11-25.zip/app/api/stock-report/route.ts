import { NextResponse } from "next/server";
import { aiConfigured, chatComplete } from "@/lib/ai";
import { createRunId, projectReportGate } from "@/lib/report-governance";
import { saveRun } from "@/lib/run-registry";

const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36";

async function jget(url: string, ms = 9000) {
  const c = new AbortController(); const timer = setTimeout(() => c.abort(), ms);
  try { const r = await fetch(url, { signal: c.signal, headers: { "user-agent": UA, accept: "application/json" }, cache: "no-store" }); return r; }
  finally { clearTimeout(timer); }
}

type LedgerItem = { item: string; value: string; source: string; url: string; asOf: string; pending?: boolean };
type Locale = "zh-CN" | "zh-HK" | "en";
type PosterCopy = { category: string; issuer: string; underlying: string; onChain: string; milestones: string; highlights: string[]; risks: string[]; keyFocus: string };

const ABOUT: Record<Locale, string> = {
  "zh-CN": process.env.REPORT_ABOUT_ZH_CN || "关于我们：Hotcoin Research 提供数字资产与代币化证券研究。本报告仅供信息参考。",
  "zh-HK": process.env.REPORT_ABOUT_ZH_HK || "關於我們：Hotcoin Research 提供數字資產與代幣化證券研究。本報告僅供資訊參考。",
  en: process.env.REPORT_ABOUT_EN || "About Us: Hotcoin Research provides research on digital assets and tokenized securities. This report is for informational purposes only.",
};
const LINKS = (process.env.REPORT_BRAND_LINKS || "").split(/\s*\|\s*/).filter(Boolean);
const DISCLAIMER: Record<Locale, string> = {
  "zh-CN": "免责声明：本文仅为研究分享，不构成投资建议；代币化股票不等同于持有正股；数据以实时行情为准。",
  "zh-HK": "免責聲明：本文僅作研究分享，不構成投資建議；代幣化股票不等同於持有正股；數據以即時行情為準。",
  en: "Disclaimer: This report is for research purposes only and does not constitute investment advice. Tokenized stocks are not equivalent to ownership of the underlying shares. Data is subject to live market information.",
};

function appendTail(report: string, locale: Locale) {
  const links = LINKS.length ? LINKS.map((link) => `- ${link}`).join("\n") : locale === "en" ? "- Official links: pending configuration" : locale === "zh-HK" ? "- 官方連結：待配置" : "- 官方链接：待配置";
  return `${report.trim()}\n\n## ${locale === "en" ? "Disclaimer" : locale === "zh-HK" ? "免責聲明" : "免责声明"}\n${DISCLAIMER[locale]}\n\n## ${locale === "en" ? "About Us" : locale === "zh-HK" ? "關於我們" : "关于我们"}\n${ABOUT[locale]}\n\n${links}`;
}

function xml(value: string) {
  return value
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll("\"", "&quot;")
    .replaceAll("'", "&apos;");
}

function visualSvg(title: string, subtitle: string, accent = "#f4b942") {
  return `<svg xmlns="http://www.w3.org/2000/svg" width="1600" height="900" viewBox="0 0 1600 900"><defs><linearGradient id="g" x2="1" y2="1"><stop stop-color="#090b0e"/><stop offset="1" stop-color="#17191d"/></linearGradient></defs><rect width="1600" height="900" fill="url(#g)"/><circle cx="1280" cy="450" r="240" fill="none" stroke="${accent}" stroke-opacity=".18" stroke-width="2"/><circle cx="1280" cy="450" r="175" fill="none" stroke="${accent}" stroke-opacity=".32" stroke-width="3"/><text x="112" y="132" fill="#f5f5f5" font-family="Arial,sans-serif" font-size="38" font-weight="700">Hotcoin Research</text><path d="M112 170h1376" stroke="#34363b"/><text x="112" y="405" fill="#fff" font-family="Arial,sans-serif" font-size="76" font-weight="700">${xml(title)}</text><text x="116" y="474" fill="${accent}" font-family="Arial,sans-serif" font-size="34">${xml(subtitle)}</text><text x="116" y="800" fill="#777b82" font-family="Arial,sans-serif" font-size="20">TOKENIZED SECURITIES · RESEARCH</text></svg>`;
}

function posterSvg(title: string, subtitle: string, copy: PosterCopy, locale: Locale) {
  const en = locale === "en"; const hk = locale === "zh-HK";
  const labels = en ? ["Category", "Underlying", "On-chain", "Milestones", "Highlights vs Risks", "Key focus"] : hk ? ["類別", "標的", "鏈上數據", "關鍵節點", "亮點 vs 風險", "關鍵觀察"] : ["定位", "標的", "链上数据", "关键节点", "亮点 vs 风险", "关键观察"];
  const esc = xml; const rows = [copy.category, copy.underlying, copy.onChain, copy.milestones];
  const left = rows.map((v, i) => `<text x="112" y="${440 + i * 90}" fill="#f4f4f4" font-family="Arial,sans-serif" font-size="24"><tspan font-weight="700">${labels[i]}: </tspan>${esc(v.slice(0, 110))}</text>`).join("");
  const bullets = [...copy.highlights.slice(0, 4).map((x) => ["#42d392", x] as const), ...copy.risks.slice(0, 4).map((x) => ["#ff625c", x] as const)];
  const right = bullets.map(([color, v], i) => `<text x="870" y="${475 + i * 43}" fill="${color}" font-family="Arial,sans-serif" font-size="25">${i < 4 ? "✓" : "▼"}</text><text x="910" y="${475 + i * 43}" fill="#ededed" font-family="Arial,sans-serif" font-size="23">${esc(v.slice(0, 76))}</text>`).join("");
  return `<svg xmlns="http://www.w3.org/2000/svg" width="1600" height="900" viewBox="0 0 1600 900"><rect width="1600" height="900" fill="#050607"/><text x="112" y="90" fill="#fff" font-family="Arial,sans-serif" font-size="35" font-weight="700">Hotcoin</text><text x="112" y="190" fill="#fff" font-family="Arial,sans-serif" font-size="60" font-weight="700">${esc(title)}</text><text x="112" y="250" fill="#fff" font-family="Arial,sans-serif" font-size="34">${esc(subtitle)}</text><path d="M112 300h1376" stroke="#343434"/><text x="112" y="380" fill="#ddd" font-family="Arial,sans-serif" font-size="28" font-weight="700">${labels[0]} · ${labels[1]} · ${labels[2]}</text>${left}<text x="870" y="380" fill="#ddd" font-family="Arial,sans-serif" font-size="28" font-weight="700">${labels[4]}</text>${right}<text x="870" y="855" fill="#aaa" font-family="Arial,sans-serif" font-size="21">${labels[5]}: ${esc(copy.keyFocus.slice(0, 100))}</text></svg>`;
}

function copyFor(locale: Locale, company: string, ticker: string, code: string, issuerInfo: string, tokenPrice: string, stockPrice: string): PosterCopy {
  const pending = locale === "en" ? "Pending verification" : locale === "zh-HK" ? "待核實" : "待核验";
  const known = (value: string) => value || pending;
  const title = company + " / " + ticker;
  if (locale === "en") return {
    category: "Tokenized equities", issuer: issuerInfo || pending, underlying: title + " (" + known(stockPrice) + ")",
    onChain: "Token " + code.toUpperCase() + ": " + known(tokenPrice), milestones: pending,
    highlights: ["Links public-market exposure with on-chain distribution", "Underlying quote and token quote are tracked separately"],
    risks: ["Issuer, custody, mint and redemption terms require verification", "Token price can diverge from the underlying equity"],
    keyFocus: "Verify legal rights, liquidity and the official issuer disclosures.",
  };
  if (locale === "zh-HK") return {
    category: "代幣化美股", issuer: issuerInfo || pending, underlying: title + "（" + known(stockPrice) + "）",
    onChain: "代幣 " + code.toUpperCase() + "：" + known(tokenPrice), milestones: pending,
    highlights: ["把公開市場標的與鏈上分發連接", "正股與代幣報價分開追蹤"],
    risks: ["發行方、託管、鑄造贖回條款待核實", "代幣價格可能偏離正股"],
    keyFocus: "核實權利結構、流動性及發行方官方披露。",
  };
  return {
    category: "代币化美股", issuer: issuerInfo || pending, underlying: title + "（" + known(stockPrice) + "）",
    onChain: "代币 " + code.toUpperCase() + "：" + known(tokenPrice), milestones: pending,
    highlights: ["连接公开市场标的与链上分发", "正股与代币报价独立追踪"],
    risks: ["发行方、托管、铸造赎回条款待核验", "代币价格可能偏离正股"],
    keyFocus: "核验权利结构、流动性及发行方官方披露。",
  };
}

function fallbackReport(locale: Locale, company: string, ticker: string, code: string, today: string, stockPrice: string, tokenPrice: string) {
  const stock = stockPrice || (locale === "en" ? "Pending verification" : locale === "zh-HK" ? "待核實" : "待核验");
  const token = tokenPrice || (locale === "en" ? "Pending verification" : locale === "zh-HK" ? "待核實" : "待核验");
  if (locale === "en") return ["# Hotcoin Research | " + company + " (" + code.toUpperCase() + ") Tokenized Equity Project Report", "", "Date: " + today, "", "## 1. Overview", "Underlying: " + ticker + "; underlying quote: " + stock + "; token quote: " + token + ". This draft is based only on the attached evidence ledger.", "", "## 2. Project Introduction", "The issuer structure and the legal relationship between the token and underlying shares require official verification.", "", "## 3. Product and Technology", "Document the supported chain, custody, minting, redemption and corporate-action handling from official issuer materials.", "", "## 4. Token Economics", "Token supply, circulating amount, market capitalization and fees are pending verification; do not treat token data as company equity data.", "", "## 5. Team and Backers", "Pending official issuer, company IR and regulatory disclosures.", "", "## 6. Roadmap", "Pending official announcements.", "", "## 7. Risks and Opportunities", "Company, regulatory, issuer, custody, liquidity and price-deviation risks must be assessed separately.", "", "## 8. Summary", "This is a production skeleton. Complete outstanding ledger items before publication."].join("\n");
  const p = locale === "zh-HK" ? "待核實" : "待核验";
  return ["# Hotcoin Research｜" + company + "（" + code.toUpperCase() + "）代幣化股票項目報告", "", "日期：" + today, "", "## 一、項目概覽", "正股：" + ticker + "；正股報價：" + stock + "；代幣報價：" + token + "。本稿僅依據資料台帳生成。", "", "## 二、項目介紹", "發行結構及代幣與正股的法律權利關係，" + p + "。", "", "## 三、產品與技術", "請依發行方官方資料補充公鏈、託管、鑄造、贖回及公司行動處理機制。", "", "## 四、經濟模型", "代幣供應、流通量、市值與費用" + p + "；不可將代幣數據與公司股權數據混用。", "", "## 五、團隊與投資人", "待發行方、公司 IR 及監管披露核實。", "", "## 六、路線圖", "待官方公告核實。", "", "## 七、風險與機會", "公司、監管、發行方、託管、流動性及價格偏離風險應分開評估。", "", "## 八、總結", "這是可供生產的報告骨架；發布前需完成所有待核實台帳項目。"].join("\n");
}

function rssItems(xml: string, source: string) {
  return (xml.match(/<item[\s\S]*?<\/item>/gi) || []).slice(0, 12).map((b) => {
    const g = (t: string) => (b.match(new RegExp(`<${t}[^>]*>([\\s\\S]*?)<\\/${t}>`, "i"))?.[1] || "").replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, "$1").replace(/<[^>]+>/g, " ").replace(/&amp;/g, "&").trim();
    return { title: g("title"), url: g("link"), pubDate: g("pubDate"), source };
  }).filter(x => x.title && x.url);
}

export async function POST(request: Request) {
  const body = await request.json() as {
    company_name?: string; stock_ticker?: string; hotcoin_code?: string; issuer_info?: string; today?: string;
    token_price?: string; token_change?: string; token_asof?: string; approved?: boolean;
  };
  const company = (body.company_name || "").trim();
  const ticker = (body.stock_ticker || "").trim().toUpperCase();
  const code = (body.hotcoin_code || "").trim().toLowerCase();
  const today = body.today || new Date().toISOString().slice(0, 10);
  if (!company || !ticker || !code) return NextResponse.json({ error: "company_name、stock_ticker、hotcoin_code 为必填" }, { status: 400 });

  const warnings: string[] = [];
  const ledger: LedgerItem[] = [];
  let tokenOk = false; let tokenPrice = body.token_price || ""; let tokenChange = body.token_change || "";

  // ① Hotcoin 代币层：优先用前端已采集的价格（前端网络可达该域名；workerd 内 DNS 不稳）
  if (tokenPrice) {
    tokenOk = true;
    ledger.push({ item: "代币价格（Hotcoin）", value: `${tokenPrice}（24h ${tokenChange}）`, source: "Hotcoin 行情接口", url: "https://api.hotcoinfin.com/v1/market/ticker", asOf: body.token_asof || today });
  } else {
    try {
      const r = await jget("https://api.hotcoinfin.com/v1/market/ticker");
      if (r.ok) {
        const j = await r.json() as { data?: { symbol: string; last: string; change: string; ts: number }[] };
        const hit = (j.data || []).find(t => t.symbol === `${code}_usdt`);
        if (hit) {
          tokenOk = true;
          tokenPrice = `$${hit.last}`; tokenChange = `${Number(hit.change) >= 0 ? "+" : ""}${hit.change}%`;
          ledger.push({ item: "代币价格（Hotcoin）", value: `${tokenPrice}（24h ${tokenChange}）`, source: "Hotcoin 行情接口", url: "https://api.hotcoinfin.com/v1/market/ticker", asOf: new Date(Number(hit.ts)).toISOString().slice(0, 10) });
        } else warnings.push(`Hotcoin 现货未找到 ${code}_usdt 交易对，请核实 hotcoin_code`);
      } else warnings.push(`Hotcoin 行情接口 HTTP ${r.status}`);
    } catch (e) { warnings.push(`Hotcoin 行情接口失败：${e instanceof Error ? e.message : "unknown"}`); }
  }

  let stockOk = false; let stockPrice = ""; let stockChange = ""; let stockName = "";

  // ② 正股层：CNBC 报价
  try {
    const r = await jget(`https://quote.cnbc.com/quote-html-webservice/restQuote/symbolType/symbol?symbols=${encodeURIComponent(ticker)}&requestMethod=itv&noform=1&partnerId=2&fund=1&output=json`);
    if (r.ok) {
      const j = await r.json() as { FormattedQuoteResult?: { FormattedQuote?: Record<string, string>[] } };
      const q = j.FormattedQuoteResult?.FormattedQuote?.[0];
      if (q && q.last) {
        stockOk = true; stockPrice = `$${q.last}`; stockChange = q.change_pct || ""; stockName = q.name || ticker;
        ledger.push({ item: "正股价格", value: `${stockPrice}（${stockChange}）`, source: "CNBC 行情", url: `https://www.cnbc.com/quotes/${ticker}`, asOf: q.last_time || today });
      } else warnings.push(`CNBC 未返回 ${ticker} 报价`);
    } else warnings.push(`CNBC 行情接口 HTTP ${r.status}`);
  } catch (e) { warnings.push(`CNBC 行情接口失败：${e instanceof Error ? e.message : "unknown"}`); }

  // ③ 近 90 天相关新闻（复用已验证可达的英文 RSS；中文来源优先的扩展待接入）
  const news: { title: string; url: string; source: string; pubDate: string }[] = [];
  const kw = new RegExp(`${company}|\\b${ticker}\\b`, "i");
  for (const f of [
    { name: "Cointelegraph", url: "https://cointelegraph.com/rss" },
    { name: "Decrypt", url: "https://decrypt.co/feed" },
  ]) {
    try {
      const r = await jget(f.url);
      if (r.ok) for (const n of rssItems(await r.text(), f.name)) news.push(n);
    } catch { /* 单源失败不阻断 */ }
  }
  const cutoff = Date.now() - 90 * 24 * 3600e3;
  const related = news
    .filter(n => { const t = +new Date(n.pubDate); return Number.isFinite(t) ? t >= cutoff : true; })
    .filter(n => kw.test(n.title))
    .slice(0, 8);
  const general = news.filter(n => !kw.test(n.title)).slice(0, 6);

  // ④ 台账：规格中其余数据源（SEC/IR/rwa.xyz/一致预期等）第一版未接入，如实列入人工确认
  for (const [item, src] of [
    ["链上流通量与代币市值", "rwa.xyz / DefiLlama / CoinGecko"],
    ["公司总市值", "Nasdaq / Yahoo Finance / stockanalysis.com"],
    ["市盈率", "stockanalysis.com / Macrotrends"],
    ["最近一季财报与指引", "SEC EDGAR / 公司 IR"],
    ["一致预期", "Yahoo Finance / MarketBeat"],
    ["核心高管与机构股东", "公司 IR / DEF 14A / 13F"],
    ["下一次财报日期", "公司 IR / Nasdaq 财报日历"],
    ["代币托管、铸造赎回与分红机制", "发行方官网 / Hotcoin 公告"],
  ] as const) {
    ledger.push({ item, value: "—", source: src, url: "", asOf: today, pending: true });
    warnings.push(`「${item}」需人工确认（第一版未接入 ${src}）`);
  }
  if (!body.issuer_info) warnings.push("issuer_info 未提供：代币结构（发行方/公链/托管）请人工确认或补充");

  // ⑤ AI 正文（配置了模型密钥时）；否则返回台账与结构骨架
  let draftZh = ""; let aiMode: "ai" | "skeleton" = "skeleton";
  const locales: Locale[] = ["zh-CN", "zh-HK", "en"];
  const reports = Object.fromEntries(locales.map((locale) => [locale, {
    report: appendTail(fallbackReport(locale, company, ticker, code, today, stockPrice, tokenPrice), locale),
    poster: copyFor(locale, company, ticker, code, body.issuer_info || "", tokenPrice, stockPrice),
  }])) as Record<Locale, { report: string; poster: PosterCopy }>;
  if (aiConfigured()) {
    try {
      const ledgerText = ledger.map(l => `${l.item}｜${l.value}｜${l.source}${l.pending ? "（待人工确认）" : ""}`).join("\n");
      const newsText = related.map(n => `- ${n.title}（${n.source}，${n.pubDate}）`).join("\n") || "（近 90 天无该公司相关英文新闻）";
      const prompt = `你是 Hotcoin Research 的研究员，为 Hotcoin 现货已上线的代币化美股撰写《Hotcoin Research｜${company}（${code.toUpperCase()}）代币化股票项目报告》，简体中文，结构固定为八节（一、项目概览 200 字；二、项目介绍 250 字；三、产品与技术 300 字；四、经济模型 300 字；五、团队与投资人 200 字；六、路线图 200 字；七、风险与机会 250 字（公司风险 3 条、代币层风险 2 条、机会 2-3 条）；八、总结 100 字）。不要添加免责声明、关于我们或品牌链接，系统会统一追加。
规则：纯文字不用表格；禁止推荐买卖、承诺收益、目标价；数据台账里没有的数字不得出现，缺失数据写「以官方公告为准」；代币市值与公司市值分开并标日期；发行方/托管信息只用输入与官方信息；公司层风险与代币层风险分开列。
输入：公司=${company}；正股代码=${ticker}；Hotcoin 代码=${code.toUpperCase()}；发行方信息=${body.issuer_info || "未提供"}；日期=${today}。
数据台账（唯一事实来源）：
${ledgerText}
相关新闻（近 90 天）：
${newsText}
只输出报告正文。`;

      draftZh = await chatComplete(prompt); aiMode = "ai";
      if (!draftZh) throw new Error("模型未返回正文");
      reports["zh-CN"].report = appendTail(draftZh, "zh-CN");
      for (const locale of ["zh-HK", "en"] as Locale[]) {
        const language = locale === "en" ? "English" : "繁體中文（香港用語）";
        const localized = await chatComplete("Translate the following report into " + language + ". Preserve every number, ticker, date, URL, heading structure, uncertainty marker and source scope exactly. Do not add facts, advice, links, disclaimer or About Us text. Output only the translated report.\n\n" + draftZh);
        reports[locale].report = appendTail(localized, locale);
      }
    } catch (e) { warnings.push(`AI 正文生成失败：${e instanceof Error ? e.message : "unknown"}`); }
  } else {
    warnings.push("未配置模型密钥：本次仅输出数据台账与章节骨架，正文需配置密钥后生成");
    draftZh = reports["zh-CN"].report;
  }

  const visuals = Object.fromEntries(locales.map((locale) => {
    const title = locale === "en" ? company + " Tokenized Equity" : company + " 代币化美股";
    const subtitle = ticker + " · " + code.toUpperCase() + " · " + today;
    return [locale, { coverSvg: visualSvg(title, subtitle), posterSvg: posterSvg(title, subtitle, reports[locale].poster, locale) }];
  })) as Record<Locale, { coverSvg: string; posterSvg: string }>;
  const approved = body.approved === true;
  const quality = projectReportGate({ today, approved, reports, visuals, ledger, linksConfigured: LINKS.length > 0 });
  const runId = createRunId("tokenized-stock-report");
  const run = await saveRun({ runId, reportType: "tokenized-stock-report", createdAt: new Date().toISOString(), reportWindow: { date: today, label: company + " / " + ticker, timezone: "UTC" }, sources: [
    { name: "Hotcoin 行情", status: tokenOk ? "ok" : "failed", detail: tokenOk ? "交易对行情已采集" : "交易对行情未验证" },
    { name: "CNBC 正股行情", status: stockOk ? "ok" : "failed", detail: stockOk ? "正股报价已采集" : "正股报价未采集" },
    { name: "项目基础资料", status: body.issuer_info ? "partial" : "failed", detail: body.issuer_info ? "操作者输入，待人工核验" : "发行方/公链/托管资料缺失" },
  ], quality: quality.checks, approval: approved ? "approved" : "pending", artifacts: ["report-zh-CN.md", "report-zh-HK.md", "report-en.md", "poster-copy-zh-CN.json", "poster-copy-en.json", "cover-zh-CN.svg", "cover-zh-HK.svg", "cover-en.svg", "poster-zh-CN.svg", "poster-zh-HK.svg", "poster-en.svg", "project-report-quality.json", "project-report-production-package.json"], status: quality.passed ? "ready" : "blocked" });
  return NextResponse.json({
    today, tokenOk, tokenPrice, tokenChange, stockOk, stockPrice, stockChange, stockName,
    ledger, relatedNews: related, generalNews: general, warnings, draftZh, reports, visuals, runId, quality, run,
    aiMode,
  });
}

