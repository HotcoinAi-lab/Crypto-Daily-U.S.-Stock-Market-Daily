import { NextResponse } from "next/server";
import { aiConfigured, chatComplete, extractJson } from "@/lib/ai";
import { createRunId, parseWeeklyPublishWindow, weeklyGate } from "@/lib/report-governance";
import { saveRun } from "@/lib/run-registry";
import { buildEvidenceReviewQueue } from "@/lib/evidence-review";

// 《每周洞察》：底稿采集（mode=draft）与 AI 周报生成（mode=generate，需模型密钥）
// 输出 JSON 结构遵循 Hotcoin Research《每周洞察 Prompt》规格（字段名完全一致）
const SPEC = `你是 Hotcoin(热币)交易所研究院 Hotcoin Research 的资深研究员，为《每周洞察》栏目生成下一期完整内容，输出为一个 JSON 对象（weekly_data.json），不要输出 JSON 以外的解释文字。

栏目背景：周日发布，覆盖当周周一至周六；读者是加密投资者（入门至进阶），核心关注 BTC/ETH/SOL/HYPE 与热点叙事。语气专业、克制、数据驱动；可以有观点但绝不喊单，判断一律用「可能/大概率/若…则」留有余地，并始终提示风险。

输出 JSON 结构（字段名必须完全一致）：
{
  "week": { "label": "YYYY年M月D日–D日", "next_week_label": "M月D日-D日", "publish_date": "YYYY-MM-DD" },
  "title_topic": "本周最大矛盾/戏剧性事件，10~20字，悬念或比喻式",
  "market": { "total_market_cap_usd_tn": 数字或null(待人工核实), "btc_dominance_pct": 数字或null, "btc_market_cap_usd_tn": 数字或null, "stablecoin_market_cap_usd_bn": 数字, "stablecoin_change_7d_pct": 数字, "stablecoin_dir": "增加|减少", "usdt_share_pct": 数字, "cmc200_pattern": "…", "coins_7d": [{"sym":"BTC","chg_pct":数字,"dir":"涨|跌"}], "hot_coin": {"sym":"…","chg_pct":数字,"dir":"…"} },
  "prediction": { "rsi": {"value": 数字, "state": "超买|中性|超卖"}, "fear_greed": {"value": 数字, "state": "…", "note": "一句话本周情绪走势"}, "altseason": {"value": null, "state": "待人工核实"}, "overall": "一句话定调下周", "ranges": [{"sym":"BTC","low":数字,"high":数字,"note":"关键支撑/压力+一句话逻辑"}] },
  "flows": { "etf": [{"asset":"BTC","summary":"D日净流入/流出X亿、…，近5个交易日累计…，一句话评价"}], "stablecoins": {"total_usd_bn": 数字, "usdt_share_pct": 数字, "source": "DefiLlama", "chg_7d_pct": 数字, "comment": "供给趋势点评一句"}, "comment": "资金面综合解读2~3句" },
  "derivatives": { "funding": [{"sym":"…","avg_8h_pct":数字,"annualized_pct":数字,"state":"…"}], "open_interest": [{"sym":"…","oi_value_usd_bn":数字,"chg_7d_pct":null}], "comment": "按『价格-OI-费率』三维判断杠杆状态2~3句" },
  "onchain_sectors": { "tvl": {"total_usd_bn": 数字, "chg_7d_pct": 数字, "source": "DefiLlama"}, "sectors": [{"name":"…","move":"…","comment":"2~3句落到具体事件"}], "equities": {"text": "美股联动总结（本周无美股数据接入则注明）"} },
  "risks": [{"title":"结论式小标题10~20字","body":"2~3句：发生了什么→传导机制→对价格的可能影响→操作建议"}],
  "events": [{"title":"小标题10~20字","body":"2~4句：时间、主体、具体数字、影响"}],
  "macro": ["M月D日[HH:MM]，主体公布指标为 X，预期 X，前值 X。"],
  "future": { "conferences": [], "key_events": ["M月D日HH:MM，主体将公布XX。"], "projects": ["待人工核实"], "unlocks": ["暂无可靠解锁数据，待人工核实"] }
}

写作硬规则：
- risks 恰好 3 条；events 8~11 条（正文主体，选材优先级：监管/立法 > 交易所与机构大动作 > 安全事件 > 链上进展 > 数据异动 > 行业风向），注明来源；macro 3~5 条固定句式。
- 数字纪律：底稿自动采集数字（市值/占比/涨跌幅/费率/OI/TVL/ETF流向/恐惧贪婪/RSI）一律原样引用，禁止改动或臆造；底稿为 null 的字段写 null 并在 note 标「待人工核实」，禁止编造。
- 金额用「亿美元/万美元」，价格用千分位；涨跌幅必须带方向词。总字数（所有文字合计）4500~6000。
- 时态区分「本周已发生」与「下周将发生」；禁止「暴涨」「必涨」「抄底」等喊单词；不用第一人称。
- ranges 区间 ≈ 最新价 ±5%~8%，note 必须给具体关键位。`;

export async function POST(request: Request) {
  const body = await request.json().catch(() => ({})) as { mode?: string; reportWindow?: unknown; approved?: boolean };
  const mode = body.mode === "generate" ? "generate" : "draft";
  let reportWindow;
  try { reportWindow = parseWeeklyPublishWindow(body.reportWindow); }
  catch (error) { return NextResponse.json({ error: error instanceof Error ? error.message : "报告窗口无效" }, { status: 400 }); }
  const runId = createRunId("crypto-weekly");

  // 采集底稿（动态 import 避免冷启动串行加载）；事实包优先用采集缓存（含 ETF 日度序列）
  const { collectWeeklyDraft } = await import("@/lib/weekly");
  const { getPackCache } = await import("@/lib/pack-cache");
  const facts = getPackCache()?.facts || null;
  const draft = await collectWeeklyDraft(facts, reportWindow);
  const evidenceReviewQueue = buildEvidenceReviewQueue(facts, reportWindow);
  const evidenceManifest = { version: "1.0", reportWindow, collectedAt: draft.collectedAt, sources: draft.sourceStatus.map(source => ({ ...source, retrievedAt: draft.collectedAt })), restrictions: ["RSS 与公开日历仅用于线索，未写入可发布事实。", "OI 为运行时快照，未采集周变化时 chg_7d_pct 必须为 null。", "未有证据的新闻、宏观、未来日历与关键价位必须保持空。"] };
  const save = async (weekly: Record<string, unknown> | null, quality: ReturnType<typeof weeklyGate>) => saveRun({
    runId, reportType: "crypto-weekly", createdAt: draft.collectedAt, reportWindow, sources: draft.sourceStatus, quality: quality.checks, approval: body.approved ? "approved" : "pending", artifacts: ["weekly_data_draft.json", ...(weekly ? ["weekly_data.json"] : []), "evidence-manifest.json", "quality-report.json", "run-manifest.json"], status: quality.passed ? "ready" : "blocked",
  });

  if (mode === "draft") { const quality = weeklyGate({ reportWindow, draft: draft as unknown as Record<string, unknown>, sources: draft.sourceStatus, approved: body.approved }); return NextResponse.json({ mode, runId, reportWindow, draft, evidenceManifest, evidenceReviewQueue, quality, run: await save(null, quality) }); }

  if (!aiConfigured()) {
    const quality = weeklyGate({ reportWindow, draft: draft as unknown as Record<string, unknown>, sources: draft.sourceStatus, approved: body.approved });
    return NextResponse.json({
      mode, runId, reportWindow, draft, evidenceManifest, evidenceReviewQueue, quality, run: await save(null, quality),
      weekly: null,
      warning: "未配置模型密钥（AI_API_KEY 或 OPENAI_API_KEY）：已输出底稿 JSON（可手动粘贴给 AI 生成周报），或配置密钥后自动生成",
    });
  }

  const prompt = `${SPEC}\n\n【自动采集底稿（weekly_data_draft.json，唯一事实来源）】\n${JSON.stringify(draft)}\n\n请生成 weekly_data.json（仅输出 JSON 对象本身）。底稿中 null 的字段保持 null 并标注待人工核实；events/macro 不足的条数如实说明，不得编造。`;

  try {
    const text = await chatComplete(prompt);
    const weekly = extractJson(text);
    const quality = weeklyGate({ reportWindow, draft: draft as unknown as Record<string, unknown>, sources: draft.sourceStatus, generated: weekly as Record<string, unknown>, approved: body.approved });
    return NextResponse.json({ mode, runId, reportWindow, draft, weekly, evidenceManifest, evidenceReviewQueue, quality, run: await save(weekly as Record<string, unknown>, quality) });
  } catch (e) {
    const quality = weeklyGate({ reportWindow, draft: draft as unknown as Record<string, unknown>, sources: draft.sourceStatus, approved: body.approved });
    return NextResponse.json({ mode, runId, reportWindow, draft, weekly: null, evidenceManifest, evidenceReviewQueue, quality, run: await save(null, quality), warning: `AI 生成失败：${e instanceof Error ? e.message : "unknown"}（底稿已输出，可手动生成）` }, { status: 200 });
  }
}
