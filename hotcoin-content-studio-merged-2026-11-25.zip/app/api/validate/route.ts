import { NextResponse } from "next/server";
import type { FactPack } from "@/lib/market-studio";

export async function POST(request: Request) {
  const { draft, factPack } = await request.json() as { draft?: string; factPack?: FactPack };
  if (!draft || !factPack) return NextResponse.json({ error: "缺少正文或事实包" }, { status: 400 });
  const age = Date.now() - new Date(factPack.collectedAt).getTime(); const sourceCount = factPack.sources.filter(s=>s.ok).length;
  const checks = [
    { id: "fresh", label: "数据时效", passed: age < 6*60*60*1000, detail: age < 6*60*60*1000 ? "事实包采集时间在6小时以内" : "数据超过6小时，请重新采集", severity: "blocker" as const },
    { id: "market", label: "真实行情存在", passed: factPack.tickers.length >= 2, detail: `已取得 ${factPack.tickers.length} 个行情快照`, severity: "blocker" as const },
    { id: "sources", label: "来源可追溯", passed: sourceCount >= 1, detail: `${sourceCount} 个数据源采集成功`, severity: "blocker" as const },
    { id: "length", label: "正文完整度", passed: draft.length >= 500, detail: `正文 ${draft.length} 字符，最低要求500`, severity: "blocker" as const },
    { id: "cutoff", label: "标明数据截止时间", passed: /截止|as of|截至/i.test(draft), detail: "正文应明确行情快照时间", severity: "blocker" as const },
    { id: "risk", label: "风险提示", passed: /不[构構]成.*(投[资資].*(建[议議]|advice)|investment advice)/i.test(draft), detail: "正文必须包含非投资建议声明（简繁体均可）", severity: "blocker" as const },
    { id: "promise", label: "确定性承诺检查", passed: !/(保证上涨|必然上涨|稳赚|零风险|guaranteed profit)/i.test(draft), detail: "禁止收益承诺和确定性价格预测", severity: "blocker" as const },
    { id: "news", label: "新闻覆盖", passed: factPack.news.length > 0, detail: factPack.news.length ? `已采集 ${factPack.news.length} 条资讯` : "新闻源失败，本次只能发布纯行情报告", severity: "warning" as const },
    { id: "seo-h1", label: "SEO：H1 唯一", passed: (draft.match(/^#\s/m) || []).length === 1, detail: "正文应只有一个 H1 标题", severity: "warning" as const },
    { id: "seo-lede", label: "SEO：导语段", passed: !!draft.split("\n").map(l=>l.trim()).find(l => l && !/^[#>|*-]/.test(l)), detail: "标题后应有核心要点引用框或导语段，便于搜索摘要与精选片段", severity: "warning" as const },
    { id: "seo-faq", label: "SEO：常见问题", passed: /常[见見][问問][题題]/.test(draft), detail: "建议增加「❓ 常见问题」小节，覆盖长尾搜索词并生成 FAQPage 结构化数据", severity: "warning" as const },
  ];
  return NextResponse.json({ passed: checks.every(c=>c.severity!=="blocker"||c.passed), checks });
}
