import { NextResponse } from "next/server";
import { createRunId } from "@/lib/report-governance";
import { saveRun } from "@/lib/run-registry";
const required = ["zh.md", "en.md", "evidence.md", "visual-data.json", "visual-data-zh.json"];

export async function POST(request: Request) {
  const { files = [], reportDate = "", approved = false } = await request.json().catch(() => ({})) as { files?: string[]; reportDate?: string; approved?: boolean };
  const names = new Set(files.map(x => x.split("/").pop()));
  const zhCharts = files.filter(x => /visuals(?:-zh|\/zh)[\/].*\.png$/.test(x)).length;
  const enCharts = files.filter(x => /visuals(?:-en|\/en)[\/].*\.png$/.test(x)).length;
  const cover = files.some(x => /cover.*\.png$/i.test(x));
  const checks = [
    ...required.map(name => ({ id: "daily-" + name, label: "包含 " + name, passed: names.has(name), severity: "blocker" as const, detail: names.has(name) ? "已发现" : "缺失" })),
    { id: "daily-cover", label: "固定封面", passed: cover, severity: "blocker" as const, detail: cover ? "已发现封面图片" : "缺失封面图片" },
    { id: "daily-zh-charts", label: "中文图表 3 张", passed: zhCharts === 3, severity: "blocker" as const, detail: "发现 " + zhCharts + "/3 张" },
    { id: "daily-en-charts", label: "英文图表 3 张", passed: enCharts === 3, severity: "blocker" as const, detail: "发现 " + enCharts + "/3 张" },
  ];
  const passed = checks.every(c => c.passed);
  const run = await saveRun({
    runId: createRunId("tradfi-daily"), reportType: "tradfi-daily", createdAt: new Date().toISOString(),
    reportWindow: { date: reportDate || "未填写", timezone: "UTC" },
    sources: [{ name: "日报交付包", status: passed ? "ok" : "partial", detail: passed ? "完整性检查通过" : "存在交付缺件" }],
    quality: checks, approval: approved ? "approved" : "pending", artifacts: files, status: passed ? (approved ? "ready" : "draft") : "blocked",
  });
  return NextResponse.json({ reportDate, passed, checks, artifacts: files, run });
}
