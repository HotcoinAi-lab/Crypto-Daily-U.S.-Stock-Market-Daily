import { NextResponse } from "next/server";
import { createRunId } from "@/lib/report-governance";
import { saveRun } from "@/lib/run-registry";
import { planTradfiDaily, type TradfiDailyFactPack } from "@/lib/tradfi-daily";

// Fact-pack endpoint: validates the original TradFi daily contract before any prose/chart renderer runs.
export async function POST(request: Request) {
  const facts = await request.json().catch(() => ({})) as TradfiDailyFactPack & { approved?: boolean };
  const plan = planTradfiDaily(facts);
  const approved = facts.approved === true;
  const run = await saveRun({
    runId: createRunId("tradfi-daily"), reportType: "tradfi-daily", createdAt: new Date().toISOString(),
    reportWindow: { date: facts.reportDate || "未填写", timezone: "UTC" }, sources: plan.sourceStatus, quality: plan.checks,
    approval: approved ? "approved" : "pending", artifacts: plan.requiredArtifacts,
    status: plan.blockers.length ? "blocked" : approved ? "ready" : "draft",
  });
  return NextResponse.json({ mode: "plan", plan, run,
    warning: plan.blockers.length ? "缺少可追溯事实输入；未生成正文或图表。" : "事实底稿完整；仍需运营确认后才可交付。" });
}
