#!/usr/bin/env node
import { readdir, writeFile } from "node:fs/promises";
import path from "node:path";

const root = process.argv[2];
if (!root) { console.error("Usage: node scripts/check-daily-package.mjs <report-directory>"); process.exit(2); }
async function files(dir, base = dir) {
  const entries = await readdir(dir, { withFileTypes: true });
  const result = await Promise.all(entries.map(e => e.isDirectory() ? files(path.join(dir, e.name), base) : [path.relative(base, path.join(dir, e.name))]));
  return result.flat();
}
const list = await files(root);
const names = new Set(list.map(x => path.basename(x)));
const required = ["zh.md", "en.md", "evidence.md", "visual-data.json", "visual-data-zh.json"];
const zh = list.filter(x => /^visuals-zh\/.*\.png$/.test(x)).length;
const en = list.filter(x => /^visuals-en\/.*\.png$/.test(x)).length;
const checks = [
  ...required.map(name => ({ id: "daily-" + name, label: "包含 " + name, passed: names.has(name), severity: "blocker", detail: names.has(name) ? "已发现" : "缺失" })),
  { id: "daily-cover", label: "固定封面", passed: list.some(x => /cover.*\.png$/i.test(x)), severity: "blocker", detail: "在当前交付目录或资产目录中提供固定封面" },
  { id: "daily-zh-charts", label: "中文图表 3 张", passed: zh === 3, severity: "blocker", detail: "发现 " + zh + "/3 张" },
  { id: "daily-en-charts", label: "英文图表 3 张", passed: en === 3, severity: "blocker", detail: "发现 " + en + "/3 张" },
];
const report = { reportDirectory: root, checkedAt: new Date().toISOString(), passed: checks.every(c => c.passed), checks, artifacts: list };
const output = path.join(root, "daily-quality-report.json");
await writeFile(output, JSON.stringify(report, null, 2) + "\n");
console.log(JSON.stringify({ output, passed: report.passed, blockers: checks.filter(c => !c.passed).map(c => c.id) }, null, 2));
process.exit(report.passed ? 0 : 1);
