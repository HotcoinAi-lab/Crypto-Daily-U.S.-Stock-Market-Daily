#!/usr/bin/env bash
set -euo pipefail

script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [[ "${SITES_ENV_READY:-}" != "1" ]]; then
  exec bash "${script_dir}/sites-env.sh" -- "$0" "$@"
fi

vinext_bin="${SITES_PROJECT_ROOT}/node_modules/.bin/vinext"
vinext_cli="${SITES_PROJECT_ROOT}/node_modules/vinext/dist/cli.js"
if [[ -x "${vinext_bin}" ]]; then
  vinext_cmd=("${vinext_bin}")
elif [[ -f "${vinext_cli}" ]]; then
  # Some restored macOS dependency trees lose executable bits in .bin.
  # The package CLI remains usable through Node.
  vinext_cmd=(node "${vinext_cli}")
else
  echo "vinext is unavailable. Run npm run install:ci and wait for it to finish before building." >&2
  exit 69
fi

echo "Running bounded vinext build..."
if command -v timeout >/dev/null 2>&1; then
  timeout \
    --signal=TERM \
    --kill-after="${SITES_BUILD_KILL_AFTER:-10s}" \
    "${SITES_BUILD_TIMEOUT:-3m}" \
    "${vinext_cmd[@]}" build
else
  # macOS ships no GNU timeout. The caller is already bounded by the task runner.
  "${vinext_cmd[@]}" build
fi
