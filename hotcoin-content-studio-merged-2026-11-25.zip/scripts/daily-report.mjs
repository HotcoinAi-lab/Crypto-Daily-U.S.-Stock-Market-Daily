// 每日定时采集报告脚本
// 流程：确保开发服务器运行 → 采集行情/资讯/指标 → 生成日报（无 API Key 时用事实模板）→ 质检 → 保存到 reports/
// 用法：node scripts/daily-report.mjs [--force]（--force 覆盖当天已生成的报告）
import { spawn } from 'node:child_process';
import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = join(dirname(fileURLToPath(import.meta.url)), '..');
const BASE = 'http://localhost:5173';
const force = process.argv.includes('--force');

// 报告按北京时间日期命名（每天 0 点任务生成当日文件）
const today = new Date().toLocaleDateString('en-CA', { timeZone: 'Asia/Shanghai' });
const reportsDir = join(ROOT, 'reports');
const outFile = join(reportsDir, `${today}.md`);

if (!force && existsSync(outFile)) {
  console.log(`[跳过] 今日报告已存在：${outFile}（如需重新生成请加 --force）`);
  process.exit(0);
}

async function serverUp() {
  try { const r = await fetch(BASE); return r.ok; } catch { return false; }
}

async function ensureServer() {
  if (await serverUp()) return console.log('[服务器] 已在运行');
  if (!existsSync(join(ROOT, 'node_modules'))) {
    throw new Error('缺少 node_modules，请先在项目目录执行: npm install');
  }
  console.log('[服务器] 正在启动开发服务器...');
  const npm = process.platform === 'win32' ? 'npm.cmd' : 'npm';
  const child = spawn(npm, ['run', 'dev'], { cwd: ROOT, stdio: 'ignore', detached: true });
  child.unref();
  for (let i = 0; i < 45; i++) {
    await new Promise((r) => setTimeout(r, 2000));
    if (await serverUp()) return console.log('[服务器] 启动完成');
  }
  throw new Error('开发服务器 90 秒内未能就绪');
}

async function post(path, body) {
  const res = await fetch(`${BASE}${path}`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body ?? {}),
  });
  const json = await res.json();
  if (!res.ok) throw new Error(`${path} 失败 HTTP ${res.status}: ${json.error || res.statusText}`);
  return json;
}

try {
  await ensureServer();

  console.log('[1/4] 采集中...');
  const factPack = await post('/api/collect');
  const srcLine = factPack.sources.map((s) => `${s.name}:${s.ok ? 'OK' : 'FAIL'}(${s.count})`).join(' ');
  console.log(`      行情 ${factPack.tickers.length} 条 | 资讯 ${factPack.news.length} 条 | 来源 ${srcLine}`);

  console.log('[2/4] 生成中...');
  const gen = await post('/api/generate', { factPack });
  console.log(`      mode=${gen.mode}, 长度=${gen.content.length}`);

  console.log('[3/4] 质检中...');
  const val = await post('/api/validate', { draft: gen.content, factPack });
  const failed = val.checks.filter((c) => !c.passed && c.severity === 'blocker');
  console.log(`      passed=${val.passed}` + (failed.length ? ` | 未通过: ${failed.map((f) => f.label).join(', ')}` : ''));

  mkdirSync(reportsDir, { recursive: true });
  const meta = `\n\n<!--\n生成时间: ${new Date().toISOString()}\n模式: ${gen.mode}\n质检: ${val.passed ? '通过' : '未通过'}\n数据来源: ${srcLine}\n-->`;
  writeFileSync(outFile, gen.content + meta, 'utf8');

  console.log(`[4/4] 已保存: ${outFile}`);
  // 输出一行摘要便于定时任务日志查看
  const fng = factPack.indicators?.fearGreed;
  console.log(`[摘要] ${today} | BTC $${factPack.tickers.find((t) => t.symbol === 'BTC')?.price ?? '-'} | 恐惧贪婪指数 ${fng ? `${fng.value}(${fng.label})` : 'N/A'} | 新闻 ${factPack.news.length} 条`);
} catch (error) {
  console.error('[失败]', error.message);
  process.exit(1);
}
