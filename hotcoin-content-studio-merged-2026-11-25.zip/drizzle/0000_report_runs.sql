CREATE TABLE IF NOT EXISTS report_runs (
  run_id TEXT PRIMARY KEY NOT NULL,
  report_type TEXT NOT NULL,
  created_at TEXT NOT NULL,
  status TEXT NOT NULL,
  payload TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS report_runs_created_at_idx ON report_runs(created_at DESC);
